import { createClient } from '@supabase/supabase-js';
import { existsSync } from 'node:fs';
import { createSeed } from '../src/seed';
if (existsSync('.env')) process.loadEnvFile('.env');
const url = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL,
  key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key)
  throw Error(
    'Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in .env. Never use the service key in VITE_* variables.',
  );
const db = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
const { data: existing, error: readError } = await db
  .from('erp_state')
  .select('id')
  .eq('id', 1)
  .maybeSingle();
if (readError)
  throw Error('Apply supabase/migrations/001_sunbeams.sql first. ' + readError.message);
if (existing && !process.argv.includes('--reset'))
  throw Error(
    'Workspace already exists. To deliberately replace ALL business data, run npm run seed -- --reset.',
  );
const { data: users, error: usersError } = await db.auth.admin.listUsers({
  page: 1,
  perPage: 1000,
});
if (usersError) throw usersError;
for (const [alias, role, display_name, customer_id] of [
  ['manager', 'Manager', 'Olivia Bennett', null],
  ['cashier', 'Cashier', 'Emma Christensen', null],
  ['studio', 'Studio', 'Daniel Cole', null],
  ['customer', 'Customer', 'Olivia Bennett', 'c0'],
]) {
  const email = alias + '@sunbeams.demo';
  const prior = users.users.find((u) => u.email === email);
  const attrs = {
    email,
    password: 'Sunshine2026!',
    email_confirm: true,
    app_metadata: { role },
    user_metadata: { display_name },
  };
  const { data, error } = prior
    ? await db.auth.admin.updateUserById(prior.id, attrs)
    : await db.auth.admin.createUser(attrs);
  if (error) throw error;
  const { error: pe } = await db
    .from('profiles')
    .upsert({ id: data.user.id, role, customer_id, display_name });
  if (pe) throw pe;
}
const payload = createSeed();
const { error } = await db.rpc('erp_seed', { payload });
if (error) throw error;
console.log(
  `Seeded ${payload.items.length} items, ${payload.customers.length} customers, ${payload.docs.length} business documents, and four demo accounts. Shared password is documented in README.md.`,
);
