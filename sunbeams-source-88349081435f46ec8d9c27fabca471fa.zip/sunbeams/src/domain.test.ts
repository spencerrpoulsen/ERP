import { describe, it, expect, beforeAll } from 'vitest';
import { PGlite } from '@electric-sql/pglite';
import { readFileSync } from 'node:fs';
import { createSeed } from './seed';
import {
  type State,
  type Command,
  execute,
  onHand,
  available,
  allocated,
  balance,
  pnl,
  ordering,
  mrp,
  productionMetrics,
  round,
  sum,
  today,
  addDays,
  saleTotals,
  dayOf,
} from './domain';
export function fixture(): State {
  return {
    version: 1,
    items: [
      {
        id: 'raw',
        sku: 'RAW',
        barcode: 'SB-001',
        name: 'Blank',
        category: 'Components',
        type: 'component',
        cost: 5,
        price: 0,
        lead: 7,
        supplier: 'sup',
        rop: 1,
        description: '',
      },
      {
        id: 'finished',
        sku: 'TEE',
        barcode: 'SB-002',
        name: 'Sun Tee',
        category: 'Mom',
        type: 'manufactured',
        cost: 10,
        price: 30,
        lead: 2,
        supplier: 'sup',
        rop: 1,
        description: '',
      },
    ],
    suppliers: [
      {
        id: 'sup',
        name: 'Test Supplier',
        contact: 'Ada',
        email: 'ada@example.com',
        phone: '',
        address: 'Utah',
        lead: 7,
        terms: 'Net 15',
        moq: 1,
      },
    ],
    customers: [{ id: 'c0', name: 'Customer', email: 'c@example.com', phone: '', city: 'Provo' }],
    locations: [
      { id: 'provo', name: 'Store' },
      { id: 'studio', name: 'Studio' },
    ],
    bom: [{ parent: 'finished', item: 'raw', qty: 2 }],
    docs: [],
    moves: [
      {
        id: 'm1',
        date: '2025-01-01T00:00:00Z',
        item: 'raw',
        location: 'studio',
        qty: 100,
        cost: 5,
        value: 500,
        ref: 'OPEN',
        type: 'Opening',
        reason: 'OPEN',
        user: 'System',
      },
      {
        id: 'm2',
        date: '2025-01-01T00:00:00Z',
        item: 'finished',
        location: 'provo',
        qty: 10,
        cost: 10,
        value: 100,
        ref: 'OPEN',
        type: 'Opening',
        reason: 'OPEN',
        user: 'System',
      },
    ],
    journals: [
      {
        id: 'j1',
        date: '2025-01-01T00:00:00Z',
        ref: 'OPEN',
        memo: 'Opening',
        lines: [
          { account: 'Inventory', debit: 600, credit: 0 },
          { account: 'Owner Equity', debit: 0, credit: 600 },
        ],
      },
    ],
    settings: {
      taxRate: 0.1,
      orderCost: 35,
      holdingRate: 0.25,
      z: 1.65,
      reviewDays: 7,
      workingDays: 312,
      weightDelivery: 50,
      weightFill: 30,
      weightQuality: 20,
    },
    activity: [],
    registries: [],
  };
}
const sale = {
  type: 'sale',
  location: 'provo',
  lines: [{ item: 'finished', qty: 2 }],
  discount: 10,
};
function assertBalanced(s: State) {
  for (const j of s.journals)
    expect(Math.abs(sum(j.lines, (l) => l.debit - l.credit))).toBeLessThan(0.005);
  expect(balance(s, 'Inventory')).toBeCloseTo(
    sum(s.moves, (m) => m.value),
    2,
  );
}
describe('inventory and accounting', () => {
  it('sale relieves correct location, discounts, tax and COGS', () => {
    const s = execute(fixture(), sale);
    expect(onHand(s, 'finished', 'provo')).toBe(8);
    expect(onHand(s, 'raw', 'studio')).toBe(100);
    expect(pnl(s)).toMatchObject({ gross: 60, discount: 6, net: 54, cogs: 20, profit: 34 });
    expect(balance(s, 'Cash')).toBe(59.4);
    expect(balance(s, 'Sales Tax Payable')).toBe(-5.4);
    assertBalanced(s);
  });
  it('overselling is atomic and never changes input', () => {
    const s = fixture();
    expect(() => execute(s, { ...sale, lines: [{ item: 'finished', qty: 11 }] })).toThrow(
      'Insufficient',
    );
    expect(s.docs).toHaveLength(0);
    expect(onHand(s, 'finished')).toBe(10);
  });
  it('receipt updates WAC and AP using a partial quantity and terms', () => {
    let s = execute(fixture(), {
      type: 'po',
      supplier: 'sup',
      location: 'studio',
      lines: [{ item: 'raw', qty: 50, cost: 8 }],
    });
    const id = s.docs[0].id;
    s = execute(s, {
      type: 'receive',
      id,
      location: 'studio',
      lines: [{ item: 'raw', qty: 20 }],
      date: '2026-01-01',
    });
    expect(s.items[0].cost).toBe(5.5);
    expect(onHand(s, 'raw')).toBe(120);
    expect(balance(s, 'Accounts Payable')).toBe(-160);
    expect(s.docs[0].status).toBe('Partially Received');
    expect(s.docs[0].invoices[0].due).toBe('2026-01-16');
    assertBalanced(s);
    s = execute(s, { type: 'pay', id });
    expect(balance(s, 'Accounts Payable')).toBe(0);
    expect(() =>
      execute(s, { type: 'receive', id, location: 'studio', lines: [{ item: 'raw', qty: 31 }] }),
    ).toThrow('remaining');
  });
  it('production 10 started / 9 good absorbs exact BOM cost', () => {
    let s = execute(fixture(), {
      type: 'production',
      item: 'finished',
      qty: 10,
      location: 'studio',
      planned: today(),
    });
    const id = s.docs[0].id;
    s = execute(s, { type: 'issue', id });
    expect(onHand(s, 'raw', 'studio')).toBe(80);
    expect(balance(s, 'Work in Progress')).toBe(100);
    s = execute(s, { type: 'start', id, date: '2026-01-01T10:00:00Z' });
    s = execute(s, {
      type: 'complete',
      id,
      good: 9,
      scrap: 1,
      rework: 1,
      reason: 'MISALIGNED_PRINT',
      date: '2026-01-01T12:00:00Z',
    });
    expect(onHand(s, 'finished', 'studio')).toBe(9);
    expect(s.moves.slice(-1)[0].cost).toBeCloseTo(100 / 9, 8);
    expect(balance(s, 'Work in Progress')).toBe(0);
    expect(productionMetrics(s).fpy).toBe(90);
    expect(productionMetrics(s).firstTouch).toBe(80);
    expect(productionMetrics(s).cycle).toBe(2);
    assertBalanced(s);
  });
  it('quality return is not sellable and uses original cost', () => {
    let s = execute(fixture(), sale);
    const id = s.docs[0].id;
    s = execute(s, {
      type: 'return',
      id,
      lines: [{ item: 'finished', qty: 1 }],
      reason: 'QUALITY_DEFECT_SEAM',
    });
    expect(onHand(s, 'finished', 'provo')).toBe(8);
    expect(onHand(s, 'finished', 'provo', true)).toBe(1);
    expect(pnl(s).returns).toBe(27);
    expect(pnl(s).cogs).toBe(10);
    expect(balance(s, 'Cash')).toBe(29.7);
    assertBalanced(s);
    expect(() =>
      execute(s, {
        type: 'return',
        id,
        lines: [{ item: 'finished', qty: 2 }],
        reason: 'WRONG_SIZE',
      }),
    ).toThrow('more than');
  });
  it('exchange rolls back refund if replacement is unavailable', () => {
    const s = execute(fixture(), sale);
    expect(() =>
      execute(s, {
        type: 'return',
        id: s.docs[0].id,
        reason: 'WRONG_SIZE',
        lines: [{ item: 'finished', qty: 1 }],
        replacements: [{ item: 'finished', qty: 50 }],
      }),
    ).toThrow('Insufficient');
    expect(s.docs[0].lines[0].returned).toBe(0);
    assertBalanced(s);
  });
  it('partial returns cumulatively reverse every original cent', () => {
    let s = execute(fixture(), {
      ...sale,
      lines: [{ item: 'finished', qty: 3 }],
      discount: 1,
      discountType: 'dollar',
    });
    const id = s.docs[0].id;
    for (let n = 0; n < 3; n++)
      s = execute(s, {
        type: 'return',
        id,
        reason: 'WRONG_SIZE',
        lines: [{ item: 'finished', qty: 1 }],
      });
    expect(pnl(s).net).toBe(0);
    expect(balance(s, 'Sales Tax Payable')).toBe(0);
    expect(balance(s, 'Cash')).toBe(0);
    assertBalanced(s);
  });
  it('reservations protect stock; fulfillment nets its own reservation once', () => {
    let s = execute(fixture(), {
      type: 'order',
      location: 'provo',
      customer: 'c0',
      lines: [{ item: 'finished', qty: 8 }],
    });
    expect(allocated(s, 'finished', 'provo')).toBe(8);
    expect(available(s, 'finished', 'provo')).toBe(2);
    expect(() => execute(s, sale)).not.toThrow();
    expect(() => execute(s, { ...sale, lines: [{ item: 'finished', qty: 3 }] })).toThrow(
      'Insufficient',
    );
    s = execute(s, { type: 'fulfill', id: s.docs[0].id });
    expect(onHand(s, 'finished', 'provo')).toBe(2);
    expect(allocated(s, 'finished')).toBe(0);
    assertBalanced(s);
  });
  it('transfers preserve valuation and adjustments post shrinkage', () => {
    let s = execute(fixture(), {
      type: 'transfer',
      item: 'finished',
      qty: 3,
      from: 'provo',
      to: 'studio',
    });
    expect(onHand(s, 'finished')).toBe(10);
    expect(balance(s, 'Inventory')).toBe(600);
    s = execute(s, {
      type: 'adjust',
      item: 'finished',
      qty: -2,
      location: 'studio',
      reason: 'DAMAGED',
    });
    expect(balance(s, 'Shrinkage')).toBe(20);
    assertBalanced(s);
  });
  it('EOQ and ROP respond to settings from stored usage', () => {
    let s = execute(fixture(), sale);
    const before = ordering(s, 'finished');
    s = execute(s, { type: 'settings', values: { orderCost: 140, z: 3.3 } });
    const after = ordering(s, 'finished');
    expect(after.eoq).toBeCloseTo(before.eoq * 2, 6);
    expect(after.safety).toBeCloseTo(before.safety * 2, 6);
    expect(after.rop).toBeGreaterThan(before.rop);
  });
  it('MRP nets on-hand once and explodes net parent need', () => {
    let s = execute(fixture(), {
      type: 'order',
      location: 'provo',
      customer: 'c0',
      lines: [{ item: 'finished', qty: 70 }],
      requested: addDays(today(), 10),
    });
    const rows = mrp(s);
    const parent = rows.find((x) => x.item === 'finished')!,
      raw = rows.find((x) => x.item === 'raw')!;
    expect(sum(parent.weeks, (w) => w.net)).toBe(60);
    expect(sum(raw.weeks, (w) => w.gross)).toBe(120);
    expect(sum(raw.weeks, (w) => w.net)).toBe(20);
    expect(raw.weeks.find((w) => w.net)!.release).toBe(
      addDays(raw.weeks.find((w) => w.net)!.date, -7),
    );
  });
  it('unauthorized role cannot mutate financial or inventory data', () => {
    expect(() =>
      execute(
        fixture(),
        { type: 'adjust', item: 'raw', qty: 1, reason: 'FOUND', location: 'studio' },
        'Customer',
        'Customer',
      ),
    ).toThrow('Customer');
    expect(() =>
      execute(fixture(), { type: 'settings', values: { taxRate: 0 } }, 'Emma', 'Cashier'),
    ).toThrow('Manager');
  });
});
describe('historical seed', () => {
  let s: State;
  beforeAll(() => {
    s = createSeed();
  }, 60000);
  it('has 33 items, 11 parent BOMs, 15 customers, all roles of documents and 365 selling days', () => {
    expect(s.items.length).toBe(33);
    expect(new Set(s.bom.map((b) => b.parent)).size).toBe(11);
    expect(s.customers).toHaveLength(15);
    expect(s.docs.filter((d) => d.kind === 'sale').length).toBeGreaterThan(1800);
    expect(s.docs.some((d) => d.kind === 'sale' && d.date.slice(0, 10) === today())).toBe(true);
    console.log('Seed size MB', round(JSON.stringify(s).length / 1048576), 'docs', s.docs.length);
  });
  it('all historical entries reconcile and stock never goes negative', () => {
    assertBalanced(s);
    for (const i of s.items)
      for (const l of s.locations) expect(onHand(s, i.id, l.id)).toBeGreaterThanOrEqual(0);
  });
  it('a real demo sale can commit against the full seed', () => {
    const i = s.items.find((i) => i.price > 0 && available(s, i.id, 'provo') > 1)!;
    const next = execute(s, { type: 'sale', location: 'provo', lines: [{ item: i.id, qty: 1 }] });
    expect(onHand(next, i.id, 'provo')).toBe(onHand(s, i.id, 'provo') - 1);
    assertBalanced(next);
  });
});
describe('Postgres RPC parity', () => {
  let db: PGlite;
  beforeAll(async () => {
    db = new PGlite();
    await db.exec(
      `create schema auth; create table auth.users(id uuid primary key); create function auth.uid() returns uuid language sql as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;create function auth.role() returns text language sql as $$select 'service_role'::text$$;create role anon;create role authenticated;create role service_role;`,
    );
    await db.exec(readFileSync('supabase/migrations/001_sunbeams.sql', 'utf8'));
  }, 60000);
  const sql = async (s: State, c: Command) => {
    const result = await db.query<{ s: State }>(
      'select public.erp_apply($1::jsonb,$2::jsonb,$3,$4) s',
      [JSON.stringify(s), JSON.stringify(c), 'Olivia Bennett', 'Manager'],
    );
    return result.rows[0].s;
  };
  it('migration compiles and sale matches TS accounting', async () => {
    const a = await sql(fixture(), sale),
      b = execute(fixture(), sale);
    expect(a.docs[0].total).toBe(b.docs[0].total);
    expect(pnl(a)).toEqual(pnl(b));
    expect(onHand(a, 'finished')).toBe(8);
    assertBalanced(a);
  });
  it('partial receipt updates WAC and terms', async () => {
    let s = await sql(fixture(), {
      type: 'po',
      supplier: 'sup',
      location: 'studio',
      lines: [{ item: 'raw', qty: 50, cost: 8 }],
    });
    s = await sql(s, {
      type: 'receive',
      id: s.docs[0].id,
      location: 'studio',
      lines: [{ item: 'raw', qty: 20 }],
      date: '2026-01-01',
    });
    expect(s.items[0].cost).toBe(5.5);
    expect(s.docs[0].invoices[0].due).toBe('2026-01-16');
    assertBalanced(s);
  });
  it('production completion balances WIP and inventory', async () => {
    let s = await sql(fixture(), {
      type: 'production',
      location: 'studio',
      item: 'finished',
      qty: 10,
    });
    const id = s.docs[0].id;
    for (const c of [
      { type: 'issue', id },
      { type: 'start', id },
      { type: 'complete', id, good: 9, scrap: 1, rework: 1, reason: 'FABRIC_FLAW' },
    ])
      s = await sql(s, c);
    expect(onHand(s, 'raw')).toBe(80);
    expect(onHand(s, 'finished')).toBe(19);
    expect(balance(s, 'Work in Progress')).toBe(0);
    assertBalanced(s);
  });
  it('quality return mirrors original discounted revenue/cost', async () => {
    let s = await sql(fixture(), sale);
    s = await sql(s, {
      type: 'return',
      id: s.docs[0].id,
      lines: [{ item: 'finished', qty: 1 }],
      reason: 'QUALITY_DEFECT_SEAM',
    });
    expect(onHand(s, 'finished', 'provo')).toBe(8);
    expect(onHand(s, 'finished', 'provo', true)).toBe(1);
    expect(pnl(s).net).toBe(27);
    assertBalanced(s);
  });
  it('projection tables reconcile to JSON aggregate', async () => {
    const s = await sql(fixture(), sale);
    await db.query('select public.erp_project($1::jsonb)', [JSON.stringify(s)]);
    const r = await db.query<{ d: number }>(
      'select sum(debit-credit)::float8 d from public.journal_lines',
    );
    expect(r.rows[0].d).toBeCloseTo(0, 5);
    const count = await db.query<{ n: number }>(
      'select count(*)::integer n from public.inventory_transactions',
    );
    expect(count.rows[0].n).toBe(3);
  });
  it('SQL rejects role escalation and overselling', async () => {
    await expect(
      sql(fixture(), { ...sale, lines: [{ item: 'finished', qty: 30 }] }),
    ).rejects.toThrow('Insufficient');
    await expect(
      db.query('select public.erp_apply($1::jsonb,$2::jsonb,$3,$4)', [
        JSON.stringify(fixture()),
        JSON.stringify({ type: 'settings', values: { taxRate: 0 } }),
        'Customer',
        'Customer',
      ]),
    ).rejects.toThrow('Customer');
  });

  it('FIFO reservations reserve only physical stock and protect older orders', async () => {
    let s = await sql(fixture(), {
      type: 'order',
      location: 'provo',
      customer: 'c0',
      lines: [{ item: 'finished', qty: 8 }],
    });
    s = await sql(s, {
      type: 'order',
      location: 'provo',
      customer: 'c0',
      lines: [{ item: 'finished', qty: 8 }],
    });
    expect(allocated(s, 'finished', 'provo')).toBe(10);
    s = await sql(s, { type: 'fulfill', id: s.docs[0].id });
    expect(onHand(s, 'finished', 'provo')).toBe(2);
    expect(s.docs[0].status).toBe('Fulfilled');
    assertBalanced(s);
  });
  it('saved seasonal demand enters MRP without doubling confirmed demand', async () => {
    let s = await sql(fixture(), {
      type: 'forecast',
      lines: [{ item: 'finished', date: today(), qty: 15 }],
    });
    expect(s.forecasts?.[0].qty).toBe(15);
    expect(sum(mrp(s).find((x) => x.item === 'finished')!.weeks, (w) => w.net)).toBe(5);
    s = execute(s, {
      type: 'order',
      location: 'provo',
      customer: 'c0',
      lines: [{ item: 'finished', qty: 12 }],
      requested: today(),
    });
    expect(sum(mrp(s).find((x) => x.item === 'finished')!.weeks, (w) => w.net)).toBe(5);
  });
  it('real RPC enforces customer isolation, sanitizes pricing and rolls back failed actions', async () => {
    const manager = '00000000-0000-0000-0000-000000000001',
      customer = '00000000-0000-0000-0000-000000000002';
    await db.exec(
      `insert into auth.users values('${manager}'),('${customer}');insert into profiles values('${manager}','Manager',null,'Olivia Bennett'),('${customer}','Customer','c0','Customer');grant usage on schema auth to authenticated;`,
    );
    await db.query('select erp_seed($1::jsonb)', [JSON.stringify(fixture())]);
    await db.query("select set_config('request.jwt.claim.sub',$1,false)", [manager]);
    await db.exec('set role authenticated');
    await db.query('select erp_command($1::jsonb)', [JSON.stringify(sale)]);
    const before = (await db.query<{ s: State }>('select erp_snapshot() s')).rows[0].s;
    await expect(
      db.query('select erp_command($1::jsonb)', [
        JSON.stringify({
          type: 'return',
          id: before.docs[0].id,
          reason: 'WRONG_SIZE',
          lines: [{ item: 'finished', qty: 1 }],
          replacements: [{ item: 'finished', qty: 100 }],
        }),
      ]),
    ).rejects.toThrow('Insufficient');
    expect((await db.query<{ s: State }>('select erp_snapshot() s')).rows[0].s).toEqual(before);
    await db.query("select set_config('request.jwt.claim.sub',$1,false)", [customer]);
    expect((await db.query('select * from erp_state')).rows.length).toBe(0);
    expect((await db.query('select * from journal_lines')).rows.length).toBe(0);
    expect((await db.query('select * from profiles')).rows.length).toBe(1);
    const portal = (await db.query<{ s: State }>('select erp_snapshot() s')).rows[0].s;
    expect(portal.journals).toHaveLength(0);
    expect(portal.docs).toHaveLength(0);
    expect(portal.items.every((i) => i.cost === 0)).toBe(true);
    await expect(db.query('select erp_command($1::jsonb)', [JSON.stringify(sale)])).rejects.toThrow(
      'Customer',
    );
    await db.query('select erp_command($1::jsonb)', [
      JSON.stringify({
        type: 'order',
        location: 'provo',
        customer: 'someone-else',
        lines: [{ item: 'finished', qty: 1, price: 0, discount: 100 }],
      }),
    ]);
    const own = (await db.query<{ s: State }>('select erp_snapshot() s')).rows[0].s;
    expect(own.docs[0].customer).toBe('c0');
    expect(own.docs[0].total).toBe(33);
    expect(own.docs[0].lines[0].price).toBe(30);
    await db.exec('reset role');
  });
});

describe('course demo edge cases', () => {
  it('Denver date boundaries keep evening sales in the right business day', () => {
    const date = '2026-11-17T01:00:00Z';
    expect(dayOf(date)).toBe('2026-11-16');
    const s = execute(fixture(), { ...sale, date });
    expect(pnl(s, '2026-11-16', '2026-11-16').net).toBe(54);
    expect(pnl(s, '2026-11-17', '2026-11-17').net).toBe(0);
  });
  it('sales order quote stays consistent when tax settings change before fulfillment', () => {
    let s = execute(fixture(), {
      type: 'order',
      customer: 'c0',
      location: 'provo',
      lines: [{ item: 'finished', qty: 1 }],
    });
    const id = s.docs[0].id,
      total = s.docs[0].total;
    s = execute(s, { type: 'settings', values: { taxRate: 0.2 } });
    s = execute(s, { type: 'fulfill', id });
    expect(s.docs.find((d) => d.kind === 'sale')!.total).toBe(total);
    assertBalanced(s);
  });
  it('ten actual matching-set BOMs consume exact components and nine good units absorb scrap', () => {
    let s = createSeed();
    const id = 'i28',
      bom = s.bom.filter((b) => b.parent === id);
    for (const b of bom) {
      const missing = Math.max(0, b.qty * 10 - onHand(s, b.item, 'studio'));
      if (missing)
        s = execute(s, {
          type: 'adjust',
          item: b.item,
          location: 'studio',
          qty: missing,
          reason: 'FOUND',
        });
    }
    const before = Object.fromEntries(bom.map((b) => [b.item, onHand(s, b.item, 'studio')]));
    const cost = round(
      sum(bom, (b) => round(b.qty * 10 * s.items.find((i) => i.id === b.item)!.cost)),
    );
    s = execute(s, { type: 'production', item: id, qty: 10, location: 'studio' });
    const p = s.docs.slice(-1)[0];
    s = execute(s, { type: 'issue', id: p.id });
    for (const b of bom) expect(onHand(s, b.item, 'studio')).toBe(before[b.item] - b.qty * 10);
    s = execute(s, { type: 'start', id: p.id });
    s = execute(s, {
      type: 'complete',
      id: p.id,
      good: 9,
      scrap: 1,
      rework: 0,
      reason: 'QUALITY_ISSUE',
    });
    expect(s.moves.slice(-1)[0].qty).toBe(9);
    expect(s.moves.slice(-1)[0].cost).toBeCloseTo(cost / 9, 8);
    assertBalanced(s);
  }, 15000);
});
