import LZString from 'lz-string';
import { createClient } from '@supabase/supabase-js';
import { createSeed } from './seed';
import { execute, type State, type Command, type Role } from './domain';
const url = import.meta.env.VITE_SUPABASE_URL,
  key = import.meta.env.VITE_SUPABASE_ANON_KEY;
export const supabase = url && key ? createClient(url, key) : null;
export const demo = !supabase;
const KEY = 'sunbeams.erp.v1';
let state: State;
const listeners = new Set<() => void>();
export function loadDemo() {
  if (!state) {
    try {
      const raw = localStorage.getItem(KEY);
      state = raw ? JSON.parse(LZString.decompressFromUTF16(raw) || raw) : createSeed();
    } catch {
      state = createSeed();
    }
  }
  return state;
}
export const snapshot = () => state;
export const subscribe = (f: () => void) => {
  listeners.add(f);
  return () => {
    listeners.delete(f);
  };
};
function notify() {
  listeners.forEach((f) => f());
}
export async function refresh() {
  if (supabase) {
    const { data, error } = await supabase.rpc('erp_snapshot');
    if (error) throw error;
    state = data;
    notify();
  } else {
    loadDemo();
    notify();
  }
}
export async function dispatch(command: Command, user: string, role: Role) {
  if (supabase) {
    const { error } = await supabase.rpc('erp_command', { command });
    if (error) throw error;
    await refresh();
  } else {
    const raw = localStorage.getItem(KEY);
    const latest = raw ? JSON.parse(LZString.decompressFromUTF16(raw) || raw) : state;
    const next = execute(latest, command, user, role);
    localStorage.setItem(KEY, LZString.compressToUTF16(JSON.stringify(next)));
    state = next;
    notify();
  }
  return state;
}
export function connect() {
  if (supabase) {
    const ch = supabase
      .channel('erp-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'erp_notices' }, () => {
        refresh().catch(() => {});
      })
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }
  const handler = (e: StorageEvent) => {
    if (e.key === KEY && e.newValue) {
      state = JSON.parse(LZString.decompressFromUTF16(e.newValue) || e.newValue);
      notify();
    }
  };
  window.addEventListener('storage', handler);
  return () => window.removeEventListener('storage', handler);
}
export function resetDemo() {
  localStorage.removeItem(KEY);
  state = createSeed();
  localStorage.setItem(KEY, LZString.compressToUTF16(JSON.stringify(state)));
  notify();
}
export function csv(name: string, rows: Record<string, unknown>[]) {
  if (!rows.length) return;
  const keys = Object.keys(rows[0]),
    esc = (v: unknown) => {
      const t = String(v ?? '');
      return (
        '"' +
        (typeof v === 'string' && /^[=+@\-]/.test(t) ? "'" : '') +
        t.replaceAll('"', '""') +
        '"'
      );
    };
  const b = new Blob(
    [
      '\uFEFF' +
        [keys.map(esc).join(','), ...rows.map((r) => keys.map((k) => esc(r[k])).join(','))].join(
          '\r\n',
        ),
    ],
    { type: 'text/csv;charset=utf-8' },
  );
  const a = document.createElement('a');
  a.href = URL.createObjectURL(b);
  a.download = name + '.csv';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
