// @vitest-environment happy-dom
import React from 'react';
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, fireEvent, waitFor, cleanup, within } from '@testing-library/react';
import App from './App';
import { snapshot } from './store';
import { onHand, pnl, today, available } from './domain';
vi.mock('recharts', () => {
  const Box = ({ children }: any) => <svg>{children}</svg>;
  return Object.fromEntries(
    [
      'ResponsiveContainer',
      'AreaChart',
      'Area',
      'XAxis',
      'YAxis',
      'CartesianGrid',
      'Tooltip',
      'BarChart',
      'Bar',
      'Cell',
      'PieChart',
      'Pie',
    ].map((k) => [k, Box]),
  );
});
vi.mock('jsbarcode', () => ({ default: vi.fn() }));
afterEach(cleanup);
async function ready() {
  render(<App />);
  await screen.findByRole('heading', { name: /A sunny day at Sunbeams/ });
}
describe('working screens', () => {
  it('renders all staff modules without runtime failures', async () => {
    await ready();
    for (const page of [
      'Inventory',
      'Sales orders',
      'Purchasing',
      'Suppliers',
      'Print Studio',
      'Material planning',
      'Reports',
      'Match Keeper',
      'Seasonal planner',
      'Customer storefront',
      'Barcode labels',
      'Settings',
      'About this system',
      'Returns & exchanges',
      'Point of sale',
    ]) {
      fireEvent.click(
        within(screen.getByRole('navigation')).getByRole('button', {
          name: new RegExp('^' + page.replaceAll('&', '\\&')),
        }),
      );
      await screen.findByRole('heading', { level: 1, name: page });
      expect(document.querySelector('[role="alert"]')).toBe(null);
    }
  }, 30000);
  it('completes an actual checkout, shows receipt, updates stock and ledger', async () => {
    await ready();
    const before = snapshot();
    const i = before.items.find((i) => i.price > 0 && available(before, i.id, 'provo') > 0)!;
    const old = onHand(before, i.id, 'provo'),
      rev = pnl(before, today(), today()).net;
    fireEvent.click(screen.getByRole('button', { name: 'Point of sale' }));
    const card = screen.getByRole('heading', { name: i.name }).closest('button')!;
    fireEvent.click(card);
    fireEvent.click(screen.getByRole('button', { name: /Complete sale/ }));
    await screen.findByRole('dialog', { name: 'Receipt' });
    expect(onHand(snapshot(), i.id, 'provo')).toBe(old - 1);
    expect(pnl(snapshot(), today(), today()).net).toBe(rev + i.price);
    expect(localStorage.getItem('sunbeams.erp.v1')!.length).toBeLessThan(1500000);
  }, 15000);
  it('inventory transfer form accepts a wedge barcode and increments quantity', async () => {
    await ready();
    fireEvent.click(screen.getByRole('button', { name: 'Inventory' }));
    fireEvent.click(screen.getByRole('button', { name: 'Transfer' }));
    const d = await screen.findByRole('dialog', { name: 'Transfer inventory' });
    const scan = within(d).getByPlaceholderText('Scan a barcode, then Enter…');
    fireEvent.change(scan, { target: { value: 'SB-000023' } });
    fireEvent.keyDown(scan, { key: 'Enter' });
    expect((within(d).getByLabelText('Item') as HTMLSelectElement).value).toBe('i22');
    expect((within(d).getByLabelText('Quantity') as HTMLInputElement).value).toBe('1');
  }, 15000);
  it('customer role shows storefront and hides staff navigation', async () => {
    await ready();
    fireEvent.click(screen.getByRole('button', { name: /Olivia Bennett Owner & Manager/ }));
    await screen.findByRole('heading', { name: 'A little sunshine starts here.' });
    fireEvent.click(screen.getByRole('button', { name: 'Customer' }));
    await screen.findByRole('heading', { level: 1, name: 'Customer storefront' });
    expect(screen.queryByRole('button', { name: 'Purchasing' })).toBeNull();
    expect(screen.queryByRole('button', { name: 'Point of sale' })).toBeNull();
  }, 15000);
});
