import {
  useEffect,
  useState,
  useSyncExternalStore,
  useRef,
  type ReactNode,
  type FormEvent,
} from 'react';
import {
  Sun,
  LayoutDashboard,
  ShoppingBag,
  Package,
  ArrowLeftRight,
  Factory,
  Truck,
  Users,
  ChartNoAxesCombined,
  Settings,
  BookOpen,
  ScanLine,
  Plus,
  Search,
  ArrowUpRight,
  ArrowRight,
  Download,
  ChevronDown,
  ChevronRight,
  ShoppingCart,
  X,
  Check,
  AlertTriangle,
  Clock,
  MapPin,
  Printer,
  LogOut,
  Heart,
  CalendarDays,
  RefreshCw,
  Menu,
  Bell,
  CheckCircle2,
  Leaf,
  Minus,
  Trash2,
  Camera,
  BarChart3,
  ReceiptText,
  Layers,
  ExternalLink,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie,
} from 'recharts';
import JsBarcode from 'jsbarcode';
import {
  type State,
  type Role,
  type Item,
  type Doc,
  type Line,
  type Command,
  dayOf,
  demand,
  onHand,
  available,
  allocated,
  reserved,
  backordered,
  onOrder,
  invValue,
  pnl,
  ordering,
  scorecard,
  mrp,
  productionMetrics,
  turnover,
  balance,
  sum,
  today,
  addDays,
  itemBy,
  expectedDate,
  saleTotals,
  round,
} from './domain';
import {
  demo,
  supabase,
  refresh,
  subscribe,
  snapshot,
  loadDemo,
  dispatch,
  connect,
  csv,
  resetDemo,
} from './store';
const money = (v: number) =>
  new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 2,
  }).format(v);
const num = (v: number, d = 0) =>
  new Intl.NumberFormat('en-US', { maximumFractionDigits: d }).format(v);
const pct = (v: number) => num(v, 1) + '%';
const fmtDate = (d: string) =>
  new Date(dayOf(d) + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
const names: Record<Role, string> = {
  Manager: 'Olivia Bennett',
  Cashier: 'Emma Christensen',
  Studio: 'Daniel Cole',
  Customer: 'Olivia Bennett',
};
const groups = [
  {
    label: 'WORKSPACE',
    items: [
      ['Overview', LayoutDashboard],
      ['Point of sale', ScanLine],
      ['Sales orders', ShoppingBag],
      ['Returns & exchanges', ArrowLeftRight],
    ],
  },
  {
    label: 'OPERATIONS',
    items: [
      ['Inventory', Package],
      ['Purchasing', Truck],
      ['Suppliers', Users],
      ['Print Studio', Factory],
      ['Material planning', Layers],
    ],
  },
  {
    label: 'INSIGHTS',
    items: [
      ['Reports', ChartNoAxesCombined],
      ['Match Keeper', Heart],
      ['Seasonal planner', CalendarDays],
    ],
  },
  {
    label: 'MORE',
    items: [
      ['Customer storefront', ShoppingCart],
      ['Barcode labels', ScanLine],
      ['Settings', Settings],
      ['About this system', BookOpen],
    ],
  },
] as const;
const details: Record<string, string> = {
  Overview: 'A little clarity for your growing business.',
  'Point of sale': 'Every little purchase, perfectly connected.',
  Inventory: 'The right pieces, in the right place.',
  'Sales orders': 'From their first click to a happy pickup.',
  'Returns & exchanges': 'Thoughtful service, with every detail accounted for.',
  Purchasing: 'Keep your shelves—and your sunshine—stocked.',
  Suppliers: 'Good partnerships make good things possible.',
  'Print Studio': 'Where little details become something special.',
  'Material planning': 'A clear plan for what comes next.',
  Reports: 'The numbers behind your sunny days.',
  'Match Keeper': 'Because the best things come in pairs.',
  'Seasonal planner': 'Make room for your next big moment.',
  'Customer storefront': 'Made for the moments you share.',
  'Barcode labels': 'Little labels. A more connected workspace.',
  Settings: 'Make Sunbeams work your way.',
  'About this system': 'Built with care. Connected by design.',
};
function Badge({ children, tone = '' }: { children: ReactNode; tone?: string }) {
  return <span className={'badge ' + tone}>{children}</span>;
}
function Empty({ text = 'Nothing here yet.' }: { text?: string }) {
  return (
    <div className="empty">
      <Sun size={32} />
      <h3>{text}</h3>
      <p>Your next little step will show up here.</p>
    </div>
  );
}
function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="field">
      <span>{label}</span>
      {children}
    </label>
  );
}
function Metric({
  label,
  value,
  sub,
  icon: Icon = Sun,
  tone = '',
}: {
  label: string;
  value: ReactNode;
  sub: ReactNode;
  icon?: any;
  tone?: string;
}) {
  return (
    <div className="metric">
      <div className="metric-label">
        {label}
        <span className={'metric-icon ' + tone}>
          <Icon size={17} />
        </span>
      </div>
      <div className="metric-value">{value}</div>
      <div className="metric-sub">{sub}</div>
    </div>
  );
}
function ProductArt({ item, small = false }: { item: Item; small?: boolean }) {
  const baby = item.category === 'Baby' || /Baby|Onesie|Bud/.test(item.name),
    sage = /Sage|Bloom|Bud/.test(item.name),
    kit = item.type === 'kit',
    color = sage ? '#adba9c' : '#f1dfbf';
  return (
    <div
      className={
        'product-art ' + (small ? 'small' : '') + (' art-' + item.category.replace(' ', '-'))
      }
    >
      <svg viewBox="0 0 180 150" aria-hidden="true">
        <ellipse cx="92" cy="133" rx="49" ry="5" fill="#584838" opacity=".06" />
        {kit ? (
          <>
            <path d="M32 55L90 34l58 21-58 23z" fill="#e8c89e" />
            <path d="M32 55v53l58 27V78z" fill="#dab486" />
            <path d="M90 78l58-23v54l-58 26z" fill="#e8c89e" />
            <path d="M74 40l18 5 17 78-19 12V78z" fill="#faf0da" />
            <circle cx="117" cy="88" r="12" fill="#f2ba48" />
            <path d="M117 82v12m-6-6h12" stroke="#fff8ec" strokeWidth="2" />
          </>
        ) : item.type === 'component' ? (
          <>
            <rect x="38" y="36" width="104" height="81" rx="7" fill={color} />
            <path
              d="M48 46h84v61H48z"
              fill="none"
              stroke="#fff8ec"
              strokeWidth="2"
              strokeDasharray="4 4"
            />
            <circle cx="90" cy="76" r="17" fill="#e6b64d" opacity=".8" />
          </>
        ) : item.category === 'Accessories' ? (
          <>
            <path d="M48 79q8-60 43-60t43 60z" fill="#d4b084" />
            <ellipse cx="91" cy="85" rx="68" ry="18" fill="#e3c79e" />
            <path d="M49 69q42 18 83 0" fill="none" stroke="#a6b392" strokeWidth="10" />
          </>
        ) : (
          <>
            <path
              d={
                baby
                  ? 'M64 29l-28 19 15 23 12-9v32l12 31h30l12-31V62l12 9 15-23-28-19-15 8H80z'
                  : 'M62 27L26 47l17 29 17-10v61h61V66l16 10 17-29-36-20-16 9H79z'
              }
              fill={color}
              stroke="#d7c9b3"
              strokeWidth="1.2"
            />
            <path d="M78 30q12 18 25 0" fill="none" stroke="#d4c3a8" strokeWidth="3" />
            <g transform="translate(91 77)">
              <circle r="10" fill="#dca844" />
              {Array.from({ length: 8 }, (_, i) => (
                <path
                  key={i}
                  d="M0 -15v-5"
                  transform={'rotate(' + i * 45 + ')'}
                  stroke="#dca844"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              ))}
            </g>
            <text
              x="91"
              y="101"
              textAnchor="middle"
              fill="#8d7047"
              fontSize="7"
              fontFamily="Georgia"
            >
              {baby ? 'little sunbeam' : 'mama sun'}
            </text>
          </>
        )}
      </svg>
    </div>
  );
}
function Barcode({ value }: { value: string }) {
  const ref = useRef<SVGSVGElement>(null);
  useEffect(() => {
    if (ref.current)
      JsBarcode(ref.current, value, {
        format: 'CODE128',
        height: 36,
        width: 1.3,
        fontSize: 11,
        margin: 8,
        background: '#ffffff',
      });
  }, [value]);
  return <svg ref={ref} />;
}
function CameraScan({ onScan, onClose }: { onScan: (v: string) => void; onClose: () => void }) {
  const video = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState('');
  useEffect(() => {
    let control: { stop: () => void } | undefined;
    let cancelled = false;
    import('@zxing/browser')
      .then(({ BrowserMultiFormatReader }) =>
        new BrowserMultiFormatReader().decodeFromVideoDevice(
          undefined,
          video.current!,
          (result, _error, c) => {
            if (result && !cancelled) {
              c.stop();
              onScan(result.getText());
              onClose();
            }
          },
        ),
      )
      .then((c) => {
        if (cancelled) c.stop();
        else control = c;
      })
      .catch((e) =>
        setError(
          'Camera unavailable. Allow camera access, or use the barcode input / USB scanner. ' +
            e.message,
        ),
      );
    return () => {
      cancelled = true;
      control?.stop();
    };
  }, []);
  return (
    <div>
      <video ref={video} className="camera" />
      {error && <p className="error">{error}</p>}
      <p>Point your camera at a Code 128 label.</p>
    </div>
  );
}
function Table({ heads, children }: { heads: string[]; children: ReactNode }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            {heads.map((h) => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}
function Modal({
  title,
  children,
  onClose,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
}) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', h);
    const prior = document.activeElement as HTMLElement;
    return () => {
      window.removeEventListener('keydown', h);
      prior?.focus();
    };
  }, []);
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <section className="modal" role="dialog" aria-modal="true" aria-label={title}>
        <div className="modal-head">
          <h2>{title}</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Close dialog">
            <X size={20} />
          </button>
        </div>
        {children}
      </section>
    </div>
  );
}
function Receipt({ s, d }: { s: State; d: Doc }) {
  return (
    <div className="receipt print-area">
      <Sun size={32} />
      <h2>sunbeams</h2>
      <p>Little moments. Matching memories.</p>
      <hr />
      <b>
        {d.kind === 'po' ? 'PURCHASE ORDER' : 'SALES RECEIPT'} · {d.id}
      </b>
      <p>
        {new Date(d.date).toLocaleString('en-US', { timeZone: 'America/Denver' })}
        <br />
        {s.locations.find((l) => l.id === d.location)?.name}
        <br />
        {d.history[0].user}
      </p>
      {d.supplier && (
        <p>
          {s.suppliers.find((x) => x.id === d.supplier)?.name}
          <br />
          Expected: {fmtDate(d.expected)}
        </p>
      )}
      <hr />
      {d.lines.map((l) => (
        <div className="receipt-line" key={l.item}>
          <span>
            {itemBy(s, l.item).name}
            <small>
              {l.qty} × {money(l.price ?? l.cost ?? itemBy(s, l.item).price)}
            </small>
          </span>
          <b>{money(l.net ?? l.qty * (l.cost || l.price || 0))}</b>
        </div>
      ))}
      {d.kind !== 'po' && (
        <>
          <div className="receipt-line">
            <span>Discounts</span>
            <span>−{money(d.discount || 0)}</span>
          </div>
          <div className="receipt-line">
            <span>Sales tax</span>
            <span>{money(d.tax || 0)}</span>
          </div>
        </>
      )}
      <hr />
      <div className="receipt-line total">
        <b>Total</b>
        <b>{money(d.total)}</b>
      </div>
      <p>
        {d.kind === 'po'
          ? 'Please include this PO number on your invoice.'
          : 'Returns within 30 days with receipt. Quality concerns? We’re here to help.'}
      </p>
      <Barcode value={d.id} />
      <button className="btn primary no-print" onClick={() => window.print()}>
        <Printer size={16} /> Print {d.kind === 'po' ? 'purchase order' : 'receipt'}
      </button>
    </div>
  );
}
export default function App() {
  const s = useSyncExternalStore(subscribe, snapshot, snapshot);
  const [page, setPage] = useState('Overview'),
    [role, setRole] = useState<Role>('Manager'),
    [logged, setLogged] = useState(demo),
    [loading, setLoading] = useState(true),
    [error, setError] = useState(''),
    [toast, setToast] = useState(''),
    [busy, setBusy] = useState(false),
    [mobile, setMobile] = useState(false);
  const [modal, setModal] = useState<{ title: string; body: ReactNode } | null>(null);
  const [loc, setLoc] = useState('all'),
    [range, setRange] = useState('30'),
    [bucket, setBucket] = useState('day'),
    [search, setSearch] = useState('');
  useEffect(() => {
    refresh()
      .then(() => setLoading(false))
      .catch((e) => {
        setError(e.message);
        setLoading(false);
      });
    const stop = connect();
    if (supabase) {
      supabase.auth.getSession().then(({ data }) => setLogged(!!data.session));
      const { data } = supabase.auth.onAuthStateChange((_event, session) => {
        setLogged(!!session);
        if (session) {
          setRole(session.user.app_metadata.role || 'Customer');
          refresh().catch((e) => setError(e.message));
        }
      });
      return () => {
        stop();
        data.subscription.unsubscribe();
      };
    }
    return stop;
  }, []);
  useEffect(() => {
    if (role === 'Customer') setPage('Customer storefront');
  }, [role]);
  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(''), 4500);
      return () => clearTimeout(t);
    }
  }, [toast]);
  const go = (p: string) => {
    setPage(p);
    setSearch('');
    setMobile(false);
  };
  async function run(c: Command, close = true) {
    try {
      setBusy(true);
      await dispatch(c, names[role], role);
      setToast('Saved. Everything is up to date.');
      if (close) setModal(null);
      return true;
    } catch (e) {
      setError((e as Error).message);
      return false;
    } finally {
      setBusy(false);
    }
  }
  const form = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    return Object.fromEntries(new FormData(e.currentTarget).entries()) as Record<string, string>;
  };
  const place = (id: string) => s?.locations.find((x) => x.id === id)?.name || id;
  const button = (label: string, action: () => void, primary = false, Icon: any = Plus) => (
    <button className={'btn ' + (primary ? 'primary' : '')} onClick={action}>
      <Icon size={16} />
      {label}
    </button>
  );
  const openReceipt = (d: Doc) =>
    setModal({
      title: d.kind === 'po' ? 'Purchase order' : 'Receipt',
      body: <Receipt s={s} d={d} />,
    });
  const confirm = (title: string, text: string, command: Command) =>
    setModal({
      title,
      body: (
        <>
          <p>{text}</p>
          <div className="modal-actions">
            <button className="btn" onClick={() => setModal(null)}>
              Keep it
            </button>
            <button className="btn danger" onClick={() => run(command)}>
              Confirm
            </button>
          </div>
        </>
      ),
    });
  function inventoryAction(type: 'transfer' | 'adjust', item?: string) {
    setModal({
      title: type === 'transfer' ? 'Transfer inventory' : 'Adjust inventory',
      body: <MovementForm s={s} type={type} item={item} onSubmit={(c) => run(c)} />,
    });
  }

  function itemDetail(i: Item) {
    const rule = ordering(s, i.id);
    setModal({
      title: i.name,
      body: (
        <>
          <div className="detail-hero">
            <ProductArt item={i} />
            <div>
              <Badge>{i.type}</Badge>
              <p>{i.description}</p>
              <h2>
                {money(i.cost)} <small>weighted average cost</small>
              </h2>
              <p className="muted">
                {i.sku} · {i.barcode}
              </p>
            </div>
          </div>
          <div className="mini-grid">
            {s.locations.map((l) => (
              <div key={l.id}>
                <small>{l.name}</small>
                <b>
                  {num(onHand(s, i.id, l.id))}
                  <small>{num(available(s, i.id, l.id))} available</small>
                </b>
              </div>
            ))}
          </div>
          <h3>Ordering policy</h3>
          <p>
            Average usage {num(rule.avg, 2)}/day · σ {num(rule.sd, 2)} · Safety stock{' '}
            {num(rule.safety, 1)}
          </p>
          <p>
            ROP = {num(rule.avg, 2)} × {i.lead} + {num(rule.safety, 1)} = <b>{num(rule.rop, 1)}</b>{' '}
            · EOQ <b>{num(rule.eoq, 1)}</b>
          </p>
          <form
            onSubmit={(e) => {
              const v = form(e);
              run({ type: 'item', id: i.id, ...v });
            }}
          >
            <div className="form-grid">
              <Field label="Lead time (days)">
                <input name="lead" type="number" min="0" defaultValue={i.lead} />
              </Field>
              <Field label="Minimum reorder point">
                <input name="rop" type="number" min="0" defaultValue={i.rop} />
              </Field>
              <Field label="Preferred supplier">
                <select name="supplier" defaultValue={i.supplier}>
                  {s.suppliers.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </Field>
            </div>
            <button className="btn">Save ordering policy</button>
          </form>
          <h3>Bill of materials</h3>
          {s.bom
            .filter((b) => b.parent === i.id)
            .map((b) => (
              <p key={b.item}>
                {b.qty} × {itemBy(s, b.item).name}
              </p>
            ))}
          <p className="muted">
            Used in:{' '}
            {s.bom
              .filter((b) => b.item === i.id)
              .map((b) => itemBy(s, b.parent).name)
              .join(', ') || 'No parent BOMs'}
          </p>
          <h3>Open purchase orders</h3>
          {s.docs
            .filter(
              (d) =>
                d.kind === 'po' &&
                ['Order Sent', 'Partially Received'].includes(d.status) &&
                d.lines.some((l) => l.item === i.id),
            )
            .map((d) => (
              <p key={d.id}>
                {d.id} · expected {fmtDate(d.expected)}
              </p>
            ))}
          <h3>Recent inventory transactions</h3>
          <Table heads={['Date', 'Type', 'Location', 'Qty', 'Reference']}>
            {s.moves
              .filter((m) => m.item === i.id)
              .slice(-25)
              .reverse()
              .map((m) => (
                <tr key={m.id}>
                  <td>{fmtDate(m.date)}</td>
                  <td>
                    {m.type}
                    <small>{m.reason}</small>
                  </td>
                  <td>{place(m.location)}</td>
                  <td>
                    {m.qty > 0 ? '+' : ''}
                    {m.qty}
                  </td>
                  <td>{m.ref}</td>
                </tr>
              ))}
          </Table>
        </>
      ),
    });
  }
  function productionForm(item?: string, qty?: number) {
    setModal({
      title: 'Plan a production order',
      body: (
        <form
          onSubmit={(e) => {
            const v = form(e);
            run({ type: 'production', ...v, qty: Number(v.qty) });
          }}
        >
          <Field label="Finished item">
            <select name="item" defaultValue={item}>
              {s.items
                .filter((i) => s.bom.some((b) => b.parent === i.id))
                .map((i) => (
                  <option key={i.id} value={i.id}>
                    {i.name}
                  </option>
                ))}
            </select>
          </Field>
          <div className="form-grid">
            <Field label="Quantity to start">
              <input type="number" name="qty" min="1" step="1" defaultValue={qty || 10} required />
            </Field>
            <Field label="Planned finish">
              <input type="date" name="planned" defaultValue={today()} required />
            </Field>
          </div>
          <Field label="Production location">
            <select name="location" defaultValue="studio">
              {s.locations.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </select>
          </Field>
          <p className="info">
            <Layers size={17} /> Component availability is checked on issue. Scrap cost is absorbed
            into good units.
          </p>
          <button className="btn primary">Create production order</button>
        </form>
      ),
    });
  }
  function completeForm(d: Doc) {
    setModal({
      title: 'Complete ' + d.id,
      body: (
        <form
          onSubmit={(e) => {
            const v = form(e);
            run({
              type: 'complete',
              id: d.id,
              ...v,
              good: +v.good,
              scrap: +v.scrap,
              rework: +v.rework,
            });
          }}
        >
          <p>
            {d.lines[0].qty} units started · Material cost {money(d.materialCost)}
          </p>
          <div className="form-grid">
            <Field label="Good units (includes reworked)">
              <input name="good" type="number" min="0" defaultValue={d.lines[0].qty} />
            </Field>
            <Field label="Scrapped">
              <input name="scrap" type="number" min="0" defaultValue="0" />
            </Field>
            <Field label="Reworked (subset of good)">
              <input name="rework" type="number" min="0" defaultValue="0" />
            </Field>
            <Field label="Labor hours">
              <input name="labor" type="number" min="0" step=".1" defaultValue="1" />
            </Field>
          </div>
          <Field label="Quality reason">
            <select name="reason">
              <option value="">No issues</option>
              {[
                'MISALIGNED_PRINT',
                'TRANSFER_PEELING',
                'CROOKED_PATCH',
                'FABRIC_FLAW',
                'HEAT_PRESS_SCORCH',
              ].map((x) => (
                <option key={x}>{x}</option>
              ))}
            </select>
          </Field>
          <button className="btn primary">Complete & receive good units</button>
        </form>
      ),
    });
  }
  function poForm(initial?: Line[], supplier?: string) {
    setModal({
      title: 'Create purchase order',
      body: (
        <DocumentForm
          s={s}
          kind="po"
          initial={initial}
          supplier={supplier}
          onSubmit={(c) => run(c)}
          busy={busy}
        />
      ),
    });
  }
  function orderForm() {
    setModal({
      title: 'New sales order',
      body: <DocumentForm s={s} kind="order" onSubmit={(c) => run(c)} busy={busy} />,
    });
  }
  function receiveForm(d: Doc) {
    setModal({
      title: 'Receive ' + d.id,
      body: <ReceiveForm s={s} d={d} onSubmit={(c) => run(c)} />,
    });
  }
  function supplierForm(id?: string) {
    const p = s.suppliers.find((x) => x.id === id);
    setModal({
      title: p ? 'Edit supplier' : 'Add supplier',
      body: (
        <form
          onSubmit={(e) => {
            const v = form(e);
            run({ type: 'supplier', value: { ...v, id: p?.id, lead: +v.lead, moq: +v.moq } });
          }}
        >
          <div className="form-grid">
            {[
              ['name', 'Company name'],
              ['contact', 'Contact person'],
              ['email', 'Email'],
              ['phone', 'Phone'],
              ['address', 'Address'],
            ].map(([k, l]) => (
              <Field label={l} key={k}>
                <input
                  name={k}
                  defaultValue={p?.[k as keyof typeof p] || ''}
                  required={k === 'name' || k === 'email'}
                  type={k === 'email' ? 'email' : 'text'}
                />
              </Field>
            ))}
            <Field label="Quoted lead time (days)">
              <input name="lead" type="number" min="1" required defaultValue={p?.lead || 7} />
            </Field>
            <Field label="Minimum order quantity">
              <input name="moq" type="number" min="1" defaultValue={p?.moq || 1} />
            </Field>
            <Field label="Payment terms">
              <select name="terms" defaultValue={p?.terms || 'Net 30'}>
                {['Net 15', 'Net 30', 'Net 45', '2/10 Net 30'].map((x) => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </Field>
          </div>
          <button className="btn primary">Save supplier</button>
        </form>
      ),
    });
  }
  function scoreDetail(id: string) {
    const p = scorecard(s, id);
    setModal({
      title: p.supplier.name,
      body: (
        <>
          <div className="row">
            <Badge tone={p.rating === 'KEEP' ? 'green' : 'orange'}>{p.rating}</Badge>
            <b>{num(p.score, 1)} / 100</b>
            <button className="btn" onClick={() => supplierForm(id)}>
              Edit supplier
            </button>
            <button
              className="btn danger"
              onClick={() =>
                confirm(
                  'Delete supplier?',
                  p.supplier.name + ' will be removed if it has no item or purchase references.',
                  { type: 'deleteSupplier', id },
                )
              }
            >
              <Trash2 size={14} />
            </button>
          </div>
          <p>
            {p.supplier.contact} · {p.supplier.email}
            <br />
            {p.supplier.address} · {p.supplier.phone}
          </p>
          <div className="mini-grid">
            <div>
              On-time delivery<b>{pct(p.onTime * 100)}</b>
            </div>
            <div>
              Fill rate<b>{pct(p.fill * 100)}</b>
            </div>
            <div>
              Actual / quoted lead
              <b>
                {num(p.lead, 1)} / {p.supplier.lead} days
              </b>
            </div>
            <div>
              Direct resale quality<b>{pct(p.quality * 100)}</b>
            </div>
            <div>
              Open AP<b>{money(p.ap)}</b>
            </div>
            <div>
              Overdue<b>{money(p.overdue)}</b>
            </div>
          </div>
          <p className="muted">
            Score uses editable delivery / fill / quality weights. Quality traces purchased resale
            returns to the preferred supplier; component lot attribution is not tracked.
          </p>
          <h3>Invoices · {p.supplier.terms}</h3>
          <Table heads={['Invoice', 'PO', 'Due', 'Amount', 'Open']}>
            {p.invoices.map((i: any) => (
              <tr key={i.id}>
                <td>{i.id}</td>
                <td>{i.po}</td>
                <td>{fmtDate(i.due)}</td>
                <td>{money(i.total)}</td>
                <td>{money(i.total - i.paid)}</td>
              </tr>
            ))}
          </Table>
        </>
      ),
    });
  }
  if (loading)
    return (
      <div className="loading">
        <Sun className="spin" size={44} />
        <h2>Warming things up…</h2>
        <p>Connecting your Sunbeams workspace</p>
      </div>
    );
  if (!logged)
    return (
      <Login
        onLogin={(r) => {
          setRole(r);
          setLogged(true);
          if (r === 'Customer') go('Customer storefront');
          else if (r === 'Cashier') go('Point of sale');
          else if (r === 'Studio') go('Print Studio');
          else go('Overview');
        }}
      />
    );
  if (!s)
    return (
      <div className="loading">
        <AlertTriangle />
        <h2>Could not load your workspace</h2>
        <p>{error || 'Run the migration and seed the database first.'}</p>
        <button className="btn" onClick={() => location.reload()}>
          Try again
        </button>
      </div>
    );
  const now = today(),
    from = addDays(now, -Number(range) + 1),
    p = pnl(s, from, now),
    openOrders = s.docs.filter((d) => d.kind === 'order' && d.status === 'Order Placed'),
    openPOs = s.docs.filter(
      (d) => d.kind === 'po' && ['Order Sent', 'Partially Received'].includes(d.status),
    ),
    low = s.items.filter((i) => ordering(s, i.id).suggested > 0),
    late = openPOs.filter((d) => d.expected < now),
    sales = s.docs.filter(
      (d) =>
        d.kind === 'sale' &&
        dayOf(d.date) >= from &&
        dayOf(d.date) <= now &&
        (loc === 'all' || d.location === loc),
    );
  const trend = Array.from({ length: Number(range) }, (_, n) => {
    const d = addDays(from, n);
    return {
      date: d,
      label: fmtDate(d),
      sales: round(
        sum(
          sales.filter((x) => dayOf(x.date) === d),
          (x) => x.net,
        ),
      ),
      returns: sum(
        s.docs.filter((x) => x.kind === 'return' && dayOf(x.date) === d),
        (x) => x.total,
      ),
    };
  });
  const chartTrend =
    bucket === 'day'
      ? trend
      : Object.values(
          trend.reduce((a: Record<string, { label: string; sales: number }>, d, n) => {
            const key = bucket === 'month' ? d.date.slice(0, 7) : String(Math.floor(n / 7));
            if (!a[key])
              a[key] = {
                label:
                  bucket === 'month'
                    ? new Date(d.date + 'T12:00:00').toLocaleDateString('en-US', {
                        month: 'short',
                        year: '2-digit',
                      })
                    : fmtDate(d.date),
                sales: 0,
              };
            a[key].sales = round(a[key].sales + d.sales);
            return a;
          }, {}),
        );
  const ranking = s.items
    .filter((i) => i.price)
    .map((i) => ({
      ...i,
      units: sum(sales, (d) =>
        sum(
          d.lines.filter((l) => l.item === i.id),
          (l) => l.qty,
        ),
      ),
      revenue: sum(sales, (d) =>
        sum(
          d.lines.filter((l) => l.item === i.id),
          (l) => l.net || 0,
        ),
      ),
    }))
    .sort((a, b) => b.revenue - a.revenue);
  function exportReport() {
    csv(
      page.toLowerCase().replaceAll(' ', '-'),
      page === 'Inventory'
        ? s.items.map((i) => ({
            SKU: i.sku,
            Name: i.name,
            OnHand: onHand(s, i.id, loc === 'all' ? undefined : loc),
            Allocated: allocated(s, i.id, loc === 'all' ? undefined : loc),
            Available: available(s, i.id, loc === 'all' ? undefined : loc),
            OnOrder: onOrder(s, i.id),
            WAC: i.cost,
          }))
        : sales.flatMap((d) =>
            d.lines.map((l) => ({
              Receipt: d.id,
              Date: d.date,
              Location: place(d.location),
              Item: itemBy(s, l.item).name,
              Quantity: l.qty,
              Revenue: l.net,
              Cost: round(l.qty * l.cost!),
            })),
          ),
    );
    setToast('CSV exported.');
  }
  let content: ReactNode;
  if (page === 'Overview')
    content = (
      <>
        <div className="greeting-banner">
          <div>
            <span className="eyebrow">A SUNNY OUTLOOK</span>
            <h2>Small moments. Big possibilities.</h2>
            <p>Here’s how your Sunbeams business is growing today.</p>
            <button className="text-btn" onClick={() => go('Reports')}>
              Explore your reports <ArrowRight size={15} />
            </button>
          </div>
          <div className="sun-scene">
            <div className="scene-rays" />
            <div className="scene-sun">
              <span>⌣</span>
            </div>
            <div className="hill h1" />
            <div className="hill h2" />
            <div className="hill h3" />
            <Leaf className="scene-leaf" size={64} />
            <span className="scene-spark s1">✧</span>
            <span className="scene-spark s2">✧</span>
          </div>
        </div>
        <div className="metrics four">
          <Metric
            label="Today’s sales"
            value={money(pnl(s, now, now).net)}
            sub={
              <>
                <span className="green-dot" /> Net sales, before tax
              </>
            }
            icon={ShoppingBag}
          />
          <Metric
            label="Month-to-date sales"
            value={money(pnl(s, now.slice(0, 7) + '-01', now).net)}
            sub={now.slice(0, 7) + ' · after discounts & returns'}
            icon={ChartNoAxesCombined}
            tone="peach"
          />
          <Metric
            label="Gross margin"
            value={pct(p.margin)}
            sub={'Last ' + range + ' days · from your ledger'}
            icon={BarChart3}
            tone="sage"
          />
          <Metric
            label="Inventory value"
            value={money(invValue(s))}
            sub={num(sum(s.items, (i) => onHand(s, i.id))) + ' units across 3 locations'}
            icon={Package}
            tone="lilac"
          />
        </div>
        <div className="dashboard-grid">
          <section className="card sales-card">
            <div className="card-head">
              <div>
                <h3>A little growth, every day</h3>
                <p>Net sales before returns · {range} days</p>
              </div>
              <div className="row">
                <select
                  aria-label="Chart grouping"
                  value={bucket}
                  onChange={(e) => setBucket(e.target.value)}
                  className="small-select"
                >
                  <option value="day">Daily</option>
                  <option value="week">Weekly</option>
                  <option value="month">Monthly</option>
                </select>
                <Badge tone="green">
                  <span className="green-dot" /> Live data
                </Badge>
              </div>
            </div>
            <div className="chart-big-number">
              {money(sum(sales, (d) => d.net))}
              <small>in sales this period</small>
            </div>
            <div className="chart">
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={chartTrend} margin={{ top: 10, right: 5, left: -15, bottom: 0 }}>
                  <defs>
                    <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#e8b93e" stopOpacity={0.32} />
                      <stop offset="100%" stopColor="#e8b93e" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid vertical={false} stroke="#eeeae2" strokeDasharray="3 3" />
                  <XAxis
                    dataKey="label"
                    axisLine={false}
                    tickLine={false}
                    minTickGap={65}
                    tick={{ fill: '#9a9487', fontSize: 11 }}
                  />
                  <YAxis
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: '#9a9487', fontSize: 11 }}
                    tickFormatter={(v) => '$' + v}
                  />
                  <Tooltip
                    formatter={(v: any) => money(Number(v))}
                    contentStyle={{ border: '1px solid #ebe5d8', borderRadius: 12 }}
                  />
                  <Area
                    type="monotone"
                    dataKey="sales"
                    stroke="#dba72e"
                    strokeWidth={2.5}
                    fill="url(#salesGradient)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </section>
          <section className="card attention-card">
            <div className="card-head">
              <div>
                <h3>A little attention</h3>
                <p>Keep the good things moving.</p>
              </div>
              <span className="soft-icon">
                <Bell size={18} />
              </span>
            </div>
            {[
              {
                title: 'Items running low',
                value: low.length,
                sub: 'Ready for a little restock',
                page: 'Inventory',
                icon: Package,
                tone: 'yellow',
              },
              {
                title: 'Orders to fulfill',
                value: openOrders.length,
                sub: 'A happy pickup is waiting',
                page: 'Sales orders',
                icon: ShoppingBag,
                tone: 'sage',
              },
              {
                title: 'Purchase orders overdue',
                value: late.length,
                sub: 'Check in with your suppliers',
                page: 'Purchasing',
                icon: Truck,
                tone: 'peach',
              },
            ].map((a) => (
              <button className="attention-row" key={a.title} onClick={() => go(a.page)}>
                <span className={'attention-icon ' + a.tone}>
                  <a.icon size={19} />
                </span>
                <span>
                  <b>{a.title}</b>
                  <small>{a.sub}</small>
                </span>
                <strong>{a.value}</strong>
                <ChevronRight size={15} />
              </button>
            ))}
            <button className="keeper-teaser" onClick={() => go('Match Keeper')}>
              <Heart size={18} />
              <span>
                Better together.<small>Check on your matching pairs</small>
              </span>
              <ArrowUpRight size={18} />
            </button>
          </section>
          <section className="card">
            <div className="card-head">
              <div>
                <h3>Little favorites</h3>
                <p>Your best sellers this period.</p>
              </div>
              <button className="text-btn" onClick={() => go('Reports')}>
                View all <ArrowUpRight size={15} />
              </button>
            </div>
            <Table heads={['PRODUCT', 'UNITS SOLD', 'NET SALES']}>
              {ranking.slice(0, 4).map((i, n) => (
                <tr key={i.id} className="clickable" onClick={() => itemDetail(i)}>
                  <td>
                    <div className="product-cell">
                      <span className="rank">{n + 1}</span>
                      <ProductArt small item={i} />
                      <span>
                        <b>{i.name}</b>
                        <small>{i.category}</small>
                      </span>
                    </div>
                  </td>
                  <td>{num(i.units)}</td>
                  <td className="bold">{money(i.revenue)}</td>
                </tr>
              ))}
            </Table>
          </section>
          <section className="card">
            <div className="card-head">
              <div>
                <h3>Around the shop</h3>
                <p>The latest from your team.</p>
              </div>
              <span className="live-pulse" />
            </div>
            <div className="activity-list">
              {s.activity.slice(0, 5).map((a, n) => (
                <div className="activity" key={a.id}>
                  <span className={'activity-icon a' + n}>
                    <Check size={14} />
                  </span>
                  <div>
                    <p>{a.text}</p>
                    <small>
                      {a.user} <span>· {fmtDate(a.date)}</span>
                    </small>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </>
    );
  else if (page === 'Inventory') {
    const items = s.items.filter((i) =>
      (i.name + ' ' + i.sku + ' ' + i.barcode).toLowerCase().includes(search.toLowerCase()),
    );
    content = (
      <>
        <div className="metrics four">
          <Metric
            label="Inventory value"
            value={money(invValue(s))}
            sub="Inventory ledger carrying value"
            icon={Package}
          />
          <Metric
            label="Catalog items"
            value={s.items.length}
            sub={
              s.bom.map((b) => b.parent).filter((v, n, a) => a.indexOf(v) === n).length +
              ' active bills of materials'
            }
            icon={Layers}
          />
          <Metric
            label="Low stock items"
            value={low.length}
            sub="Below dynamic reorder policy"
            icon={AlertTriangle}
            tone="peach"
          />
          <Metric
            label="Quality hold"
            value={num(sum(s.items, (i) => onHand(s, i.id, undefined, true)))}
            sub="Excluded from sellable availability"
            icon={Heart}
            tone="sage"
          />
        </div>
        <section className="card">
          <div className="card-head">
            <div>
              <h3>Your inventory</h3>
              <p>Components, little favorites, and matching sets.</p>
            </div>
            <div className="row">
              {button('Adjust', () => inventoryAction('adjust'), false, ArrowLeftRight)}
              {button('Transfer', () => inventoryAction('transfer'), true, ArrowRight)}
            </div>
          </div>
          <div className="table-tools">
            <label className="search-box">
              <Search size={16} />
              <input
                placeholder="Search items, SKU, or scan a barcode…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    const i = s.items.find((i) => i.barcode === search);
                    if (i) itemDetail(i);
                  }
                }}
              />
            </label>
            <Badge>{items.length} items</Badge>
          </div>
          <Table
            heads={[
              'ITEM',
              'ON HAND',
              'ALLOCATED',
              'AVAILABLE',
              'BACKORDER',
              'ON ORDER',
              'WAC',
              'STATUS',
            ]}
          >
            {items.map((i) => (
              <tr className="clickable" key={i.id} onClick={() => itemDetail(i)}>
                <td>
                  <div className="product-cell">
                    <ProductArt small item={i} />
                    <span>
                      <b>{i.name}</b>
                      <small>
                        {i.sku} · {i.type}
                      </small>
                    </span>
                  </div>
                </td>
                <td>{num(onHand(s, i.id, loc === 'all' ? undefined : loc))}</td>
                <td>{num(allocated(s, i.id, loc === 'all' ? undefined : loc))}</td>
                <td className="bold">{num(available(s, i.id, loc === 'all' ? undefined : loc))}</td>
                <td>{num(backordered(s, i.id, loc === 'all' ? undefined : loc))}</td>
                <td>{num(onOrder(s, i.id))}</td>
                <td>{money(i.cost)}</td>
                <td>
                  <Badge tone={ordering(s, i.id).suggested ? 'orange' : 'green'}>
                    {ordering(s, i.id).suggested ? 'Reorder' : 'In stock'}
                  </Badge>
                </td>
              </tr>
            ))}
          </Table>
          {!items.length && <Empty text="No items match your search" />}
        </section>
      </>
    );
  } else if (page === 'Point of sale')
    content = (
      <POS
        s={s}
        onSubmit={async (c) => {
          const ok = await run(c, false);
          if (ok) {
            const next = snapshot();
            openReceipt(next.docs.filter((d) => d.kind === 'sale').slice(-1)[0]);
          }
          return ok;
        }}
      />
    );
  else if (page === 'Sales orders') {
    const orders = s.docs
      .filter((d) => d.kind === 'order')
      .slice()
      .reverse();
    content = (
      <section className="card">
        <div className="card-head">
          <div>
            <h3>Sales orders</h3>
            <p>Stock is reserved when orders are placed.</p>
          </div>
          {button('New order', orderForm, true)}
        </div>
        <Table
          heads={[
            'ORDER',
            'CUSTOMER / REQUESTED',
            'LOCATION',
            'ITEMS',
            'TOTAL',
            'STATUS',
            'NEXT STEP',
          ]}
        >
          {orders.map((d) => (
            <tr key={d.id}>
              <td>
                <button
                  className="link"
                  onClick={() =>
                    setModal({
                      title: d.id,
                      body: (
                        <>
                          <h3>Items & availability</h3>
                          {d.lines.map((l) => (
                            <p key={l.item}>
                              {l.qty} × {itemBy(s, l.item).name}
                              {l.qty > reserved(s, d.id, l.item) && (
                                <small className="orange">
                                  Backordered · estimated {fmtDate(expectedDate(s, l.item))}
                                </small>
                              )}
                            </p>
                          ))}
                          <h3>Status history</h3>
                          {d.history.map((h, n) => (
                            <p key={n}>
                              <Badge>{h.status}</Badge>{' '}
                              {new Date(h.date).toLocaleString('en-US', {
                                timeZone: 'America/Denver',
                              })}{' '}
                              · {h.user}
                            </p>
                          ))}
                        </>
                      ),
                    })
                  }
                >
                  {d.id}
                </button>
                <small>
                  {fmtDate(d.date)} · {d.source}
                </small>
              </td>
              <td>
                {s.customers.find((c) => c.id === d.customer)?.name}
                <small>Requested {fmtDate(d.requested)}</small>
              </td>
              <td>{place(d.location)}</td>
              <td>{sum(d.lines, (l) => l.qty)}</td>
              <td>{money(d.total)}</td>
              <td>
                <Badge tone={d.status === 'Order Placed' ? 'orange' : 'green'}>{d.status}</Badge>
              </td>
              <td>
                <div className="row">
                  {d.status === 'Order Placed' && (
                    <>
                      <button className="btn sm" onClick={() => run({ type: 'fulfill', id: d.id })}>
                        Fulfill
                      </button>
                      <button
                        className="icon-btn"
                        aria-label={'Cancel ' + d.id}
                        onClick={() =>
                          confirm('Cancel order?', d.id + ' will release all stock reservations.', {
                            type: 'cancelOrder',
                            id: d.id,
                          })
                        }
                      >
                        <X size={16} />
                      </button>
                    </>
                  )}
                  {d.status === 'Fulfilled' && (
                    <button className="btn sm" onClick={() => run({ type: 'close', id: d.id })}>
                      Close order
                    </button>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </Table>
        {!orders.length && <Empty text="Your first order starts here" />}
      </section>
    );
  } else if (page === 'Returns & exchanges')
    content = <Returns s={s} onSubmit={(c) => run(c, false)} />;
  else if (page === 'Purchasing') {
    const pos = s.docs
      .filter((d) => d.kind === 'po')
      .slice()
      .reverse();
    content = (
      <>
        <div className="metrics four">
          <Metric
            label="Open purchase orders"
            value={openPOs.length}
            sub="Sent or partially received"
            icon={Truck}
          />
          <Metric
            label="Accounts payable"
            value={money(-balance(s, 'Accounts Payable'))}
            sub="Received stock, unpaid invoices"
            icon={ReceiptText}
          />
          <Metric
            label="Overdue deliveries"
            value={late.length}
            sub="Expected date has passed"
            icon={Clock}
            tone="peach"
          />
          <Metric
            label="Units on order"
            value={num(sum(s.items, (i) => onOrder(s, i.id)))}
            sub="Remaining purchase quantities"
            icon={Package}
            tone="sage"
          />
        </div>
        <section className="card">
          <div className="card-head">
            <div>
              <h3>Purchase orders</h3>
              <p>Receive partially, pay accurately, keep things moving.</p>
            </div>
            <div className="row">
              {button('Review ordering', () => go('Material planning'), false, Layers)}
              {button('Create purchase order', () => poForm(), true)}
            </div>
          </div>
          <Table
            heads={[
              'PO / SUPPLIER',
              'EXPECTED',
              'RECEIVED / ORDERED',
              'TOTAL',
              'OPEN AP',
              'STATUS',
              'ACTIONS',
            ]}
          >
            {pos.slice(0, 90).map((d) => (
              <tr key={d.id}>
                <td>
                  <button className="link" onClick={() => openReceipt(d)}>
                    {d.id}
                  </button>
                  <small>{s.suppliers.find((p) => p.id === d.supplier)?.name}</small>
                </td>
                <td>
                  {fmtDate(d.expected)}
                  {d.receipts?.length > 0 && (
                    <small>
                      {d.receipts.slice(-1)[0].late > 0
                        ? d.receipts.slice(-1)[0].late + ' days late'
                        : Math.abs(d.receipts.slice(-1)[0].late) + ' days early/on time'}
                    </small>
                  )}
                </td>
                <td>
                  {sum(d.lines, (l) => l.received || 0)} / {sum(d.lines, (l) => l.qty)}
                </td>
                <td>{money(d.total)}</td>
                <td>{money(sum(d.invoices || [], (i: any) => i.total - i.paid))}</td>
                <td>
                  <Badge
                    tone={d.status === 'Closed' || d.status === 'Received' ? 'green' : 'orange'}
                  >
                    {d.status}
                  </Badge>
                </td>
                <td>
                  <div className="row">
                    {['Order Sent', 'Partially Received'].includes(d.status) && (
                      <button className="btn sm" onClick={() => receiveForm(d)}>
                        Receive
                      </button>
                    )}
                    {sum(d.invoices || [], (i: any) => i.total - i.paid) > 0 && (
                      <button
                        className="btn sm"
                        onClick={() =>
                          confirm(
                            'Record supplier payment?',
                            `Pay ${money(sum(d.invoices || [], (i: any) => i.total - i.paid))} from Cash for ${d.id}.`,
                            { type: 'pay', id: d.id },
                          )
                        }
                      >
                        Pay
                      </button>
                    )}
                    {d.status === 'Order Sent' && (
                      <button
                        className="icon-btn"
                        aria-label="Cancel purchase order"
                        onClick={() =>
                          confirm(
                            'Cancel purchase order?',
                            d.id + ' will be removed from scheduled receipts.',
                            { type: 'cancelPO', id: d.id },
                          )
                        }
                      >
                        <X size={15} />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </Table>
        </section>
      </>
    );
  } else if (page === 'Suppliers')
    content = (
      <section className="card">
        <div className="card-head">
          <div>
            <h3>Your supplier circle</h3>
            <p>Every score comes from your purchasing and receipt history.</p>
          </div>
          {button('Add supplier', () => supplierForm(), true)}
        </div>
        <Table
          heads={[
            'SUPPLIER',
            'QUOTED / ACTUAL LEAD',
            'ON-TIME',
            'FILL RATE',
            'OPEN AP',
            'SCORE',
            'RATING',
          ]}
        >
          {s.suppliers.map((p) => {
            const c = scorecard(s, p.id);
            return (
              <tr className="clickable" key={p.id} onClick={() => scoreDetail(p.id)}>
                <td>
                  <b>{p.name}</b>
                  <small>
                    {p.contact} · {p.terms}
                  </small>
                </td>
                <td>
                  {p.lead} / {num(c.lead, 1)} days
                </td>
                <td>{pct(c.onTime * 100)}</td>
                <td>{pct(c.fill * 100)}</td>
                <td>{money(c.ap)}</td>
                <td>
                  <b>{num(c.score, 1)}</b>
                  <div className="progress">
                    <span style={{ width: c.score + '%' }} />
                  </div>
                </td>
                <td>
                  <Badge
                    tone={c.rating === 'KEEP' ? 'green' : c.rating === 'WATCH' ? 'orange' : 'red'}
                  >
                    {c.rating}
                  </Badge>
                </td>
              </tr>
            );
          })}
        </Table>
        <div className="card-foot">
          Select a supplier for invoices, quality, overdue balances, and editable contact details.
        </div>
      </section>
    );
  else if (page === 'Print Studio') {
    const m = productionMetrics(s, from, now),
      orders = s.docs
        .filter((d) => d.kind === 'production')
        .slice()
        .reverse(),
      reasons = Object.entries(
        m.docs.reduce((a: Record<string, number>, d) => {
          a[d.reason] = (a[d.reason] || 0) + d.scrap;
          return a;
        }, {}),
      )
        .map(([reason, qty]) => ({ reason: reason.replaceAll('_', ' '), qty }))
        .sort((a, b) => b.qty - a.qty);
    content = (
      <>
        <div className="metrics four">
          <Metric
            label="First-pass yield"
            value={pct(m.fpy)}
            sub="Good ÷ started · course definition"
            icon={CheckCircle2}
          />
          <Metric
            label="Scrap / rework rate"
            value={pct(m.scrapRate) + ' / ' + pct(m.reworkRate)}
            sub={m.scrap + ' scrapped · ' + m.rework + ' reworked'}
            icon={Factory}
          />
          <Metric
            label="Average cycle time"
            value={num(m.cycle, 1) + ' hrs'}
            sub={num(m.uph, 1) + ' good units / labor hour'}
            icon={Clock}
          />
          <Metric
            label="On-time completion"
            value={pct(m.onTime)}
            sub={'First-touch yield ' + pct(m.firstTouch)}
            icon={CalendarDays}
            tone="sage"
          />
        </div>
        <section className="card">
          <div className="card-head">
            <div>
              <h3>Production orders</h3>
              <p>Make something that belongs together.</p>
            </div>
            {button('Plan production', () => productionForm(), true)}
          </div>
          <Table
            heads={[
              'ORDER',
              'ITEM',
              'PLANNED',
              'STARTED',
              'GOOD / SCRAP / REWORK',
              'STATUS',
              'NEXT STEP',
            ]}
          >
            {orders.slice(0, 35).map((d) => (
              <tr key={d.id}>
                <td>
                  {d.id}
                  <small>{place(d.location)}</small>
                </td>
                <td>{itemBy(s, d.lines[0].item).name}</td>
                <td>{fmtDate(d.planned)}</td>
                <td>{d.lines[0].qty}</td>
                <td>
                  {d.good ?? '—'} / {d.scrap ?? '—'} / {d.rework ?? '—'}
                </td>
                <td>
                  <Badge tone={d.status === 'Completed' ? 'green' : 'orange'}>{d.status}</Badge>
                </td>
                <td>
                  <div className="row">
                    {d.status === 'Planned' && (
                      <>
                        <button className="btn sm" onClick={() => run({ type: 'issue', id: d.id })}>
                          Issue BOM
                        </button>
                        <button
                          className="icon-btn"
                          aria-label="Cancel production"
                          onClick={() =>
                            confirm(
                              'Cancel production?',
                              d.id + ' has no issued materials and can be cancelled.',
                              { type: 'cancelProduction', id: d.id },
                            )
                          }
                        >
                          <X size={15} />
                        </button>
                      </>
                    )}
                    {d.status === 'Released' && (
                      <button className="btn sm" onClick={() => run({ type: 'start', id: d.id })}>
                        Start work
                      </button>
                    )}
                    {d.status === 'In Progress' && (
                      <button className="btn sm" onClick={() => completeForm(d)}>
                        Complete
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </Table>
        </section>
        <section className="card">
          <div className="card-head">
            <div>
              <h3>Scrap by reason</h3>
              <p>Largest contributors first · selected report period</p>
            </div>
            {button(
              'Export production',
              () =>
                csv(
                  'production',
                  m.docs.map((d) => ({
                    Order: d.id,
                    Item: itemBy(s, d.lines[0].item).name,
                    Started: d.lines[0].qty,
                    Good: d.good,
                    Scrap: d.scrap,
                    Rework: d.rework,
                    Reason: d.reason,
                    Start: d.started,
                    Finish: d.finished,
                  })),
                ),
              false,
              Download,
            )}
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={reasons} margin={{ bottom: 40, right: 20, left: 10 }}>
              <CartesianGrid vertical={false} stroke="#eeeae2" />
              <XAxis dataKey="reason" tick={{ fontSize: 9 }} angle={-10} interval={0} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="qty" fill="#caaa67" radius={[5, 5, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </section>
      </>
    );
  } else if (page === 'Material planning')
    content = (
      <Planning
        s={s}
        onPO={(lines, supplier) => poForm(lines, supplier)}
        onProduction={productionForm}
        onRun={run}
      />
    );
  else if (page === 'Reports') content = <Reports s={s} from={from} to={now} locationId={loc} />;
  else if (page === 'Match Keeper')
    content = (
      <>
        <div className="info">
          <Heart size={20} />
          <div>
            <b>Keep a little room for both.</b>
            <p>
              Compares days of supply for Mom and Baby pieces at each location, using the last 90
              days of demand at that location. Where no demand exists, unit counts are compared. A
              score of 100 means balanced coverage.
            </p>
          </div>
        </div>
        <div className="keeper-grid">
          {[
            [22, 23, 'Sunshine'],
            [24, 25, 'Bloom'],
            [26, 27, 'Cozy Sunshine'],
          ].flatMap(([mom, baby, name]) =>
            s.locations.map((l) => {
              const a = itemBy(s, 'i' + mom),
                b = itemBy(s, 'i' + baby),
                aq = available(s, a.id, l.id),
                bq = available(s, b.id, l.id),
                ad = demand(s, a.id, 90, l.id).avg,
                bd = demand(s, b.id, 90, l.id).avg,
                ac = ad ? aq / ad : aq,
                bc = bd ? bq / bd : bq,
                health = Math.max(ac, bc) ? (Math.min(ac, bc) / Math.max(ac, bc)) * 100 : 100,
                need = ac > bc ? b : a,
                qty = Math.ceil(Math.abs(ac - bc) * (ac > bc ? bd : ad));
              return (
                <section className="card keeper-card" key={name + l.id}>
                  <div className="card-head">
                    <h3>{name} pair</h3>
                    <Badge tone={health > 70 ? 'green' : 'orange'}>
                      {num(health)}% match health
                    </Badge>
                  </div>
                  <p className="muted">
                    <MapPin size={13} /> {l.name}
                  </p>
                  <div className="pair-arts">
                    <ProductArt item={a} />
                    <Heart size={22} />
                    <ProductArt item={b} />
                  </div>
                  <div className="mini-grid">
                    <div>
                      Mom available
                      <b>
                        {aq}
                        <small>{ad ? num(ac, 1) + ' days coverage' : 'No recent demand'}</small>
                      </b>
                    </div>
                    <div>
                      Baby available
                      <b>
                        {bq}
                        <small>{bd ? num(bc, 1) + ' days coverage' : 'No recent demand'}</small>
                      </b>
                    </div>
                  </div>
                  {qty > 0 ? (
                    <button className="btn" onClick={() => productionForm(need.id, qty)}>
                      <Plus size={15} /> Plan {qty} × {need.category} pieces
                    </button>
                  ) : (
                    <Badge tone="green">A happy matching pair</Badge>
                  )}
                </section>
              );
            }),
          )}
        </div>
      </>
    );
  else if (page === 'Seasonal planner')
    content = (
      <Seasonal
        s={s}
        onPlanning={() => go('Material planning')}
        onForecast={async (c) => {
          if (await run(c, false)) go('Material planning');
        }}
      />
    );
  else if (page === 'Customer storefront')
    content = (
      <Storefront
        s={s}
        customer={role === 'Customer' ? s.customers[0]?.id : undefined}
        onOrder={(c) => run(c, false)}
        onDetails={itemDetail}
      />
    );
  else if (page === 'Barcode labels') content = <Labels s={s} />;
  else if (page === 'Settings')
    content = (
      <section className="card settings-card">
        <div className="card-head">
          <div>
            <h3>Workspace settings</h3>
            <p>Planning and reports recalculate from these stored values.</p>
          </div>
          <Settings size={21} />
        </div>
        <form
          onSubmit={(e) => {
            const v = form(e);
            run(
              {
                type: 'settings',
                values: Object.fromEntries(Object.entries(v).map(([k, v]) => [k, Number(v)])),
              },
              false,
            );
          }}
        >
          <div className="form-grid">
            {Object.entries({
              taxRate: 'Sales tax rate (0.0725 = 7.25%)',
              orderCost: 'Ordering cost per PO ($)',
              holdingRate: 'Annual holding rate (0.25 = 25%)',
              z: 'Service level z-value',
              reviewDays: 'Review period (days)',
              workingDays: 'Working days per year',
              weightDelivery: 'Supplier weight · on-time delivery',
              weightFill: 'Supplier weight · fill rate',
              weightQuality: 'Supplier weight · quality',
            }).map(([k, label]) => (
              <Field key={k} label={label}>
                <input
                  type="number"
                  name={k}
                  min="0"
                  step="any"
                  defaultValue={s.settings[k]}
                  required
                />
              </Field>
            ))}
          </div>
          <button className="btn primary">Save settings</button>
        </form>
        <hr />
        <h3>Workspace connection</h3>
        <p>
          <Badge tone={demo ? 'orange' : 'green'}>
            {demo ? 'Browser demo' : 'Supabase connected'}
          </Badge>
        </p>
        <p className="muted">
          {demo
            ? 'Demo data stays in this browser. Tabs on the same origin update through storage events. Cross-browser collaboration requires Supabase; demo role switching is not a security boundary.'
            : 'Authenticated business commands are committed by a Postgres RPC. Realtime refreshes every screen after committed changes.'}
        </p>
        {demo && (
          <button
            className="btn danger"
            onClick={() =>
              setModal({
                title: 'Reset the demo?',
                body: (
                  <>
                    <p>This removes all your local changes and rebuilds the historical seed.</p>
                    <button
                      className="btn danger"
                      onClick={() => {
                        resetDemo();
                        setModal(null);
                        setToast('Demo reset.');
                      }}
                    >
                      Reset all demo data
                    </button>
                  </>
                ),
              })
            }
          >
            Reset demo data
          </button>
        )}
      </section>
    );
  else content = <About />;
  return (
    <div className="app">
      <aside className={'sidebar ' + (mobile ? 'mobile-open' : '')}>
        <button className="brand" onClick={() => go('Overview')}>
          <span className="brand-mark">
            <Sun size={33} strokeWidth={1.6} />
          </span>
          <span>
            sunbeams<small>RETAIL & STUDIO</small>
          </span>
        </button>
        <div className="workspace-chip">
          <span className="shop-icon">
            <ShoppingBag size={17} />
          </span>
          <span>
            Sunbeams workspace<small>Made for little moments</small>
          </span>
          <ChevronDown size={14} />
        </div>
        <nav>
          {groups.map((g) => (
            <div className="nav-group" key={g.label}>
              <p>{g.label}</p>
              {g.items
                .filter(([p]) =>
                  role === 'Customer'
                    ? p === 'Customer storefront' || p === 'About this system'
                    : role === 'Cashier'
                      ? [
                          'Overview',
                          'Point of sale',
                          'Sales orders',
                          'Returns & exchanges',
                          'Barcode labels',
                          'About this system',
                        ].includes(p)
                      : role === 'Studio'
                        ? [
                            'Overview',
                            'Inventory',
                            'Purchasing',
                            'Suppliers',
                            'Print Studio',
                            'Material planning',
                            'Barcode labels',
                            'About this system',
                          ].includes(p)
                        : true,
                )
                .map(([p, Icon]) => (
                  <button
                    key={p}
                    className={'nav-item ' + (p === page ? 'active' : '')}
                    onClick={() => go(p)}
                  >
                    <Icon size={18} strokeWidth={1.7} />
                    <span>{p}</span>
                    {p === 'Sales orders' && <em>{openOrders.length}</em>}
                    {p === page && <span className="active-dot" />}
                  </button>
                ))}
            </div>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="demo-label">
            <span className="live-pulse" />
            {demo ? 'DEMO WORKSPACE' : 'CONNECTED WORKSPACE'}
          </div>
          <button
            className="user-profile"
            onClick={() => {
              if (supabase) supabase.auth.signOut();
              setLogged(false);
            }}
          >
            <span className="avatar">
              {names[role]
                .split(' ')
                .map((x) => x[0])
                .join('')}
            </span>
            <span>
              <b>{names[role]}</b>
              <small>{role === 'Manager' ? 'Owner & Manager' : role}</small>
            </span>
            <LogOut size={15} />
          </button>
        </div>
      </aside>
      {mobile && <div className="sidebar-scrim" onClick={() => setMobile(false)} />}
      <div className="workspace">
        <header className="topbar">
          <div className="breadcrumb">
            <button
              className="icon-btn mobile-menu"
              aria-label="Open navigation"
              onClick={() => setMobile(true)}
            >
              <Menu size={21} />
            </button>
            <span>Workspace</span>
            <ChevronRight size={13} />
            <b>{page}</b>
          </div>
          <div className="topbar-right">
            <span className="connected">
              <span className="live-pulse" />
              {demo ? 'Demo mode' : 'All changes saved'}
            </span>
            <button
              className="icon-btn"
              aria-label="View activity"
              onClick={() =>
                setModal({
                  title: 'Around the shop',
                  body: (
                    <div className="activity-list">
                      {s.activity.slice(0, 30).map((a) => (
                        <div className="activity" key={a.id}>
                          <Check size={15} />
                          <div>
                            <p>{a.text}</p>
                            <small>
                              {a.user} ·{' '}
                              {new Date(a.date).toLocaleString('en-US', {
                                timeZone: 'America/Denver',
                              })}
                            </small>
                          </div>
                        </div>
                      ))}
                    </div>
                  ),
                })
              }
            >
              <Bell size={19} />
              <span className="notification-dot" />
            </button>
            <span className="avatar small-avatar">
              {names[role]
                .split(' ')
                .map((x) => x[0])
                .join('')}
            </span>
          </div>
        </header>
        <main>
          <div className="page-heading">
            <div>
              <div className="date-eyebrow">
                {new Date(now + 'T12:00:00').toLocaleDateString('en-US', {
                  weekday: 'long',
                  month: 'long',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </div>
              <h1>
                {page === 'Overview' ? 'A sunny day at Sunbeams' : page}
                <span className="heading-dot">{page === 'Overview' ? '☀' : ''}</span>
              </h1>
              <p>{details[page]}</p>
            </div>
            <div className="page-actions">
              {['Overview', 'Reports', 'Print Studio'].includes(page) && (
                <select
                  value={range}
                  onChange={(e) => setRange(e.target.value)}
                  aria-label="Report date range"
                >
                  <option value="7">Last 7 days</option>
                  <option value="30">Last 30 days</option>
                  <option value="90">Last 90 days</option>
                  <option value="365">Last 12 months</option>
                </select>
              )}
              {['Overview', 'Inventory', 'Reports'].includes(page) && (
                <select
                  value={loc}
                  onChange={(e) => setLoc(e.target.value)}
                  aria-label="Location"
                  title={
                    page === 'Inventory'
                      ? 'Inventory location'
                      : 'Sales chart and item-sales location'
                  }
                >
                  <option value="all">All locations</option>
                  {s.locations.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
                </select>
              )}
              {['Overview', 'Inventory'].includes(page) &&
                button('Export', exportReport, false, Download)}
            </div>
          </div>
          {content}
          <footer className="footer">
            <span>
              <Sun size={13} /> A little more connected. A lot more sunshine.
            </span>
            <span>Sunbeams · Retail & Studio</span>
          </footer>
        </main>
      </div>
      {modal && (
        <Modal title={modal.title} onClose={() => setModal(null)}>
          <fieldset disabled={busy}>{modal.body}</fieldset>
        </Modal>
      )}
      {error && (
        <div className="toast error-toast" role="alert">
          <AlertTriangle size={20} />
          <span>{error}</span>
          <button aria-label="Dismiss error" onClick={() => setError('')}>
            <X size={17} />
          </button>
        </div>
      )}
      {toast && (
        <div className="toast" role="status">
          <CheckCircle2 size={20} />
          {toast}
        </div>
      )}
      {busy && (
        <div className="saving">
          <RefreshCw className="spin" size={15} /> Saving transaction…
        </div>
      )}
    </div>
  );
}
function Login({ onLogin }: { onLogin: (r: Role) => void }) {
  const [email, setEmail] = useState('manager@sunbeams.demo'),
    [password, setPassword] = useState('Sunshine2026!'),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  async function login(r?: Role) {
    if (demo) {
      onLogin(
        r ||
          ({ cashier: 'Cashier', studio: 'Studio', customer: 'Customer' } as Record<string, Role>)[
            email.split('@')[0]
          ] ||
          'Manager',
      );
      return;
    }
    setBusy(true);
    const e = r
      ? { Manager: 'manager', Cashier: 'cashier', Studio: 'studio', Customer: 'customer' }[r] +
        '@sunbeams.demo'
      : email;
    const { error } = await supabase!.auth.signInWithPassword({
      email: e,
      password: r ? 'Sunshine2026!' : password,
    });
    if (error) setError(error.message);
    else {
      const { data } = await supabase!.auth.getUser();
      onLogin(data.user?.app_metadata.role || 'Customer');
    }
    setBusy(false);
  }
  return (
    <div className="login">
      <div className="login-brand">
        <Sun size={50} />
        <h1>sunbeams</h1>
        <p>Little moments. Matching memories.</p>
        <div className="login-art">
          <ProductArt item={{ name: 'Mama Sun', category: 'Mom', type: 'manufactured' } as Item} />
          <ProductArt
            item={{ name: 'Little Sunbeam', category: 'Baby', type: 'manufactured' } as Item}
          />
        </div>
        <h2>Everything in its sunny place.</h2>
        <p>A thoughtfully connected home for your shop and studio.</p>
      </div>
      <div className="login-card">
        <span className="eyebrow">WELCOME TO YOUR WORKSPACE</span>
        <h2>A little sunshine starts here.</h2>
        <p className="muted">Sign in to keep the good things growing.</p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            login();
          }}
        >
          <Field label="Email">
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </Field>
          <Field label="Password">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </Field>
          <button className="btn primary wide" disabled={busy}>
            Sign in <ArrowRight size={16} />
          </button>
        </form>
        <div className="divider">OR EXPLORE AS A DEMO ROLE</div>
        <div className="role-grid">
          {(['Manager', 'Cashier', 'Studio', 'Customer'] as Role[]).map((r) => (
            <button className="btn" disabled={busy} key={r} onClick={() => login(r)}>
              {r}
            </button>
          ))}
        </div>
        {error && <p className="error">{error}</p>}
        <p className="muted tiny">
          {demo
            ? 'Browser demo · data stays on this device.'
            : 'Supabase Auth · permissions enforced by Postgres.'}
        </p>
      </div>
    </div>
  );
}
function POS({ s, onSubmit }: { s: State; onSubmit: (c: Command) => Promise<boolean> }) {
  const [location, setLocation] = useState('provo'),
    [customer, setCustomer] = useState(''),
    [category, setCategory] = useState('All pieces'),
    [q, setQ] = useState(''),
    [lines, setLines] = useState<Line[]>([]),
    [discount, setDiscount] = useState(0),
    [discountType, setDiscountType] = useState('percent'),
    [payment, setPayment] = useState('card'),
    [scan, setScan] = useState(false),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const totals = (() => {
    try {
      return saleTotals(s, lines, discount, discountType);
    } catch {
      return null;
    }
  })();
  function add(i: Item) {
    if (!available(s, i.id, location)) {
      setError('No available stock for ' + i.name);
      return;
    }
    setLines((ls) => {
      const l = ls.find((l) => l.item === i.id);
      return l
        ? ls.map((x) => (x.item === i.id ? { ...x, qty: x.qty + 1 } : x))
        : [...ls, { item: i.id, qty: 1, discount: 0, discountType: 'percent' }];
    });
    setQ('');
    setError('');
  }
  function scanned(v: string) {
    const i = s.items.find((i) => i.barcode === v && i.price > 0);
    if (i) add(i);
    else setError('Barcode not found in sellable catalog: ' + v);
  }
  return (
    <div className="pos-layout">
      <section>
        <div className="pos-search">
          <label className="search-box">
            <Search size={18} />
            <input
              placeholder="Search or scan a barcode, then Enter…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') scanned(q);
              }}
            />
          </label>
          <button className="btn" onClick={() => setScan(true)} aria-label="Scan with camera">
            <Camera size={19} />
          </button>
        </div>
        <div className="tabs">
          {['All pieces', 'Mom', 'Baby', 'Matching Sets', 'Accessories'].map((c) => (
            <button
              className={category === c ? 'selected' : ''}
              key={c}
              onClick={() => setCategory(c)}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="product-grid">
          {s.items
            .filter(
              (i) =>
                i.price > 0 &&
                (category === 'All pieces' || i.category === category) &&
                (i.name + ' ' + i.barcode + ' ' + i.sku).toLowerCase().includes(q.toLowerCase()),
            )
            .map((i) => (
              <button className="product-card" key={i.id} onClick={() => add(i)}>
                <ProductArt item={i} />
                <div>
                  <small>{i.category}</small>
                  <h3>{i.name}</h3>
                  <p>
                    <b>{money(i.price)}</b>
                    <span>{available(s, i.id, location)} available</span>
                  </p>
                </div>
              </button>
            ))}
        </div>
      </section>
      <section className="card pos-cart">
        <div className="card-head">
          <div>
            <h3>A little bag of sunshine</h3>
            <p>{sum(lines, (l) => l.qty)} pieces in this sale</p>
          </div>
          <ShoppingBag size={22} />
        </div>
        <div className="cart-body">
          <Field label="Selling location">
            <select value={location} onChange={(e) => setLocation(e.target.value)}>
              {s.locations.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Customer (optional)">
            <select value={customer} onChange={(e) => setCustomer(e.target.value)}>
              <option value="">Walk-in customer</option>
              {s.customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </Field>
          <div className="cart-lines">
            {!lines.length ? (
              <Empty text="Their next favorite is waiting" />
            ) : (
              lines.map((l) => {
                const i = itemBy(s, l.item);
                return (
                  <div className="cart-line" key={l.item}>
                    <ProductArt small item={i} />
                    <div className="cart-line-info">
                      <b>{i.name}</b>
                      <small>{money(i.price)} each</small>
                      <div className="row">
                        <div className="stepper">
                          <button
                            aria-label="Decrease quantity"
                            onClick={() =>
                              setLines(
                                lines
                                  .map((x) => (x.item === l.item ? { ...x, qty: x.qty - 1 } : x))
                                  .filter((x) => x.qty > 0),
                              )
                            }
                          >
                            <Minus size={12} />
                          </button>
                          <input
                            aria-label="Quantity"
                            type="number"
                            min="1"
                            value={l.qty}
                            onChange={(e) =>
                              setLines(
                                lines.map((x) =>
                                  x.item === l.item ? { ...x, qty: Number(e.target.value) } : x,
                                ),
                              )
                            }
                          />
                          <button
                            aria-label="Increase quantity"
                            onClick={() =>
                              setLines(
                                lines.map((x) =>
                                  x.item === l.item ? { ...x, qty: x.qty + 1 } : x,
                                ),
                              )
                            }
                          >
                            <Plus size={12} />
                          </button>
                        </div>
                        <input
                          className="discount-input"
                          aria-label="Line discount"
                          type="number"
                          min="0"
                          value={l.discount || 0}
                          onChange={(e) =>
                            setLines(
                              lines.map((x) =>
                                x.item === l.item ? { ...x, discount: +e.target.value } : x,
                              ),
                            )
                          }
                        />
                        <select
                          aria-label="Line discount type"
                          className="small-select"
                          value={l.discountType}
                          onChange={(e) =>
                            setLines(
                              lines.map((x) =>
                                x.item === l.item ? { ...x, discountType: e.target.value } : x,
                              ),
                            )
                          }
                        >
                          <option value="percent">% off</option>
                          <option value="dollar">$ off</option>
                        </select>
                      </div>
                    </div>
                    <button
                      className="icon-btn"
                      aria-label="Remove item"
                      onClick={() => setLines(lines.filter((x) => x.item !== l.item))}
                    >
                      <X size={14} />
                    </button>
                  </div>
                );
              })
            )}
          </div>
          <div className="form-grid">
            <Field label="Order discount">
              <input
                type="number"
                min="0"
                value={discount}
                onChange={(e) => setDiscount(+e.target.value)}
              />
            </Field>
            <Field label="Discount type">
              <select value={discountType} onChange={(e) => setDiscountType(e.target.value)}>
                <option value="percent">Percent (%)</option>
                <option value="dollar">Amount ($)</option>
              </select>
            </Field>
          </div>
          {error && <p className="error">{error}</p>}
          {!totals && <p className="error">Discount cannot exceed the item or order amount.</p>}
          <div className="cart-totals">
            <div>
              <span>Subtotal</span>
              <b>{money(totals?.subtotal || 0)}</b>
            </div>
            <div>
              <span>Discounts</span>
              <span>−{money(totals?.discount || 0)}</span>
            </div>
            <div>
              <span>Tax ({pct(s.settings.taxRate * 100)})</span>
              <span>{money(totals?.tax || 0)}</span>
            </div>
            <div className="grand-total">
              <b>Total</b>
              <b>{money(totals?.total || 0)}</b>
            </div>
          </div>
          <div className="payment-toggle">
            {['card', 'cash'].map((p) => (
              <button
                key={p}
                className={payment === p ? 'selected' : ''}
                onClick={() => setPayment(p)}
              >
                {p === 'card' ? 'Credit / debit card' : 'Cash'}
              </button>
            ))}
          </div>
          <button
            className="btn primary wide checkout"
            disabled={!lines.length || !totals || busy}
            onClick={async () => {
              setBusy(true);
              try {
                if (
                  await onSubmit({
                    type: 'sale',
                    location,
                    customer: customer || undefined,
                    lines,
                    discount,
                    discountType,
                    payment,
                  })
                ) {
                  setLines([]);
                  setDiscount(0);
                }
              } finally {
                setBusy(false);
              }
            }}
          >
            <CheckCircle2 size={18} />
            {busy ? 'Completing sale…' : 'Complete sale'} <span>{money(totals?.total || 0)}</span>
          </button>
        </div>
      </section>
      {scan && (
        <Modal title="Scan a barcode" onClose={() => setScan(false)}>
          <CameraScan onScan={scanned} onClose={() => setScan(false)} />
        </Modal>
      )}
    </div>
  );
}
function DocumentForm({
  s,
  kind,
  onSubmit,
  initial,
  supplier,
  busy,
}: {
  s: State;
  kind: 'po' | 'order';
  onSubmit: (c: Command) => void;
  initial?: Line[];
  supplier?: string;
  busy: boolean;
}) {
  const [lines, setLines] = useState<Line[]>(
      initial?.map((l) => ({ ...l, cost: round(l.cost ?? itemBy(s, l.item).cost) })) || [],
    ),
    [sup, setSup] = useState(supplier || s.suppliers[0].id),
    [item, setItem] = useState(''),
    [location, setLocation] = useState(kind === 'po' ? 'orem' : 'provo');
  const items = s.items.filter((i) =>
    kind === 'po' ? i.supplier === sup && ['component', 'resale'].includes(i.type) : i.price > 0,
  );
  const [error, setError] = useState('');
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const v = Object.fromEntries(new FormData(e.currentTarget));
        onSubmit({ type: kind, ...v, supplier: sup, location, lines });
      }}
    >
      {kind === 'po' ? (
        <Field label="Supplier">
          <select
            value={sup}
            onChange={(e) => {
              setSup(e.target.value);
              setLines([]);
            }}
          >
            {s.suppliers.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </Field>
      ) : (
        <>
          <Field label="Customer">
            <select name="customer" required>
              {s.customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Requested pickup date">
            <input name="requested" type="date" defaultValue={today()} required />
          </Field>
        </>
      )}
      <Field label={kind === 'po' ? 'Default receiving location' : 'Fulfilling location'}>
        <select value={location} onChange={(e) => setLocation(e.target.value)}>
          {s.locations.map((l) => (
            <option key={l.id} value={l.id}>
              {l.name}
            </option>
          ))}
        </select>
      </Field>
      <div className="row">
        <select value={item} onChange={(e) => setItem(e.target.value)} className="grow">
          <option value="">Choose an item…</option>
          {items.map((i) => (
            <option key={i.id} value={i.id}>
              {i.name}
            </option>
          ))}
        </select>
        <button
          className="btn"
          type="button"
          onClick={() => {
            if (!item) return;
            setLines(
              lines.some((l) => l.item === item)
                ? lines.map((l) => (l.item === item ? { ...l, qty: l.qty + 1 } : l))
                : [...lines, { item, qty: 1, cost: round(itemBy(s, item).cost) }],
            );
            setItem('');
          }}
        >
          <Plus size={16} />
          Add
        </button>
      </div>
      <Table heads={['ITEM', 'QTY', kind === 'po' ? 'UNIT COST' : 'UNIT PRICE', '']}>
        {lines.map((l) => (
          <tr key={l.item}>
            <td>{itemBy(s, l.item).name}</td>
            <td>
              <input
                className="qty-input"
                aria-label="Quantity"
                type="number"
                min="1"
                value={l.qty}
                onChange={(e) =>
                  setLines(
                    lines.map((x) => (x.item === l.item ? { ...x, qty: +e.target.value } : x)),
                  )
                }
              />
            </td>
            <td>
              {kind === 'po' ? (
                <input
                  className="cost-input"
                  type="number"
                  min=".01"
                  step=".01"
                  aria-label="Unit cost"
                  value={l.cost}
                  onChange={(e) =>
                    setLines(
                      lines.map((x) => (x.item === l.item ? { ...x, cost: +e.target.value } : x)),
                    )
                  }
                />
              ) : (
                money(itemBy(s, l.item).price)
              )}
            </td>
            <td>
              <button
                type="button"
                className="icon-btn"
                aria-label="Remove item"
                onClick={() => setLines(lines.filter((x) => x.item !== l.item))}
              >
                <X size={14} />
              </button>
            </td>
          </tr>
        ))}
      </Table>
      {!lines.length && <p className="muted">Add at least one item to get started.</p>}
      {kind === 'po' && (
        <p className="info">
          <Truck size={16} /> Expected{' '}
          {fmtDate(addDays(today(), s.suppliers.find((p) => p.id === sup)!.lead))} ·{' '}
          {s.suppliers.find((p) => p.id === sup)!.terms}
        </p>
      )}
      {error && <p className="error">{error}</p>}
      <button className="btn primary" disabled={!lines.length || busy}>
        {kind === 'po' ? 'Create & mark as sent' : 'Place & reserve order'}
      </button>
    </form>
  );
}
function ReceiveForm({ s, d, onSubmit }: { s: State; d: Doc; onSubmit: (c: Command) => void }) {
  const [values, setValues] = useState<Record<string, number>>({}),
    [barcode, setBarcode] = useState(''),
    [error, setError] = useState(''),
    [camera, setCamera] = useState(false);
  const lines = d.lines.filter((l) => l.qty > (l.received || 0));
  function scan(v: string) {
    const i = s.items.find((i) => i.barcode === v),
      line = lines.find((l) => l.item === i?.id);
    if (!line) setError('This barcode is not an outstanding item on this PO.');
    else {
      setValues((v) => ({ ...v, [line.item]: (v[line.item] || 0) + 1 }));
      setError('');
    }
    setBarcode('');
  }
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const v = Object.fromEntries(new FormData(e.currentTarget));
        onSubmit({
          type: 'receive',
          id: d.id,
          ...v,
          lines: lines
            .map((l) => ({ item: l.item, qty: values[l.item] || 0 }))
            .filter((l) => l.qty > 0),
        });
      }}
    >
      <div className="form-grid">
        <Field label="Receiving location">
          <select name="location" defaultValue={d.location}>
            {s.locations.map((l) => (
              <option key={l.id} value={l.id}>
                {l.name}
              </option>
            ))}
          </select>
        </Field>
        <Field label="Actual receipt date">
          <input type="date" name="date" defaultValue={today()} required />
        </Field>
      </div>
      <div className="row">
        <input
          className="grow"
          placeholder="Scan barcode, then Enter"
          value={barcode}
          onChange={(e) => setBarcode(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              scan(barcode);
            }
          }}
        />
        <button type="button" className="btn" onClick={() => setCamera(true)}>
          <Camera size={16} />
        </button>
        <button
          type="button"
          className="btn"
          onClick={() =>
            setValues(Object.fromEntries(lines.map((l) => [l.item, l.qty - (l.received || 0)])))
          }
        >
          Receive all
        </button>
      </div>
      <Table heads={['ITEM', 'REMAINING', 'RECEIVE NOW']}>
        {lines.map((l) => (
          <tr key={l.item}>
            <td>
              {itemBy(s, l.item).name}
              <small>{itemBy(s, l.item).barcode}</small>
            </td>
            <td>{l.qty - (l.received || 0)}</td>
            <td>
              <input
                type="number"
                aria-label={'Receive ' + itemBy(s, l.item).name}
                className="qty-input"
                min="0"
                max={l.qty - (l.received || 0)}
                value={values[l.item] || 0}
                onChange={(e) => setValues({ ...values, [l.item]: +e.target.value })}
              />
            </td>
          </tr>
        ))}
      </Table>
      {error && <p className="error">{error}</p>}
      <p className="muted">
        Updates weighted average cost and posts Inventory / Accounts Payable in one transaction.
      </p>
      <button className="btn primary" disabled={!Object.values(values).some((v) => v > 0)}>
        Receive & create payable
      </button>
      {camera && (
        <Modal title="Scan to receive" onClose={() => setCamera(false)}>
          <CameraScan onScan={scan} onClose={() => setCamera(false)} />
        </Modal>
      )}
    </form>
  );
}
function Returns({ s, onSubmit }: { s: State; onSubmit: (c: Command) => Promise<boolean> }) {
  const [query, setQuery] = useState(''),
    [id, setId] = useState(''),
    [values, setValues] = useState<Record<string, number>>({}),
    [reason, setReason] = useState('WRONG_SIZE'),
    [replacement, setReplacement] = useState(''),
    [qty, setQty] = useState(1),
    [busy, setBusy] = useState(false);
  const recent = s.docs
      .filter((d) => d.kind === 'sale' && d.id.toLowerCase().includes(query.toLowerCase()))
      .slice(-12)
      .reverse(),
    d = s.docs.find((d) => d.id === id);
  const refund = d
    ? sum(
        d.lines,
        (l) =>
          round((l.net! * ((l.returned || 0) + (values[l.item] || 0))) / l.qty) -
          round((l.net! * (l.returned || 0)) / l.qty) +
          round((l.tax! * ((l.returned || 0) + (values[l.item] || 0))) / l.qty) -
          round((l.tax! * (l.returned || 0)) / l.qty),
      )
    : 0;
  const replacementCost = replacement ? saleTotals(s, [{ item: replacement, qty }]).total : 0;
  return (
    <div className="return-layout">
      <section className="card">
        <div className="card-head">
          <div>
            <h3>Find the original receipt</h3>
            <p>Enter or scan a Sunbeams receipt number.</p>
          </div>
          <ReceiptText size={22} />
        </div>
        <div className="pad">
          <label className="search-box">
            <Search size={17} />
            <input
              value={query}
              placeholder="e.g. SB-00001"
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && recent.length) {
                  setId(recent[0].id);
                  setValues({});
                }
              }}
            />
          </label>
        </div>
        {recent.map((x) => (
          <button
            className={'receipt-select ' + (x.id === id ? 'selected' : '')}
            key={x.id}
            onClick={() => {
              setId(x.id);
              setValues({});
            }}
          >
            <span>
              <b>{x.id}</b>
              <small>
                {fmtDate(x.date)} · {s.locations.find((l) => l.id === x.location)?.name}
              </small>
            </span>
            <b>{money(x.total)}</b>
            <ChevronRight size={16} />
          </button>
        ))}
      </section>
      <section className="card">
        <div className="card-head">
          <div>
            <h3>{d ? 'Return · ' + d.id : 'Make it right, with care'}</h3>
            <p>Select the items coming back to Sunbeams.</p>
          </div>
          <Heart size={21} />
        </div>
        {d ? (
          <div className="pad">
            <Table heads={['ITEM', 'RETURNABLE', 'RETURN QTY']}>
              {d.lines.map((l) => (
                <tr key={l.item}>
                  <td>
                    {itemBy(s, l.item).name}
                    <small>Original cost: {money(l.cost!)}</small>
                  </td>
                  <td>{l.qty - (l.returned || 0)}</td>
                  <td>
                    <input
                      className="qty-input"
                      aria-label="Return quantity"
                      type="number"
                      min="0"
                      max={l.qty - (l.returned || 0)}
                      value={values[l.item] || 0}
                      onChange={(e) => setValues({ ...values, [l.item]: +e.target.value })}
                    />
                  </td>
                </tr>
              ))}
            </Table>
            <Field label="Required return reason">
              <select value={reason} onChange={(e) => setReason(e.target.value)}>
                {[
                  'WRONG_SIZE',
                  'CHANGED_MIND',
                  'GIFT_RETURN',
                  'QUALITY_DEFECT_PRINT_PEELING',
                  'QUALITY_DEFECT_SEAM',
                  'QUALITY_DEFECT_STAIN',
                ].map((r) => (
                  <option key={r}>{r}</option>
                ))}
              </select>
            </Field>
            <p className="info">
              <Package size={17} />
              {reason.startsWith('QUALITY')
                ? 'Returned items go to non-sellable Quality Hold.'
                : 'Returned items go back into sellable inventory at original cost.'}
            </p>
            <h3>Exchange (optional)</h3>
            <div className="form-grid">
              <Field label="Replacement item">
                <select value={replacement} onChange={(e) => setReplacement(e.target.value)}>
                  <option value="">Refund only</option>
                  {s.items
                    .filter((i) => i.price)
                    .map((i) => (
                      <option key={i.id} value={i.id}>
                        {i.name} · {money(i.price)}
                      </option>
                    ))}
                </select>
              </Field>
              {replacement && (
                <Field label="Replacement quantity">
                  <input
                    type="number"
                    min="1"
                    value={qty}
                    onChange={(e) => setQty(+e.target.value)}
                  />
                </Field>
              )}
            </div>
            <div className="cart-totals">
              <div>
                <span>Estimated refund (includes tax)</span>
                <b>{money(refund)}</b>
              </div>
              {replacement && (
                <div>
                  <span>
                    {replacementCost - refund >= 0 ? 'Customer pays' : 'Customer receives'}
                  </span>
                  <b>{money(Math.abs(replacementCost - refund))}</b>
                </div>
              )}
            </div>
            <button
              className="btn primary"
              disabled={busy || !Object.values(values).some((q) => q > 0)}
              onClick={async () => {
                setBusy(true);
                if (
                  await onSubmit({
                    type: 'return',
                    id: d.id,
                    reason,
                    lines: Object.entries(values)
                      .filter(([, q]) => q > 0)
                      .map(([item, qty]) => ({ item, qty })),
                    replacements: replacement ? [{ item: replacement, qty }] : [],
                  })
                ) {
                  setValues({});
                  setReplacement('');
                }
                setBusy(false);
              }}
            >
              {replacement ? 'Complete exchange' : 'Issue refund'}
            </button>
          </div>
        ) : (
          <Empty text="Choose a receipt to get started" />
        )}
      </section>
    </div>
  );
}
function Planning({
  s,
  onPO,
  onProduction,
  onRun,
}: {
  s: State;
  onPO: (l: Line[], supplier: string) => void;
  onProduction: (item: string, qty: number) => void;
  onRun: (c: Command, close?: boolean) => Promise<boolean>;
}) {
  const [tab, setTab] = useState('Material requirements'),
    [rounding, setRounding] = useState(false),
    [uplift, setUplift] = useState(0),
    [last, setLast] = useState('Calculated from current data'),
    [busy, setBusy] = useState(false);
  const rows = mrp(s, rounding, uplift),
    rules = s.items.map((i) => ({ i, r: ordering(s, i.id) })),
    suggestions = rules.filter(
      (x) => x.r.suggested > 0 && ['component', 'resale'].includes(x.i.type),
    );
  async function createPOs() {
    if (!suggestions.length) return;
    setBusy(true);
    try {
      for (const supplier of [...new Set(suggestions.map((x) => x.i.supplier))]) {
        const lines = suggestions
          .filter((x) => x.i.supplier === supplier)
          .map((x) => ({ item: x.i.id, qty: x.r.suggested, cost: round(x.i.cost) }));
        if (!(await onRun({ type: 'po', supplier, location: 'orem', lines }, false))) break;
      }
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <div className="tabs">
        <button
          className={tab === 'Material requirements' ? 'selected' : ''}
          onClick={() => setTab('Material requirements')}
        >
          Material requirements
        </button>
        <button
          className={tab === 'Ordering review' ? 'selected' : ''}
          onClick={() => setTab('Ordering review')}
        >
          Periodic ordering review
        </button>
      </div>
      {tab === 'Material requirements' ? (
        <>
          <section className="card">
            <div className="card-head">
              <div>
                <h3>A plan for every little piece</h3>
                <p>{last} · open customer orders, recursively exploded through BOMs</p>
              </div>
              <button
                className="btn primary"
                onClick={() =>
                  setLast(
                    'Recalculated at ' +
                      new Date().toLocaleTimeString('en-US', { timeZone: 'America/Denver' }),
                  )
                }
              >
                <RefreshCw size={16} />
                Run MRP
              </button>
            </div>
            <div className="planning-controls">
              <label className="check">
                <input
                  type="checkbox"
                  checked={rounding}
                  onChange={(e) => setRounding(e.target.checked)}
                />{' '}
                Round planned orders to EOQ / supplier MOQ
              </label>
              <label className="row">
                Demand uplift{' '}
                <input
                  className="qty-input"
                  type="number"
                  min="0"
                  value={uplift}
                  onChange={(e) => setUplift(Math.max(0, +e.target.value))}
                />{' '}
                %
              </label>
            </div>
            <Table
              heads={[
                'ITEM / REQUIREMENT',
                ...Array.from(
                  { length: 4 },
                  (_, n) => 'WEEK ' + (n + 1) + ' · ' + fmtDate(addDays(today(), n * 7)),
                ),
                'ACTION',
              ]}
            >
              {rows.map((row) => {
                const i = itemBy(s, row.item),
                  total = sum(row.weeks, (w) => w.qty);
                return (
                  <tr key={i.id}>
                    <td>
                      <b>{i.name}</b>
                      <small>
                        {i.sku} · {i.lead}-day lead
                      </small>
                    </td>
                    {row.weeks.map((w) => (
                      <td key={w.date} className="mrp-cell">
                        <span>
                          Gross <b>{w.gross}</b>
                        </span>
                        <span>
                          Receipts <b>{w.receipts}</b>
                        </span>
                        <span>
                          Projected <b>{w.projected}</b>
                        </span>
                        <span>
                          Net req. <b>{w.net}</b>
                        </span>
                        <span>
                          Release <b>{w.qty}</b>
                        </span>
                        {w.qty > 0 && (
                          <small className={w.release < today() ? 'orange' : ''}>
                            {w.release < today() ? 'Expedite · ' : ''}
                            {fmtDate(w.release)}
                          </small>
                        )}
                      </td>
                    ))}
                    <td>
                      {total > 0 &&
                        (s.bom.some((b) => b.parent === i.id) ? (
                          <button className="btn sm" onClick={() => onProduction(i.id, total)}>
                            Plan build
                          </button>
                        ) : (
                          <button
                            className="btn sm"
                            onClick={() =>
                              onPO([{ item: i.id, qty: total, cost: round(i.cost) }], i.supplier)
                            }
                          >
                            Create PO
                          </button>
                        ))}
                    </td>
                  </tr>
                );
              })}
            </Table>
            {!rows.length && <Empty text="No requirements in the next four weeks" />}
          </section>
          <div className="info explanation">
            <BookOpen size={22} />
            <div>
              <h3>MRP, in plain English</h3>
              <p>
                <b>Gross requirements</b> are the pieces needed for open orders and parent builds.{' '}
                <b>Scheduled receipts</b> are remaining quantities on POs in their expected week.{' '}
                <b>Projected on-hand</b> carries the balance forward, including planned supply.{' '}
                <b>Net requirements</b> are the shortage after existing stock and receipts.{' '}
                <b>Planned order release</b> is the quantity to order or build, offset by the item’s
                lead time.
              </p>
              <p>
                Open-order demand is netted against physical stock once, without subtracting its
                reservations a second time. Saved forecasts are consumed against confirmed orders
                using the greater demand per item/week. Existing production WIP is not included as
                scheduled supply; review it before converting suggestions. Conversions open a review
                form and do not auto-submit.
              </p>
            </div>
          </div>
        </>
      ) : (
        <section className="card">
          <div className="card-head">
            <div>
              <h3>Periodic review · every {s.settings.reviewDays} days</h3>
              <p>Historical usage includes sales and production component consumption.</p>
            </div>
            <button
              className="btn primary"
              disabled={busy || !suggestions.length}
              onClick={createPOs}
            >
              <Plus size={16} />
              Create {new Set(suggestions.map((x) => x.i.supplier)).size} grouped POs
            </button>
          </div>
          <Table
            heads={[
              'ITEM',
              'DAILY USAGE / σ',
              'SAFETY STOCK',
              'ROP',
              'POSITION',
              'EOQ',
              'SUGGESTED',
              'ORDER BY',
            ]}
          >
            {rules.map(({ i, r }) => (
              <tr key={i.id}>
                <td>
                  <b>{i.name}</b>
                  <small>
                    Lead {i.lead} days · Holding {pct(s.settings.holdingRate * 100)}
                  </small>
                </td>
                <td>
                  {num(r.avg, 2)} / {num(r.sd, 2)}
                </td>
                <td>{num(r.safety, 1)}</td>
                <td>
                  {num(r.rop, 1)}
                  <small>Minimum {i.rop}</small>
                </td>
                <td>{num(r.position)}</td>
                <td>{num(r.eoq, 1)}</td>
                <td>{r.suggested ? <Badge tone="orange">{r.suggested}</Badge> : '—'}</td>
                <td>{r.suggested ? fmtDate(r.orderBy) : '—'}</td>
              </tr>
            ))}
          </Table>
        </section>
      )}
    </>
  );
}
function Reports({
  s,
  from,
  to,
  locationId,
}: {
  s: State;
  from: string;
  to: string;
  locationId: string;
}) {
  const [tab, setTab] = useState('Profit & loss'),
    [a, setA] = useState(from),
    [b, setB] = useState(to);
  useEffect(() => {
    setA(from);
    setB(to);
  }, [from, to]);
  const sales = s.docs.filter(
      (d) =>
        d.kind === 'sale' &&
        dayOf(d.date) >= a &&
        dayOf(d.date) <= b &&
        (locationId === 'all' || d.location === locationId),
    ),
    ranking = s.items
      .filter((i) => i.price > 0)
      .map((i) => ({
        ...i,
        units: sum(sales, (d) =>
          sum(
            d.lines.filter((l) => l.item === i.id),
            (l) => l.qty,
          ),
        ),
        revenue: sum(sales, (d) =>
          sum(
            d.lines.filter((l) => l.item === i.id),
            (l) => l.net || 0,
          ),
        ),
      }))
      .sort((x, y) => y.revenue - x.revenue);
  const p = pnl(s, a, b),
    t = turnover(s, a, b),
    accounts = [...new Set(s.journals.flatMap((j) => j.lines.map((l) => l.account)))],
    returns = s.docs.filter(
      (d) =>
        d.kind === 'return' &&
        dayOf(d.date) >= a &&
        dayOf(d.date) <= b &&
        (locationId === 'all' || d.location === locationId),
    );
  const reportRows = [
    ['Gross sales', p.gross],
    ['Sales discounts', -p.discount],
    ['Returns & allowances', -p.returns],
    ['Net sales', p.net],
    ['Cost of goods sold', -p.cogs],
    ['Gross profit', p.profit],
    ['Scrap / shrinkage expense', -p.shrink],
    ['Operating income', p.income],
  ] as [string, number][];
  return (
    <>
      <div className="tabs">
        {[
          'Profit & loss',
          'Inventory valuation',
          'Turnover & DSI',
          'Sales insights',
          'General ledger',
        ].map((x) => (
          <button className={tab === x ? 'selected' : ''} key={x} onClick={() => setTab(x)}>
            {x}
          </button>
        ))}
      </div>
      <div className="report-dates">
        <label>
          From <input type="date" value={a} onChange={(e) => setA(e.target.value)} />
        </label>
        <label>
          To <input type="date" value={b} min={a} onChange={(e) => setB(e.target.value)} />
        </label>
      </div>
      {a > b ? (
        <p className="error">Start date must precede end date.</p>
      ) : tab === 'Profit & loss' ? (
        <div className="reports-grid">
          <section className="card">
            <div className="card-head">
              <div>
                <h3>Profit & loss</h3>
                <p>
                  {fmtDate(a)} – {fmtDate(b)} · all locations · posted ledger
                </p>
              </div>
              <button
                className="btn"
                onClick={() =>
                  csv(
                    'profit-and-loss',
                    reportRows.map(([Account, Amount]) => ({ Account, Amount })),
                  )
                }
              >
                <Download size={16} />
                Export
              </button>
            </div>
            <div className="pnl-lines">
              {reportRows.map(([name, value]) => (
                <div
                  className={
                    ['Net sales', 'Gross profit', 'Operating income'].includes(name)
                      ? 'emphasis'
                      : ''
                  }
                  key={name}
                >
                  <span>{name}</span>
                  <b>{money(value)}</b>
                </div>
              ))}
              <div>
                <span>Gross margin</span>
                <b>{pct(p.margin)}</b>
              </div>
            </div>
          </section>
          <section className="card">
            <div className="card-head">
              <div>
                <h3>Balance sheet snapshot</h3>
                <p>As of {fmtDate(b)} · full posted history</p>
              </div>
              <BookOpen size={20} />
            </div>
            <div className="pnl-lines">
              {[
                'Cash',
                'Accounts Receivable',
                'Inventory',
                'Work in Progress',
                'Accounts Payable',
                'Sales Tax Payable',
              ].map((x) => (
                <div key={x}>
                  <span>{x}</span>
                  <b>
                    {money(
                      balance(s, x, '0000', b) *
                        (x === 'Accounts Payable' || x === 'Sales Tax Payable' ? -1 : 1),
                    )}
                  </b>
                </div>
              ))}
            </div>
            <p className="pad muted">
              Liabilities shown as positive amounts. Quality-hold stock remains an inventory asset
              until disposition.
            </p>
          </section>
        </div>
      ) : tab === 'Inventory valuation' ? (
        <section className="card">
          <div className="card-head">
            <div>
              <h3>Inventory valuation · current stock</h3>
              <p>WAC is global per item. Carrying values retain transaction rounding.</p>
            </div>
            <button
              className="btn"
              onClick={() =>
                csv(
                  'inventory-valuation',
                  s.items.flatMap((i) =>
                    s.locations.map((l) => ({
                      Item: i.name,
                      Location: l.name,
                      OnHand: onHand(s, i.id, l.id),
                      QualityHold: onHand(s, i.id, l.id, true),
                      WAC: i.cost,
                      Value: round((onHand(s, i.id, l.id) + onHand(s, i.id, l.id, true)) * i.cost),
                    })),
                  ),
                )
              }
            >
              <Download size={16} />
              Export
            </button>
          </div>
          <Table
            heads={['ITEM', ...s.locations.map((l) => l.name), 'QUALITY HOLD', 'WAC', 'WAC VALUE']}
          >
            {s.items.map((i) => (
              <tr key={i.id}>
                <td>{i.name}</td>
                {s.locations.map((l) => (
                  <td key={l.id}>{onHand(s, i.id, l.id)}</td>
                ))}
                <td>{onHand(s, i.id, undefined, true)}</td>
                <td>{money(i.cost)}</td>
                <td>{money((onHand(s, i.id) + onHand(s, i.id, undefined, true)) * i.cost)}</td>
              </tr>
            ))}
          </Table>
          <div className="card-foot">
            Inventory ledger / GL carrying value: <b>{money(invValue(s))}</b> · WAC value:{' '}
            <b>
              {money(
                sum(s.items, (i) => (onHand(s, i.id) + onHand(s, i.id, undefined, true)) * i.cost),
              )}
            </b>
          </div>
        </section>
      ) : tab === 'Turnover & DSI' ? (
        <>
          <div className="metrics four">
            <Metric label="Period COGS" value={money(p.cogs)} sub={t.days + ' calendar days'} />
            <Metric
              label="Average inventory"
              value={money(t.average)}
              sub="Average of daily closing ledger values"
            />
            <Metric
              label="Inventory turnover"
              value={num(t.turns, 2) + '×'}
              sub="Period COGS ÷ average inventory"
            />
            <Metric
              label="Days sales of inventory"
              value={num(t.dsi, 1) + ' days'}
              sub="Days in period ÷ period turnover"
            />
          </div>
          <p className="info">
            <BookOpen size={18} /> Turnover uses actual daily inventory history, including receipts
            and production WIP movements. This is period turnover; it is not annualized.
          </p>
          <section className="card">
            <div className="card-head">
              <div>
                <h3>Turnover by category & item</h3>
                <p>
                  COGS is allocated from the same sale / return cost movements posted to the GL.
                </p>
              </div>
              <button
                className="btn"
                onClick={() =>
                  csv(
                    'turnover',
                    s.items.map((i) => ({
                      Item: i.name,
                      Category: i.category,
                      ...turnover(s, a, b, [i.id]),
                    })),
                  )
                }
              >
                <Download size={16} />
                Export
              </button>
            </div>
            <Table heads={['CATEGORY / ITEM', 'PERIOD COGS', 'AVG. INVENTORY', 'TURNOVER', 'DSI']}>
              {['Mom', 'Baby', 'Matching Sets', 'Accessories', 'Components'].map((category) => {
                const v = turnover(
                  s,
                  a,
                  b,
                  s.items.filter((i) => i.category === category).map((i) => i.id),
                );
                return (
                  <tr key={category}>
                    <td>
                      <b>{category}</b>
                    </td>
                    <td>{money(v.cogs)}</td>
                    <td>{money(v.average)}</td>
                    <td>{num(v.turns, 2)}×</td>
                    <td>{v.turns ? num(v.dsi, 1) + ' days' : '—'}</td>
                  </tr>
                );
              })}
              {s.items
                .filter((i) => i.price)
                .map((i) => {
                  const v = turnover(s, a, b, [i.id]);
                  return (
                    <tr key={i.id}>
                      <td>{i.name}</td>
                      <td>{money(v.cogs)}</td>
                      <td>{money(v.average)}</td>
                      <td>{num(v.turns, 2)}×</td>
                      <td>{v.turns ? num(v.dsi, 1) + ' days' : '—'}</td>
                    </tr>
                  );
                })}
            </Table>
          </section>
        </>
      ) : tab === 'Sales insights' ? (
        <>
          <div className="reports-grid">
            <section className="card">
              <div className="card-head">
                <h3>Sales by location</h3>
              </div>
              <ResponsiveContainer width="100%" height={230}>
                <BarChart
                  data={s.locations.map((l) => ({
                    name: l.name
                      .replace(' Fulfillment Warehouse', '')
                      .replace(' Flagship Store', ''),
                    Sales: sum(
                      sales.filter((d) => d.location === l.id),
                      (d) => d.net,
                    ),
                  }))}
                >
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tickFormatter={(v) => '$' + v} />
                  <Tooltip formatter={(v: any) => money(+v)} />
                  <Bar dataKey="Sales" fill="#a8b89a" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </section>
            <section className="card">
              <div className="card-head">
                <h3>Sales by category</h3>
              </div>
              <ResponsiveContainer width="100%" height={230}>
                <BarChart
                  data={['Mom', 'Baby', 'Matching Sets', 'Accessories'].map((name) => ({
                    name,
                    Sales: sum(sales, (d) =>
                      sum(
                        d.lines.filter((l) => itemBy(s, l.item).category === name),
                        (l) => l.net || 0,
                      ),
                    ),
                  }))}
                >
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tickFormatter={(v) => '$' + v} />
                  <Tooltip formatter={(v: any) => money(+v)} />
                  <Bar dataKey="Sales" fill="#e9bd55" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </section>
          </div>
          <section className="card">
            <div className="card-head">
              <div>
                <h3>Best sellers & slow movers</h3>
                <p>Sorted by revenue · use the period filter above</p>
              </div>
              <button
                className="btn"
                onClick={() =>
                  csv(
                    'item-sales',
                    ranking.map((i) => ({
                      Item: i.name,
                      Units: i.units,
                      Revenue: i.revenue,
                      Returned: sum(returns, (d) =>
                        sum(
                          d.lines.filter((l) => l.item === i.id),
                          (l) => l.qty,
                        ),
                      ),
                    })),
                  )
                }
              >
                <Download size={16} />
                Export
              </button>
            </div>
            <Table heads={['ITEM', 'UNITS', 'NET SALES', 'RETURNS', 'RETURN RATE']}>
              {ranking.map((i) => {
                const r = sum(returns, (d) =>
                  sum(
                    d.lines.filter((l) => l.item === i.id),
                    (l) => l.qty,
                  ),
                );
                return (
                  <tr key={i.id}>
                    <td>{i.name}</td>
                    <td>{i.units}</td>
                    <td>{money(i.revenue)}</td>
                    <td>{r}</td>
                    <td>{i.units ? pct((r / i.units) * 100) : '—'}</td>
                  </tr>
                );
              })}
            </Table>
          </section>
          <section className="card">
            <div className="card-head">
              <h3>Returns by reason</h3>
            </div>
            <Table heads={['REASON', 'UNITS', 'REFUNDS']}>
              {[...new Set(returns.map((d) => d.reason))].map((reason) => (
                <tr key={reason}>
                  <td>{reason}</td>
                  <td>
                    {sum(
                      returns.filter((d) => d.reason === reason),
                      (d) => sum(d.lines, (l) => l.qty),
                    )}
                  </td>
                  <td>
                    {money(
                      sum(
                        returns.filter((d) => d.reason === reason),
                        (d) => d.total,
                      ),
                    )}
                  </td>
                </tr>
              ))}
            </Table>
          </section>
        </>
      ) : (
        <>
          <section className="card">
            <div className="card-head">
              <div>
                <h3>Trial balance</h3>
                <p>Debits = credits · a negative debit balance is a credit balance</p>
              </div>
              <Badge
                tone={
                  Math.abs(sum(accounts, (x) => balance(s, x, '0000', b))) < 0.02 ? 'green' : 'red'
                }
              >
                {Math.abs(sum(accounts, (x) => balance(s, x, '0000', b))) < 0.02
                  ? 'Balanced'
                  : 'Out of balance'}
              </Badge>
              <button
                className="btn"
                onClick={() =>
                  csv(
                    'journal-lines',
                    s.journals
                      .filter((j) => dayOf(j.date) >= a && dayOf(j.date) <= b)
                      .flatMap((j) =>
                        j.lines.map((l) => ({
                          Date: j.date,
                          Reference: j.ref,
                          Memo: j.memo,
                          ...l,
                        })),
                      ),
                  )
                }
              >
                <Download size={16} />
                Export journal
              </button>
            </div>
            <Table heads={['ACCOUNT', 'DEBIT', 'CREDIT']}>
              {accounts.map((account) => {
                const v = balance(s, account, '0000', b);
                return (
                  <tr key={account}>
                    <td>{account}</td>
                    <td>{v > 0 ? money(v) : '—'}</td>
                    <td>{v < 0 ? money(-v) : '—'}</td>
                  </tr>
                );
              })}
            </Table>
          </section>
          <section className="card">
            <div className="card-head">
              <h3>Recent journal entries</h3>
            </div>
            <Table heads={['DATE', 'REFERENCE', 'MEMO', 'DEBIT', 'CREDIT']}>
              {s.journals
                .filter((j) => dayOf(j.date) >= a && dayOf(j.date) <= b)
                .slice(-40)
                .reverse()
                .map((j) => (
                  <tr key={j.id}>
                    <td>{fmtDate(j.date)}</td>
                    <td>{j.ref}</td>
                    <td>{j.memo}</td>
                    <td>{money(sum(j.lines, (l) => l.debit))}</td>
                    <td>{money(sum(j.lines, (l) => l.credit))}</td>
                  </tr>
                ))}
            </Table>
          </section>
        </>
      )}
    </>
  );
}
function Storefront({
  s,
  customer,
  onOrder,
  onDetails,
}: {
  s: State;
  customer?: string;
  onOrder: (c: Command) => Promise<boolean>;
  onDetails: (i: Item) => void;
}) {
  const [tab, setTab] = useState('Shop'),
    [loc, setLoc] = useState('provo'),
    [category, setCategory] = useState('All'),
    [lines, setLines] = useState<Line[]>([]),
    [cid, setCid] = useState(customer || 'c0'),
    [registry, setRegistry] = useState(''),
    [registryId, setRegistryId] = useState(''),
    [busy, setBusy] = useState(false);
  const orders = s.docs
    .filter((d) => d.kind === 'order' && d.customer === cid)
    .slice()
    .reverse();
  return (
    <>
      <div className="store-hero">
        <span className="eyebrow">A LITTLE SUNSHINE, FOR BOTH OF YOU</span>
        <h2>
          Made to match.
          <br />
          Made for memories.
        </h2>
        <p>Thoughtful pieces for moms, babies, and the moments in between.</p>
        <Sun className="store-sun" size={160} strokeWidth={0.6} />
      </div>
      <div className="store-controls">
        <div className="tabs">
          {['Shop', 'My orders', 'Baby shower registry'].map((x) => (
            <button key={x} className={x === tab ? 'selected' : ''} onClick={() => setTab(x)}>
              {x}
            </button>
          ))}
        </div>
        <div className="row">
          {!customer && (
            <select
              value={cid}
              onChange={(e) => setCid(e.target.value)}
              aria-label="Customer account"
            >
              {s.customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          )}
          <select value={loc} onChange={(e) => setLoc(e.target.value)} aria-label="Pickup location">
            {s.locations
              .filter((l) => l.id !== 'studio')
              .map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
          </select>
        </div>
      </div>
      {tab === 'Shop' ? (
        <>
          <div className="tabs">
            {['All', 'Mom', 'Baby', 'Matching Sets', 'Accessories'].map((c) => (
              <button
                key={c}
                className={category === c ? 'selected' : ''}
                onClick={() => setCategory(c)}
              >
                {c}
              </button>
            ))}
          </div>
          <div className="store-grid">
            {s.items
              .filter((i) => i.price > 0 && (category === 'All' || category === i.category))
              .map((i) => (
                <article className="product-card" key={i.id}>
                  <ProductArt item={i} />
                  <div>
                    <small>{i.category}</small>
                    <h3>{i.name}</h3>
                    <p>
                      <b>{money(i.price)}</b>
                      <span>{available(s, i.id, loc)} available</span>
                    </p>
                    <small>at {s.locations.find((l) => l.id === loc)?.name}</small>
                    <button
                      className="btn wide"
                      onClick={() =>
                        setLines(
                          lines.some((l) => l.item === i.id)
                            ? lines.map((l) => (l.item === i.id ? { ...l, qty: l.qty + 1 } : l))
                            : [...lines, { item: i.id, qty: 1 }],
                        )
                      }
                    >
                      <Plus size={14} /> Add for pickup
                    </button>
                  </div>
                </article>
              ))}
          </div>
          {!!lines.length && (
            <section className="card pickup-cart">
              <div className="card-head">
                <h3>Your sunshine bag · {sum(lines, (l) => l.qty)} items</h3>
                <button className="icon-btn" aria-label="Clear bag" onClick={() => setLines([])}>
                  <Trash2 size={16} />
                </button>
              </div>
              <div className="pad">
                {lines.map((l) => (
                  <p className="row" key={l.item}>
                    <span className="grow">{itemBy(s, l.item).name}</span>
                    <input
                      className="qty-input"
                      aria-label="Pickup quantity"
                      type="number"
                      min="1"
                      value={l.qty}
                      onChange={(e) =>
                        setLines(
                          lines.map((x) =>
                            x.item === l.item ? { ...x, qty: +e.target.value } : x,
                          ),
                        )
                      }
                    />
                    <button
                      className="icon-btn"
                      aria-label="Remove from bag"
                      onClick={() => setLines(lines.filter((x) => x.item !== l.item))}
                    >
                      <X size={14} />
                    </button>
                  </p>
                ))}
                <p className="muted">
                  Pickup orders reserve available stock. Shortages will be backordered with an
                  estimated date.
                </p>
                <div className="row">
                  <b className="grow">Total including tax: {money(saleTotals(s, lines).total)}</b>
                  <button
                    className="btn primary"
                    disabled={busy}
                    onClick={async () => {
                      setBusy(true);
                      if (
                        await onOrder({
                          type: 'order',
                          customer: cid,
                          location: loc,
                          lines,
                          requested: addDays(today(), 2),
                          source: 'Portal',
                          registry: registryId || undefined,
                        })
                      ) {
                        setLines([]);
                        setRegistryId('');
                        setTab('My orders');
                      }
                      setBusy(false);
                    }}
                  >
                    Place pickup order <ArrowRight size={16} />
                  </button>
                </div>
              </div>
            </section>
          )}
        </>
      ) : tab === 'My orders' ? (
        <section className="card">
          <div className="card-head">
            <div>
              <h3>My little moments</h3>
              <p>{s.customers.find((c) => c.id === cid)?.name} · pickup order history</p>
            </div>
          </div>
          {orders.length ? (
            <Table heads={['ORDER', 'PLACED', 'PICKUP', 'TOTAL', 'STATUS']}>
              {orders.map((d) => (
                <tr key={d.id}>
                  <td>
                    {d.id}
                    <small>
                      {d.lines.map((l) => l.qty + ' × ' + itemBy(s, l.item).name).join(', ')}
                    </small>
                  </td>
                  <td>{fmtDate(d.date)}</td>
                  <td>
                    {s.locations.find((l) => l.id === d.location)?.name}
                    <small>Requested {fmtDate(d.requested)}</small>
                  </td>
                  <td>{money(d.total)}</td>
                  <td>
                    <Badge tone={d.status === 'Order Placed' ? 'orange' : 'green'}>
                      {d.status === 'Fulfilled' ? 'Ready for pickup' : d.status}
                    </Badge>
                  </td>
                </tr>
              ))}
            </Table>
          ) : (
            <Empty text="Your next little memory starts in the shop" />
          )}
        </section>
      ) : (
        <section className="card">
          <div className="card-head">
            <div>
              <h3>Baby shower registry</h3>
              <p>Thoughtful gifts for the little one on the way.</p>
            </div>
            <Heart size={22} />
          </div>
          <div className="pad">
            <p className="info">
              Create a registry from your bag, or shop a registry as a guest. Pickup checkout
              reserves stock and reduces the registry’s remaining needs.
            </p>
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                if (
                  await onOrder({
                    type: 'registry',
                    name: registry,
                    customer: cid,
                    lines: lines.length ? lines : [{ item: 'i32', qty: 1 }],
                  })
                )
                  setRegistry('');
              }}
            >
              <div className="row">
                <input
                  className="grow"
                  required
                  placeholder="Registry name, e.g. Baby Bennett"
                  value={registry}
                  onChange={(e) => setRegistry(e.target.value)}
                />
                <button className="btn primary">
                  <Plus size={16} />
                  Create registry
                </button>
              </div>
              <small>Uses your current bag, or starts with one Newborn Sunshine Bundle.</small>
            </form>
            {s.registries.map((r) => {
              const remaining = r.items
                .map((l) => ({
                  ...l,
                  qty: Math.max(
                    0,
                    l.qty -
                      sum(
                        s.docs.filter(
                          (d) =>
                            d.kind === 'order' && d.registry === r.id && d.status !== 'Cancelled',
                        ),
                        (d) =>
                          sum(
                            d.lines.filter((x) => x.item === l.item),
                            (x) => x.qty,
                          ),
                      ),
                  ),
                }))
                .filter((l) => l.qty > 0);
              return (
                <div className="registry" key={r.id}>
                  <h3>
                    <Heart size={17} />
                    {r.name} <Badge>{r.customer === cid ? 'My registry' : 'Guest shopping'}</Badge>
                  </h3>
                  {r.items.map((l) => {
                    const need = remaining.find((x) => x.item === l.item)?.qty || 0;
                    return (
                      <p key={l.item}>
                        {itemBy(s, l.item).name} · {l.qty - need} of {l.qty} gifted ·{' '}
                        <b>{need} still needed</b>
                      </p>
                    );
                  })}
                  <button
                    className="btn"
                    disabled={!remaining.length}
                    onClick={() => {
                      setLines(remaining);
                      setRegistryId(r.id);
                      setTab('Shop');
                    }}
                  >
                    {remaining.length ? 'Shop remaining gifts' : 'Registry complete'}
                  </button>
                </div>
              );
            })}
          </div>
        </section>
      )}
    </>
  );
}
function Seasonal({
  s,
  onPlanning,
  onForecast,
}: {
  s: State;
  onPlanning: () => void;
  onForecast: (c: Command) => void;
}) {
  const [uplift, setUplift] = useState(15);
  const series = Array.from({ length: 12 }, (_, n) => {
    const date = addDays(today(), n * 7),
      past = addDays(date, -364),
      prev = sum(
        s.docs.filter(
          (d) => d.kind === 'sale' && dayOf(d.date) >= past && dayOf(d.date) < addDays(past, 7),
        ),
        (d) => sum(d.lines, (l) => l.qty),
      ),
      recent =
        sum(
          s.docs.filter((d) => d.kind === 'sale' && dayOf(d.date) >= addDays(today(), -28)),
          (d) => sum(d.lines, (l) => l.qty),
        ) / 4,
      last =
        sum(
          s.docs.filter(
            (d) =>
              d.kind === 'sale' &&
              dayOf(d.date) >= addDays(today(), -56) &&
              dayOf(d.date) < addDays(today(), -28),
          ),
          (d) => sum(d.lines, (l) => l.qty),
        ) / 4,
      growth = last ? Math.min(1.5, Math.max(0.7, recent / last)) : 1,
      base = Math.round((prev || recent) * growth);
    return {
      date,
      week: fmtDate(date),
      Baseline: base,
      Promotion: Math.ceil(base * (1 + uplift / 100)),
    };
  });
  return (
    <>
      <section className="card">
        <div className="card-head">
          <div>
            <h3>Your next 12 weeks of sunshine</h3>
            <p>Prior-year seasonal units × recent four-week trend · 1.5× trend cap</p>
          </div>
          <label className="row">
            Promo uplift{' '}
            <input
              className="qty-input"
              type="number"
              min="0"
              max="500"
              value={uplift}
              onChange={(e) => setUplift(+e.target.value)}
            />{' '}
            %
          </label>
        </div>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={series} margin={{ right: 30, left: 10 }}>
            <CartesianGrid vertical={false} stroke="#eeeae2" />
            <XAxis dataKey="week" tick={{ fontSize: 11 }} />
            <YAxis />
            <Tooltip />
            <Area
              type="monotone"
              dataKey="Baseline"
              stroke="#a8b89a"
              fill="#a8b89a"
              fillOpacity={0.1}
            />
            <Area
              type="monotone"
              dataKey="Promotion"
              stroke="#dbaa34"
              fill="#e8bd54"
              fillOpacity={0.15}
            />
          </AreaChart>
        </ResponsiveContainer>
        <div className="card-foot row">
          <span className="grow">
            {num(sum(series, (x) => x.Promotion))} forecast units · holiday ramp, Mother’s Day, and
            baby-shower patterns come from seeded history.
          </span>
          <button className="btn" onClick={() => csv('seasonal-forecast', series)}>
            <Download size={16} />
            Export
          </button>
          <button
            className="btn primary"
            onClick={() => {
              const lines = s.items
                .filter((i) => i.price > 0)
                .flatMap((i) =>
                  series.map((w) => {
                    const all = sum(
                      s.docs.filter(
                        (d) => d.kind === 'sale' && dayOf(d.date) >= addDays(today(), -90),
                      ),
                      (d) => sum(d.lines, (l) => l.qty),
                    );
                    const sold = sum(
                      s.docs.filter(
                        (d) => d.kind === 'sale' && dayOf(d.date) >= addDays(today(), -90),
                      ),
                      (d) =>
                        sum(
                          d.lines.filter((l) => l.item === i.id),
                          (l) => l.qty,
                        ),
                    );
                    return {
                      item: i.id,
                      date: w.date,
                      qty: Math.ceil(w.Promotion * (all ? sold / all : 0)),
                    };
                  }),
                );
              onForecast({ type: 'forecast', lines });
            }}
          >
            Push forecast into MRP <ArrowRight size={16} />
          </button>
        </div>
      </section>
      <p className="info">
        <CalendarDays size={20} /> Push forecast into MRP to allocate weekly unit forecasts by
        recent product mix. MRP consumes confirmed demand against the forecast using the greater
        quantity per item/week, avoiding double counting. Review every suggestion before ordering.
      </p>
    </>
  );
}
function Labels({ s }: { s: State }) {
  const [selected, setSelected] = useState<Record<string, number>>({}),
    [search, setSearch] = useState('');
  const count = sum(Object.values(selected), (v) => v);
  return (
    <div className="labels-layout">
      <section className="card no-print">
        <div className="card-head">
          <h3>Choose your labels</h3>
          <ScanLine size={20} />
        </div>
        <div className="pad">
          <input
            className="wide"
            placeholder="Search name or SKU…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <button className="btn primary wide mt" disabled={!count} onClick={() => window.print()}>
            <Printer size={16} />
            Print {count} labels
          </button>
        </div>
        <div className="label-select-list">
          {s.items
            .filter((i) => (i.name + i.sku).toLowerCase().includes(search.toLowerCase()))
            .map((i) => (
              <label className="label-select" key={i.id}>
                <span>
                  <b>{i.name}</b>
                  <small>{i.sku}</small>
                </span>
                <input
                  className="qty-input"
                  type="number"
                  min="0"
                  max="100"
                  aria-label={'Labels for ' + i.name}
                  value={selected[i.id] || 0}
                  onChange={(e) =>
                    setSelected({
                      ...selected,
                      [i.id]: Math.min(100, Math.max(0, +e.target.value)),
                    })
                  }
                />
              </label>
            ))}
        </div>
      </section>
      <section className="card">
        <div className="card-head no-print">
          <div>
            <h3>Label sheet preview</h3>
            <p>Three-column grid · set print scale to 100%, margins to minimum</p>
          </div>
        </div>
        {count ? (
          <div className="label-sheet print-area">
            {Object.entries(selected).flatMap(([id, n]) =>
              Array.from({ length: n }, (_, j) => {
                const i = itemBy(s, id);
                return (
                  <div className="barcode-label" key={id + j}>
                    <b>{i.name}</b>
                    <small>
                      {i.sku}
                      {i.price ? ' · ' + money(i.price) : ''}
                    </small>
                    <Barcode value={i.barcode} />
                  </div>
                );
              }),
            )}
          </div>
        ) : (
          <Empty text="Add a few labels to your sheet" />
        )}
      </section>
    </div>
  );
}
function About() {
  return (
    <section className="card about">
      <span className="eyebrow">ABOUT THIS SYSTEM</span>
      <h2>A connected little world.</h2>
      <p>
        Sunbeams is a fictional mom-and-baby brand and an ERP course project built with OpenAI
        Codex. The frontend uses React, TypeScript, Vite, Tailwind CSS, Lucide, Recharts, JsBarcode,
        and ZXing. Supabase provides Postgres, Auth, row-level permissions and Realtime when
        configured.
      </p>
      <div className="info">
        <BookOpen size={22} />
        <p>
          Browser demo mode stores a complete workspace on this device and synchronizes tabs through
          storage events. It is intended for a classroom demo. Live Supabase mode requires the
          migration, seed, and project environment variables. See the README for setup and current
          limitations.
        </p>
      </div>
      <h3>One action, connected everywhere</h3>
      <div className="flow-diagram">
        <span>Customers → Sales orders</span>
        <ArrowRight />
        <span>Inventory ledger</span>
        <ArrowRight />
        <span>General ledger</span>
        <ArrowRight />
        <span>Reports & planning</span>
      </div>
      <div className="flow-diagram">
        <span>Suppliers → POs → Receipts</span>
        <ArrowRight />
        <span>Components → BOM → Production</span>
        <ArrowRight />
        <span>Finished pieces & matching sets</span>
      </div>
      <h3>Data model</h3>
      <svg
        viewBox="0 0 780 230"
        role="img"
        aria-label="Database architecture: profiles authorizes ERP state commands, which update inventory, journals and realtime notices"
        className="erd"
      >
        <defs>
          <marker id="arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto">
            <path d="M0 0L7 3.5L0 7" fill="#baa56e" />
          </marker>
        </defs>
        {[
          [130, 55, 290, 100],
          [410, 100, 560, 35],
          [410, 100, 560, 100],
          [410, 100, 560, 170],
          [665, 112, 665, 170],
        ].map(([x, y, x2, y2], i) => (
          <path
            key={i}
            d={`M${x} ${y}L${x2} ${y2}`}
            stroke="#cbbc93"
            fill="none"
            markerEnd="url(#arrow)"
          />
        ))}
        {[
          ['profiles', 20, 25, 'Auth roles / customer ID'],
          ['erp_state', 275, 65, 'Catalog, BOMs, documents'],
          ['inventory_transactions', 540, 10, 'Quantity / cost ledger'],
          ['journal_entries', 540, 77, 'Business references'],
          ['journal_lines', 540, 157, 'Accounts / debits / credits'],
          ['erp_notices', 275, 157, 'Realtime version signal'],
        ].map(([label, x, y, sub]) => (
          <g key={String(label)} transform={`translate(${x},${y})`}>
            <rect width="215" height="56" rx="8" fill="#f7f0dc" stroke="#e5d7b6" />
            <text x="12" y="23" fontSize="12" fill="#8b7548">
              {label}
            </text>
            <text x="12" y="41" fontSize="10" fill="#b19d72">
              {sub}
            </text>
          </g>
        ))}
      </svg>
      <p>
        Postgres locks the workspace aggregate for each business command. Inventory and accounting
        projection tables are rebuilt in that same transaction. Catalog and document collections
        also have read-only SQL views.
      </p>
      <pre>{`profiles ── customers ── sales orders ── lines ── items
suppliers ── purchase orders ── receipts ── AP invoices
items ── BOM components ── production orders
items + locations ── inventory transactions
business documents ── journal entries ── journal lines
settings ── ordering policies / tax / supplier scoring`}</pre>
      <h3>The math, without the mystery</h3>
      <Table heads={['MEASURE', 'FORMULA']}>
        {[
          [
            'Weighted average cost',
            '(Existing quantity × WAC + received quantity × receipt cost) ÷ new total quantity',
          ],
          ['Safety stock', 'z × standard deviation of daily demand × √lead time'],
          [
            'Reorder point',
            'Average daily usage × lead time + safety stock (or item minimum, if higher)',
          ],
          ['EOQ', '√(2 × annual demand × ordering cost ÷ annual holding cost per unit)'],
          ['Annual holding cost', 'Annual holding rate × current unit cost'],
          ['Inventory position', 'On-hand + on-order − allocated'],
          [
            'Net MRP requirements',
            'max(0, gross requirements − prior projected inventory − scheduled receipts)',
          ],
          ['Order-by date', 'Requirement date − component lead time'],
          [
            'Supplier score',
            'Weighted mean of on-time delivery, fill rate, and direct-resale quality',
          ],
          ['Inventory turnover', 'Period COGS ÷ mean daily closing inventory carrying value'],
          ['Days sales of inventory', 'Number of days in period ÷ period inventory turnover'],
          ['First-pass yield (course definition)', 'Good units ÷ started units'],
          ['First-touch yield', '(Good units − reworked units) ÷ started units'],
          ['Scrap / rework rates', 'Scrap or reworked units ÷ started units'],
          ['Cycle time', 'Actual finish timestamp − actual start timestamp'],
          ['On-time completion', 'Orders finished by planned date ÷ completed orders'],
        ].map(([a, b]) => (
          <tr key={a}>
            <td>
              <b>{a}</b>
            </td>
            <td>{b}</td>
          </tr>
        ))}
      </Table>
      <h3>Accounting choices</h3>
      <p>
        All costs are in USD. Each inventory movement records quantity, cost, value, location,
        reference, reason, time and operator. WAC is global per item; journal values round to cents.
        Historical seed activity uses the same transaction engine as live demo actions, starting
        from a balanced opening inventory and owner investment.
      </p>
      <p>
        Production issues debit Work in Progress and credit Inventory. On completion, material cost
        is absorbed into good units, including scrap cost; if every unit is scrapped, the entire
        cost posts to Shrinkage. Reworked units are a subset of good units and never create extra
        stock. Quality returns retain original sale cost and enter non-sellable hold; all held stock
        is included in financial inventory.
      </p>
      <p>
        Returns reverse the original discounted revenue and tax proportionally, with cumulative
        rounding so a full return reverses every cent. Exchanges run the return and replacement sale
        atomically. No card processor is connected; payment methods record tender for the demo.
      </p>
      <h3>Scope notes</h3>
      <p>
        Sizes and lots are not tracked. Supplier quality attribution covers purchased resale items
        by preferred supplier, not manufactured component lots. Registry checkout reserves inventory
        through pickup orders and tracks gifts against desired quantities. Seasonal forecasts feed
        MRP when the manager explicitly pushes them. MRP does not net existing production WIP. Demo
        state writes across simultaneous tabs are not a substitute for database transactions.
      </p>
    </section>
  );
}
function MovementForm({
  s,
  type,
  item,
  onSubmit,
}: {
  s: State;
  type: 'adjust' | 'transfer';
  item?: string;
  onSubmit: (c: Command) => void;
}) {
  const [id, setId] = useState(item || s.items[0].id),
    [qty, setQty] = useState(1),
    [code, setCode] = useState(''),
    [camera, setCamera] = useState(false),
    [error, setError] = useState('');
  function scan(v: string) {
    const i = s.items.find((i) => i.barcode === v);
    if (!i) {
      setError('Unknown barcode: ' + v);
      return;
    }
    setQty(i.id === id ? qty + 1 : 1);
    setId(i.id);
    setCode('');
    setError('');
  }
  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const v = Object.fromEntries(new FormData(e.currentTarget));
        onSubmit({ type, ...v, item: id, qty });
      }}
    >
      <div className="row">
        <input
          className="grow"
          placeholder="Scan a barcode, then Enter…"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              scan(code);
            }
          }}
        />
        <button
          type="button"
          className="btn"
          aria-label="Camera scan"
          onClick={() => setCamera(true)}
        >
          <Camera size={17} />
        </button>
      </div>
      <Field label="Item">
        <select
          value={id}
          onChange={(e) => {
            setId(e.target.value);
            setQty(1);
          }}
        >
          {s.items.map((i) => (
            <option key={i.id} value={i.id}>
              {i.barcode} · {i.name}
            </option>
          ))}
        </select>
      </Field>
      {type === 'transfer' ? (
        <div className="form-grid">
          <Field label="From">
            <select name="from">
              {s.locations.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </select>
          </Field>
          <Field label="To">
            <select name="to" defaultValue="studio">
              {s.locations.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
            </select>
          </Field>
        </div>
      ) : (
        <Field label="Location">
          <select name="location">
            {s.locations.map((l) => (
              <option key={l.id} value={l.id}>
                {l.name}
              </option>
            ))}
          </select>
        </Field>
      )}
      <Field label={type === 'transfer' ? 'Quantity' : 'Quantity change (+ found / − removed)'}>
        <input
          type="number"
          step="1"
          min={type === 'transfer' ? 1 : undefined}
          required
          value={qty}
          onChange={(e) => setQty(+e.target.value)}
        />
      </Field>
      {type === 'adjust' && (
        <Field label="Required reason">
          <select name="reason">
            {['CYCLE_COUNT', 'DAMAGED', 'LOST', 'FOUND'].map((x) => (
              <option key={x}>{x}</option>
            ))}
          </select>
        </Field>
      )}
      {error && <p className="error">{error}</p>}
      <p className="muted">
        Availability is checked before posting. Each scan increments the selected item’s quantity.
      </p>
      <button className="btn primary">Post {type}</button>
      {camera && (
        <Modal title="Scan inventory label" onClose={() => setCamera(false)}>
          <CameraScan onScan={scan} onClose={() => setCamera(false)} />
        </Modal>
      )}
    </form>
  );
}
