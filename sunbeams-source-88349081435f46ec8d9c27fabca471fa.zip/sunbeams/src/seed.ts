import {
  apply,
  addDays,
  today,
  round,
  onHand,
  uid,
  type State,
  type Item,
  type Command,
} from './domain';
export function createSeed(): State {
  const supplierNames = [
    'Wasatch Blank Apparel Co.',
    'Little Cotton Mills',
    'Bright Press Transfers',
    'Canyon Stitch Patches',
    'Honeycomb Packaging',
    'Sundance Accessories Wholesale',
  ];
  const s: State = {
    version: 0,
    items: [],
    suppliers: supplierNames.map((name, n) => ({
      id: 'sup' + n,
      name,
      contact: [
        'James Walker',
        'Sarah Kim',
        'Daniel Cole',
        'Mia Jensen',
        'Nora Brooks',
        'Eli Parker',
      ][n],
      email: [
        'orders@wasatch.example',
        'sales@littlecotton.example',
        'hello@brightpress.example',
        'orders@canyonstitch.example',
        'hello@honeycomb.example',
        'sales@sundance.example',
      ][n],
      phone: `801-555-01${10 + n}`,
      address: ['Provo, UT', 'Logan, UT', 'Orem, UT', 'Ogden, UT', 'Lehi, UT', 'St. George, UT'][n],
      lead: [10, 14, 7, 21, 5, 18][n],
      terms: ['Net 30', 'Net 30', 'Net 15', 'Net 45', 'Net 30', '2/10 Net 30'][n],
      moq: [12, 12, 25, 20, 50, 6][n],
    })),
    customers: [],
    locations: [
      { id: 'provo', name: 'Provo Flagship Store' },
      { id: 'orem', name: 'Orem Fulfillment Warehouse' },
      { id: 'studio', name: 'Print Studio' },
    ],
    bom: [],
    docs: [],
    moves: [],
    journals: [],
    settings: {
      taxRate: 0.0725,
      orderCost: 35,
      holdingRate: 0.25,
      z: 1.65,
      reviewDays: 7,
      workingDays: 312,
      weightDelivery: 50,
      weightFill: 30,
      weightQuality: 20,
    },
    activity: [],
    registries: [],
  };
  const data: [string, number, number, number, string, string][] = [
    ['Blank Women’s Crew Tee · Cream', 5.2, 0, 0, 'Components', 'component'],
    ['Blank Women’s Crew Tee · Sage', 5.6, 0, 0, 'Components', 'component'],
    ['Blank Baby Onesie · Cream', 3.8, 0, 1, 'Components', 'component'],
    ['Blank Baby Tee · Sage', 4.1, 0, 1, 'Components', 'component'],
    ['Blank Women’s Crewneck · Oatmeal', 12.5, 0, 0, 'Components', 'component'],
    ['Blank Baby Sweatshirt · Oatmeal', 7.5, 0, 1, 'Components', 'component'],
    ['Mama Sun Heat Transfer', 1.8, 0, 2, 'Components', 'component'],
    ['Little Sunbeam Heat Transfer', 1.2, 0, 2, 'Components', 'component'],
    ['Mama Bloom Heat Transfer', 2.1, 0, 2, 'Components', 'component'],
    ['Little Bud Heat Transfer', 1.4, 0, 2, 'Components', 'component'],
    ['Embroidered Sun Patch · Large', 2.5, 0, 3, 'Components', 'component'],
    ['Embroidered Sun Patch · Small', 1.6, 0, 3, 'Components', 'component'],
    ['Matching Set Gift Box', 2.2, 0, 4, 'Components', 'component'],
    ['Tissue Paper Sheet', 0.12, 0, 4, 'Components', 'component'],
    ['Sunbeams Sticker Seal', 0.08, 0, 4, 'Components', 'component'],
    ['Satin Hang Tag', 0.2, 0, 4, 'Components', 'component'],
    ['Mom Straw Sun Hat', 9.5, 28, 5, 'Accessories', 'resale'],
    ['Baby Sun Bonnet', 5.2, 18, 5, 'Accessories', 'resale'],
    ['Muslin Swaddle · Sunshine Print', 7.2, 24, 5, 'Accessories', 'resale'],
    ['Baby Socks 3-Pack', 3.6, 12, 5, 'Accessories', 'resale'],
    ['Linen Scrunchie', 1.8, 8, 5, 'Accessories', 'resale'],
    ['Sunbeams Canvas Tote', 4.8, 16, 5, 'Accessories', 'resale'],
    ['Mama Sun Printed Tee', 7.2, 32, 0, 'Mom', 'manufactured'],
    ['Little Sunbeam Printed Onesie', 5.2, 24, 1, 'Baby', 'manufactured'],
    ['Mama Bloom Sage Tee', 7.9, 34, 0, 'Mom', 'manufactured'],
    ['Little Bud Sage Baby Tee', 5.7, 26, 1, 'Baby', 'manufactured'],
    ['Mom Sunshine Sweatshirt', 15.2, 48, 0, 'Mom', 'manufactured'],
    ['Baby Sunshine Sweatshirt', 9.3, 34, 1, 'Baby', 'manufactured'],
    ['Sunbeam Matching Set', 15, 62, 4, 'Matching Sets', 'kit'],
    ['Bloom Matching Set', 16.2, 66, 4, 'Matching Sets', 'kit'],
    ['Cozy Sunshine Sweatshirt Set', 27, 79, 4, 'Matching Sets', 'kit'],
    ['Sun Hat Duo', 19.5, 58, 5, 'Matching Sets', 'kit'],
    ['Newborn Sunshine Bundle', 18.4, 64, 4, 'Matching Sets', 'kit'],
  ];
  s.items = data.map(([name, cost, price, sup, category, type], n): Item => ({
    id: 'i' + n,
    sku: `SB-${String(n + 1).padStart(4, '0')}`,
    barcode: `SB-${String(n + 1).padStart(6, '0')}`,
    name,
    cost,
    price,
    supplier: 'sup' + sup,
    category,
    type,
    lead: type === 'kit' ? 2 : type === 'manufactured' ? 3 : s.suppliers[sup].lead,
    rop: type === 'component' ? 25 : 8,
    description:
      type === 'component'
        ? 'Carefully sourced materials for our in-house Print Studio.'
        : 'Thoughtfully made for sunshine-filled days and little moments together.',
  }));
  const recipes: Record<number, [number, number][]> = {
    22: [
      [0, 1],
      [6, 1],
      [15, 1],
    ],
    23: [
      [2, 1],
      [7, 1],
      [15, 1],
    ],
    24: [
      [1, 1],
      [8, 1],
      [15, 1],
    ],
    25: [
      [3, 1],
      [9, 1],
      [15, 1],
    ],
    26: [
      [4, 1],
      [10, 1],
      [15, 1],
    ],
    27: [
      [5, 1],
      [11, 1],
      [15, 1],
    ],
    28: [
      [22, 1],
      [23, 1],
      [12, 1],
      [13, 2],
      [14, 1],
    ],
    29: [
      [24, 1],
      [25, 1],
      [12, 1],
      [13, 2],
      [14, 1],
    ],
    30: [
      [26, 1],
      [27, 1],
      [12, 1],
      [13, 2],
      [14, 1],
    ],
    31: [
      [16, 1],
      [17, 1],
      [21, 1],
    ],
    32: [
      [23, 1],
      [18, 1],
      [19, 1],
      [12, 1],
      [13, 2],
    ],
  };
  for (const [p, lines] of Object.entries(recipes))
    for (const [i, qty] of lines) s.bom.push({ parent: 'i' + p, item: 'i' + i, qty });
  const names = [
    'Olivia Bennett',
    'Emma Christensen',
    'Sophia Martinez',
    'Charlotte Davis',
    'Amelia Wilson',
    'Isabella Nguyen',
    'Mia Robinson',
    'Harper Anderson',
    'Evelyn Thomas',
    'Abigail Jensen',
    'Emily Moore',
    'Ella Thompson',
    'Grace Peterson',
    'Lily Harris',
    'Hannah Taylor',
  ];
  s.customers = names.map((name, n) => ({
    id: 'c' + n,
    name,
    email: name.toLowerCase().replace(' ', '.') + '@example.com',
    phone: `801-555-02${String(n).padStart(2, '0')}`,
    city: ['Provo', 'Orem', 'Lehi', 'Spanish Fork', 'Springville', 'American Fork', 'Draper'][
      n % 7
    ],
  }));
  const end = today(),
    start = addDays(end, -364);
  const date = (d: string, h = 14) => d + `T${String(h).padStart(2, '0')}:00:00.000Z`;
  const run = (c: Command) => apply(s, c, 'Seed · Emma', 'Manager');
  // Opening capital and inventory are balanced, identifiable ledger events, not hidden balances.
  let opening = 0;
  for (const i of s.items)
    for (const l of s.locations) {
      const scale = 1 + (Number(i.id.slice(1)) % 5) * 0.12;
      const qty = Math.round(
        (i.type === 'component'
          ? l.id === 'studio'
            ? 900
            : l.id === 'orem'
              ? 240
              : 40
          : i.type === 'kit'
            ? l.id === 'studio'
              ? 4
              : l.id === 'orem'
                ? 12
                : 10
            : i.type === 'resale'
              ? l.id === 'studio'
                ? 20
                : l.id === 'orem'
                  ? 80
                  : 60
              : l.id === 'studio'
                ? 80
                : l.id === 'orem'
                  ? 120
                  : 100) * scale,
      );
      const value = round(qty * i.cost);
      s.moves.push({
        id: uid(),
        date: date(addDays(start, -1)),
        item: i.id,
        location: l.id,
        qty,
        cost: i.cost,
        value,
        ref: 'OPENING',
        type: 'Opening',
        reason: 'OPENING_BALANCE',
        user: 'System',
      });
      opening += value;
    }
  s.journals.push({
    id: uid(),
    date: date(addDays(start, -1)),
    ref: 'OPENING',
    memo: 'Opening owner investment',
    lines: [
      { account: 'Inventory', debit: round(opening), credit: 0 },
      { account: 'Cash', debit: 50000, credit: 0 },
      { account: 'Owner Equity', debit: 0, credit: round(opening + 50000) },
    ],
  });
  // Historical replenishment follows the same transfer, PO and BOM paths as the UI.
  function ensureStock(id: string, needed: number, location: string, day: string) {
    let shortage = needed - onHand(s, id, location);
    if (shortage <= 0) return;
    for (const source of s.locations.filter((l) => l.id !== location)) {
      const amount = Math.min(shortage, onHand(s, id, source.id));
      if (amount > 0) {
        run({
          type: 'transfer',
          item: id,
          qty: amount,
          from: source.id,
          to: location,
          date: date(day, 12),
        });
        shortage -= amount;
      }
      if (shortage <= 0) return;
    }
    const item = s.items.find((i) => i.id === id)!,
      components = s.bom.filter((b) => b.parent === id);
    if (components.length) {
      const qty = Math.max(30, shortage);
      for (const b of components) ensureStock(b.item, b.qty * qty, 'studio', day);
      run({
        type: 'production',
        item: id,
        qty,
        location: 'studio',
        planned: day,
        date: date(day, 8),
      });
      const p = s.docs[s.docs.length - 1];
      run({ type: 'issue', id: p.id, date: date(day, 9) });
      run({ type: 'start', id: p.id, date: date(day, 10) });
      run({
        type: 'complete',
        id: p.id,
        good: qty,
        scrap: 0,
        rework: 0,
        labor: qty / 12,
        date: date(day, 12),
      });
      if (location !== 'studio')
        run({
          type: 'transfer',
          item: id,
          qty: shortage,
          from: 'studio',
          to: location,
          date: date(day, 13),
        });
    } else {
      const supplier = s.suppliers.find((p) => p.id === item.supplier)!,
        lag = [-1, 5, 0, 12, -2, 3][Number(supplier.id.slice(3))],
        qty = Math.max(shortage, item.type === 'component' ? 300 : 60);
      run({
        type: 'po',
        supplier: supplier.id,
        location,
        lines: [{ item: id, qty, cost: round(item.cost * 1.01) }],
        date: date(addDays(day, -supplier.lead - lag), 10),
      });
      const po = s.docs[s.docs.length - 1];
      run({
        type: 'receive',
        id: po.id,
        location,
        lines: [{ item: id, qty }],
        date: date(day, 11),
      });
    }
  }
  // Deterministic seasonal demand with nonuniform item popularity, location mix and 4% returns.
  let txn = 0;
  for (let day = 0; day < 365; day++) {
    const d = addDays(start, day),
      dt = new Date(d + 'T12:00:00Z'),
      dow = dt.getUTCDay(),
      month = dt.getUTCMonth() + 1,
      md = Number(d.slice(5).replace('-', ''));
    const mother = md >= 425 && md <= 515 ? 2.8 : 1,
      holiday = month === 12 || (md >= 1115 && md <= 1130) ? 1.7 : 1,
      growth = 0.75 + day / 730,
      count = Math.round((dow === 0 ? 2 : dow === 6 ? 10 : 6) * mother * holiday * growth);
    for (let k = 0; k < count; k++) {
      const n = (day * 17 + k * 11) % 100;
      let ix =
        n < 25
          ? 22
          : n < 45
            ? 23
            : n < 60
              ? 28
              : n < 70
                ? 19
                : n < 78
                  ? 24
                  : n < 84
                    ? 25
                    : n < 89
                      ? 29
                      : n < 93
                        ? 18
                        : n < 96
                          ? 20
                          : n < 98
                            ? 31
                            : 32;
      if ((month <= 3 || month >= 10) && n >= 70 && n < 84) ix = n % 2 ? 26 : 30;
      if (month >= 4 && month <= 8 && n >= 89) ix = n % 2 ? 16 : 17;
      const loc = dow === 0 ? 'orem' : k % 4 === 0 ? 'orem' : 'provo',
        qty = k % 7 === 0 ? 2 : 1;
      const i = s.items[ix];
      if (onHand(s, i.id, loc) < qty + 12) ensureStock(i.id, qty + 36, loc, d);
      run({
        type: 'sale',
        location: loc,
        customer: 'c' + ((day + k) % 15),
        lines: [{ item: i.id, qty }],
        discount: k % 11 === 0 ? 10 : 0,
        source: loc === 'orem' ? 'Portal' : 'POS',
        date: date(d, 14 + (k % 7)),
      });
      txn++;
      if (txn % 25 === 0) {
        const sale = s.docs[s.docs.length - 1];
        run({
          type: 'return',
          id: sale.id,
          lines: [{ item: i.id, qty: 1 }],
          reason: [
            'WRONG_SIZE',
            'CHANGED_MIND',
            'GIFT_RETURN',
            'QUALITY_DEFECT_PRINT_PEELING',
            'QUALITY_DEFECT_SEAM',
          ][Math.floor(txn / 25) % 5],
          date: date(addDays(d, Math.min(3, 364 - day)), 20),
        });
      }
    }
    // Each supplier has a distinct early/late/fill profile; receipts and payments use the same posting path.
    if (day % 28 === 0)
      for (let sup = 0; sup < 6; sup++) {
        const items = s.items.filter(
          (i) => i.supplier === 'sup' + sup && ['component', 'resale'].includes(i.type),
        );
        const lines = items
          .slice(0, 3)
          .map((i) => ({ item: i.id, qty: 120, cost: round(i.cost * (0.96 + (day % 5) * 0.02)) }));
        run({ type: 'po', supplier: 'sup' + sup, location: 'studio', lines, date: date(d, 10) });
        const po = s.docs[s.docs.length - 1],
          lag = [-1, 5, 0, 12, -2, 3][sup],
          receivedDate = addDays(po.expected, lag);
        if (receivedDate <= end) {
          run({
            type: 'receive',
            id: po.id,
            location: sup === 5 ? 'orem' : 'studio',
            lines: lines.map((l) => ({ ...l, qty: sup === 3 ? 72 : 120 })),
            date: date(receivedDate, 12),
          });
          if (addDays(receivedDate, 32) < end)
            run({ type: 'pay', id: po.id, date: date(addDays(receivedDate, 32), 13) });
        }
      }
    if (day % 6 === 0) {
      const id = 'i' + (22 + (Math.floor(day / 6) % 6));
      const b = s.bom.filter((b) => b.parent === id);
      for (const c of b) ensureStock(c.item, c.qty * 24, 'studio', d);
      run({
        type: 'production',
        item: id,
        qty: 24,
        location: 'studio',
        planned: d,
        date: date(d, 9),
      });
      const p = s.docs[s.docs.length - 1];
      run({ type: 'issue', id: p.id, date: date(d, 10) });
      run({ type: 'start', id: p.id, date: date(d, 11) });
      const scrap = day % 4 === 0 ? 2 : 1,
        rework = day % 3 === 0 ? 2 : 0;
      run({
        type: 'complete',
        id: p.id,
        good: 24 - scrap,
        scrap,
        rework,
        reason: [
          'MISALIGNED_PRINT',
          'TRANSFER_PEELING',
          'CROOKED_PATCH',
          'FABRIC_FLAW',
          'HEAT_PRESS_SCORCH',
        ][day % 5],
        labor: 2.5,
        date: date(d, 14 + (day % 3)),
      });
    }
  }
  // Visible working scenarios: some thin pairs, open production, POs and backordered sets.
  for (const [id, target] of [
    ['i23', 8],
    ['i28', 3],
    ['i17', 5],
    ['i6', 18],
    ['i10', 12],
  ] as [string, number][]) {
    const q = target - onHand(s, id, 'provo');
    if (q)
      run({
        type: 'adjust',
        item: id,
        location: 'provo',
        qty: q,
        reason: 'CYCLE_COUNT',
        date: date(end, 9),
      });
  }
  for (const [id, total] of [
    ['i23', 2],
    ['i24', 0],
    ['i25', 0],
    ['i28', 6],
    ['i29', 0],
    ['i30', 0],
    ['i32', 0],
    ['i9', 1],
  ] as [string, number][]) {
    for (const [n, location] of s.locations.entries()) {
      const target = n === 0 ? total : 0,
        change = target - onHand(s, id, location.id);
      if (change)
        run({
          type: 'adjust',
          item: id,
          location: location.id,
          qty: change,
          reason: 'CYCLE_COUNT',
          date: date(end, 9),
        });
    }
  }
  for (let n = 0; n < 5; n++)
    run({
      type: 'order',
      customer: 'c' + n,
      location: n % 2 ? 'orem' : 'provo',
      lines: [{ item: ['i28', 'i23', 'i29', 'i30', 'i32'][n], qty: n === 0 ? 14 : 2 + n }],
      requested: addDays(end, n * 5 + 2),
      date: date(end, 10 + n),
    });
  for (let n = 0; n < 3; n++)
    run({
      type: 'production',
      item: 'i' + (22 + n),
      qty: 20 + n * 5,
      location: 'studio',
      planned: addDays(end, n + 1),
      date: date(end, 9),
    });
  const planned = s.docs.filter((d) => d.kind === 'production' && d.status === 'Planned');
  run({ type: 'issue', id: planned[0].id, date: date(end, 10) });
  run({ type: 'start', id: planned[0].id, date: date(end, 11) });
  s.activity = s.activity.slice(0, 40);
  s.version = 1;
  return s;
}
