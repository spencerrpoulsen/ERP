export type Role = 'Manager' | 'Cashier' | 'Studio' | 'Customer';
export type Item = {
  id: string;
  sku: string;
  barcode: string;
  name: string;
  category: string;
  type: string;
  cost: number;
  price: number;
  lead: number;
  supplier: string;
  rop: number;
  description: string;
  pair?: string;
};
export type Supplier = {
  id: string;
  name: string;
  contact: string;
  email: string;
  phone: string;
  address: string;
  lead: number;
  terms: string;
  moq: number;
};
export type Line = {
  item: string;
  qty: number;
  price?: number;
  cost?: number;
  discount?: number;
  discountType?: string;
  returned?: number;
  received?: number;
  net?: number;
  tax?: number;
};
export type Doc = {
  id: string;
  kind: string;
  date: string;
  status: string;
  location: string;
  customer?: string;
  supplier?: string;
  lines: Line[];
  history: { status: string; date: string; user: string }[];
  total: number;
  [key: string]: any;
};
export type Movement = {
  id: string;
  date: string;
  item: string;
  location: string;
  qty: number;
  cost: number;
  value: number;
  ref: string;
  type: string;
  reason: string;
  user: string;
  hold?: boolean;
};
export type Journal = {
  id: string;
  date: string;
  ref: string;
  memo: string;
  lines: { account: string; debit: number; credit: number }[];
};
export type State = {
  version: number;
  items: Item[];
  suppliers: Supplier[];
  customers: { id: string; name: string; email: string; phone: string; city: string }[];
  locations: { id: string; name: string }[];
  bom: { parent: string; item: string; qty: number }[];
  docs: Doc[];
  moves: Movement[];
  journals: Journal[];
  settings: Record<string, number>;
  activity: { id: string; date: string; user: string; text: string }[];
  registries: { id: string; name: string; customer: string; items: Line[] }[];
  forecasts?: { item: string; date: string; qty: number }[];
};
export type Command = { type: string; [key: string]: any };
export const round = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;
export const sum = <T>(a: T[], f: (x: T) => number) => a.reduce((s, x) => s + f(x), 0);
const businessDateFormatter = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'America/Denver',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
});
const businessDates = new Map<string, string>();
export const today = () => businessDateFormatter.format(new Date());
export const dayOf = (d: string) => {
  if (d.length === 10) return d;
  let day = businessDates.get(d);
  if (day) return day;
  day = businessDateFormatter.format(new Date(d));
  if (businessDates.size > 20000) businessDates.clear();
  businessDates.set(d, day);
  return day;
};
export const addDays = (d: string, n: number) => {
  const t = new Date(dayOf(d) + 'T12:00:00Z');
  t.setUTCDate(t.getUTCDate() + n);
  return t.toISOString().slice(0, 10);
};
export const uid = () => globalThis.crypto?.randomUUID?.() || Math.random().toString(36).slice(2);
export const itemBy = (s: State, id: string) => {
  const i = s.items.find((x) => x.id === id);
  if (!i) throw Error('Item not found');
  return i;
};
export const onHand = (s: State, item: string, loc?: string, hold = false) =>
  sum(
    s.moves.filter((x) => x.item === item && (!loc || x.location === loc) && !!x.hold === hold),
    (x) => x.qty,
  );
export function reserved(s: State, order: string, item: string) {
  const d = s.docs.find((d) => d.id === order);
  if (!d || d.kind !== 'order' || d.status !== 'Order Placed') return 0;
  let remaining = onHand(s, item, d.location);
  for (const doc of s.docs.filter(
    (x) => x.kind === 'order' && x.status === 'Order Placed' && x.location === d.location,
  )) {
    const need = sum(
        doc.lines.filter((l) => l.item === item),
        (l) => l.qty,
      ),
      allocation = Math.min(need, Math.max(0, remaining));
    if (doc.id === order) return allocation;
    remaining -= allocation;
  }
  return 0;
}
export const allocated = (s: State, item: string, loc?: string, except?: string) =>
  sum(
    s.docs.filter(
      (x) =>
        x.kind === 'order' &&
        x.status === 'Order Placed' &&
        x.id !== except &&
        (!loc || x.location === loc),
    ),
    (d) => reserved(s, d.id, item),
  );
export const backordered = (s: State, item: string, loc?: string) =>
  sum(
    s.docs.filter(
      (x) => x.kind === 'order' && x.status === 'Order Placed' && (!loc || x.location === loc),
    ),
    (d) =>
      sum(
        d.lines.filter((l) => l.item === item),
        (l) => l.qty,
      ) - reserved(s, d.id, item),
  );
export const available = (s: State, item: string, loc?: string, except?: string) =>
  Math.max(0, onHand(s, item, loc) - allocated(s, item, loc, except));
export const onOrder = (s: State, item: string) =>
  sum(
    s.docs.filter(
      (d) => d.kind === 'po' && !['Closed', 'Cancelled', 'Received'].includes(d.status),
    ),
    (d) =>
      sum(
        d.lines.filter((l) => l.item === item),
        (l) => l.qty - (l.received || 0),
      ),
  );
export const wac = (s: State, id: string) => itemBy(s, id).cost;
export const invValue = (s: State) => round(sum(s.moves, (x) => x.value));
export function balance(s: State, account: string, from = '0000', to = '9999') {
  return round(
    sum(
      s.journals.filter((j) => dayOf(j.date) >= from && dayOf(j.date) <= to),
      (j) =>
        sum(
          j.lines.filter((l) => l.account === account),
          (l) => l.debit - l.credit,
        ),
    ),
  );
}
export function pnl(s: State, from = '0000', to = '9999') {
  const gross = -balance(s, 'Sales Revenue', from, to),
    discount = balance(s, 'Sales Discounts', from, to),
    returns = balance(s, 'Sales Returns', from, to),
    net = round(gross - discount - returns),
    cogs = balance(s, 'COGS', from, to),
    shrink = balance(s, 'Shrinkage', from, to),
    profit = round(net - cogs);
  return {
    gross,
    discount,
    returns,
    net,
    cogs,
    profit,
    margin: net ? (profit / net) * 100 : 0,
    shrink,
    income: round(profit - shrink),
  };
}
export function costReceipt(s: State, id: string, qty: number, cost: number) {
  const i = itemBy(s, id),
    q = onHand(s, id) + onHand(s, id, undefined, true);
  i.cost = q + qty > 0 ? (q * i.cost + qty * cost) / (q + qty) : cost;
}
function move(
  s: State,
  id: string,
  loc: string,
  qty: number,
  cost: number,
  ref: string,
  type: string,
  reason: string,
  date: string,
  user: string,
  hold = false,
) {
  s.moves.push({
    id: uid(),
    date,
    item: id,
    location: loc,
    qty,
    cost,
    value: round(qty * cost),
    ref,
    type,
    reason,
    user,
    hold,
  });
}
function post(s: State, ref: string, memo: string, date: string, entries: Record<string, number>) {
  const lines = Object.entries(entries)
    .filter(([, v]) => Math.abs(v) > 0.0001)
    .map(([account, v]) => ({
      account,
      debit: v > 0 ? round(v) : 0,
      credit: v < 0 ? round(-v) : 0,
    }));
  if (Math.abs(sum(lines, (x) => x.debit - x.credit)) > 0.005)
    throw Error('Journal does not balance');
  s.journals.push({ id: uid(), ref, memo, date, lines });
}
function assertQty(n: number, allowZero = false) {
  if (!Number.isInteger(n) || n < (allowZero ? 0 : 1))
    throw Error('Quantity must be a ' + (allowZero ? 'nonnegative' : 'positive') + ' whole number');
}
function checkLines(lines: Line[]) {
  if (!lines?.length) throw Error('Add at least one item');
  const ids = new Set();
  for (const l of lines) {
    assertQty(l.qty);
    if (ids.has(l.item)) throw Error('Combine duplicate items into one line');
    ids.add(l.item);
  }
}
function enough(s: State, id: string, loc: string, qty: number, except?: string) {
  if (available(s, id, loc, except) < qty)
    throw Error('Insufficient available stock for ' + itemBy(s, id).name);
}
function makeDoc(
  s: State,
  kind: string,
  c: Command,
  date: string,
  user: string,
  status: string,
  lines: Line[],
  total = 0,
): Doc {
  const prefix = (
    { sale: 'SB', order: 'SO', po: 'PO', production: 'PR', return: 'RT' } as Record<string, string>
  )[kind];
  const n = s.docs.filter((d) => d.kind === kind).length + 1;
  const d: Doc = {
    id: `${prefix}-${String(n).padStart(5, '0')}`,
    kind,
    date,
    status,
    location: c.location || 'provo',
    customer: c.customer,
    supplier: c.supplier,
    lines,
    total,
    history: [{ status, date, user }],
  };
  s.docs.push(d);
  return d;
}
function status(d: Doc, v: string, date: string, user: string) {
  d.status = v;
  d.history.push({ status: v, date, user });
}
export function saleTotals(s: State, lines: Line[], discount = 0, discountType = 'percent') {
  const result = lines.map((l) => {
    const p = l.price ?? itemBy(s, l.item).price;
    if (!Number.isFinite(p) || p < 0) throw Error('Invalid price');
    const gross = round(p * l.qty),
      v = l.discount || 0;
    if (!Number.isFinite(v) || v < 0 || ((l.discountType || 'percent') === 'percent' && v > 100))
      throw Error('Invalid line discount');
    const reduction = round(l.discountType === 'dollar' ? v : (gross * v) / 100);
    if (reduction > gross) throw Error('Line discount exceeds amount');
    return { ...l, price: p, gross, lineDiscount: reduction, net: round(gross - reduction) };
  });
  const base = round(sum(result, (l) => l.net));
  if (!Number.isFinite(discount) || discount < 0 || (discountType === 'percent' && discount > 100))
    throw Error('Invalid order discount');
  const orderDiscount = round(discountType === 'dollar' ? discount : (base * discount) / 100);
  if (orderDiscount > base) throw Error('Discount exceeds subtotal');
  let used = 0;
  const taxRate = s.settings.taxRate;
  const final = result.map((l, n) => {
    const part =
      n === result.length - 1
        ? round(orderDiscount - used)
        : round(base ? (orderDiscount * l.net) / base : 0);
    used += part;
    const net = round(l.net - part);
    return { ...l, net, tax: round(net * taxRate), cost: wac(s, l.item), returned: 0 };
  });
  const net = round(sum(final, (l) => l.net)),
    tax = round(sum(final, (l) => l.tax));
  return {
    lines: final,
    subtotal: round(sum(result, (l) => l.gross)),
    discount: round(sum(result, (l) => l.lineDiscount) + orderDiscount),
    net,
    tax,
    total: round(net + tax),
  };
}
function recordSale(
  s: State,
  c: Command,
  date: string,
  user: string,
  except?: string,
  quotedTaxRate?: number,
) {
  checkLines(c.lines);
  for (const l of c.lines) {
    if (itemBy(s, l.item).price <= 0) throw Error('Components cannot be sold');
    enough(s, l.item, c.location, l.qty, except);
  }
  const totals = saleTotals(
    quotedTaxRate === undefined ? s : { ...s, settings: { ...s.settings, taxRate: quotedTaxRate } },
    c.lines,
    c.discount,
    c.discountType,
  );
  const d = makeDoc(s, 'sale', c, date, user, 'Completed', totals.lines, totals.total);
  Object.assign(d, totals, { payment: c.payment || 'card', source: c.source || 'POS' });
  let cost = 0;
  for (const l of d.lines) {
    const v = round(l.qty * l.cost!);
    cost += v;
    move(s, l.item, c.location, -l.qty, l.cost!, d.id, 'Sale', 'SALE', date, user);
  }
  post(s, d.id, 'Sale', date, {
    [c.payment === 'account' ? 'Accounts Receivable' : 'Cash']: totals.total,
    'Sales Discounts': totals.discount,
    'Sales Revenue': -totals.subtotal,
    'Sales Tax Payable': -totals.tax,
    COGS: round(cost),
    Inventory: -round(cost),
  });
  return d;
}
export function execute(
  input: State,
  c: Command,
  user = 'Olivia Bennett',
  role: Role = 'Manager',
): State {
  const s = structuredClone(input);
  apply(s, c, user, role);
  s.version++;
  return s;
}
export function apply(s: State, c: Command, user = 'Olivia Bennett', role: Role = 'Manager') {
  const date = c.date || new Date().toISOString();
  if (
    ['sale', 'order', 'po', 'production', 'receive', 'adjust'].includes(c.type) &&
    !s.locations.some((l) => l.id === c.location)
  )
    throw Error('Choose a valid location');
  const manager = ['settings', 'supplier', 'pay', 'item', 'forecast', 'deleteSupplier'];
  if (role === 'Customer' && !['order', 'registry'].includes(c.type))
    throw Error('Customer access is limited to pickup orders and registries');
  if (manager.includes(c.type) && role !== 'Manager') throw Error('Manager permission required');
  if (
    role === 'Cashier' &&
    [
      'po',
      'receive',
      'production',
      'issue',
      'start',
      'complete',
      'cancelPO',
      'cancelProduction',
      'adjust',
      'transfer',
    ].includes(c.type)
  )
    throw Error('Warehouse or manager permission required');
  if (
    role === 'Studio' &&
    ['sale', 'return', 'order', 'fulfill', 'close', 'cancelOrder'].includes(c.type)
  )
    throw Error('Cashier or manager permission required');
  if (c.type === 'sale') recordSale(s, c, date, user);
  else if (c.type === 'order') {
    checkLines(c.lines);
    for (const l of c.lines) {
      if (itemBy(s, l.item).price <= 0) throw Error('Components cannot be sold');
    }
    if (!s.customers.some((x) => x.id === c.customer)) throw Error('Choose a customer');
    const safeLines = c.lines.map((l: Line) => ({ item: l.item, qty: l.qty }));
    const d = makeDoc(
      s,
      'order',
      c,
      date,
      user,
      'Order Placed',
      saleTotals(s, safeLines).lines,
      saleTotals(s, safeLines).total,
    );
    d.taxRate = s.settings.taxRate;
    d.requested = c.requested || today();
    d.source = c.source || 'Staff';
    if (c.registry) d.registry = c.registry;
  } else if (['fulfill', 'close', 'cancelOrder'].includes(c.type)) {
    const d = s.docs.find((d) => d.id === c.id && d.kind === 'order');
    if (!d) throw Error('Order not found');
    if (c.type === 'fulfill') {
      if (d.status !== 'Order Placed') throw Error('Only placed orders can be fulfilled');
      const sale = recordSale(
        s,
        { ...c, lines: d.lines, location: d.location, customer: d.customer, source: d.source },
        date,
        user,
        d.id,
        d.taxRate,
      );
      d.sale = sale.id;
      status(d, 'Fulfilled', date, user);
    } else if (c.type === 'close') {
      if (d.status !== 'Fulfilled') throw Error('Fulfill the order first');
      status(d, 'Closed', date, user);
    } else {
      if (d.status !== 'Order Placed') throw Error('Only open orders can be cancelled');
      status(d, 'Cancelled', date, user);
    }
  } else if (c.type === 'transfer') {
    assertQty(c.qty);
    if (c.from === c.to) throw Error('Choose different locations');
    enough(s, c.item, c.from, c.qty);
    const cost = wac(s, c.item),
      ref = 'TR-' + uid().slice(0, 8);
    move(s, c.item, c.from, -c.qty, cost, ref, 'Transfer', 'TRANSFER', date, user);
    move(s, c.item, c.to, c.qty, cost, ref, 'Transfer', 'TRANSFER', date, user);
  } else if (c.type === 'adjust') {
    if (!c.reason) throw Error('A reason code is required');
    if (!Number.isInteger(c.qty) || !c.qty) throw Error('Enter a nonzero whole quantity change');
    if (c.qty < 0) enough(s, c.item, c.location, -c.qty);
    const cost = wac(s, c.item),
      ref = 'AD-' + uid().slice(0, 8),
      v = round(c.qty * cost);
    move(s, c.item, c.location, c.qty, cost, ref, 'Adjustment', c.reason, date, user);
    post(s, ref, c.reason, date, { Inventory: v, Shrinkage: -v });
  } else if (c.type === 'return') {
    const original = s.docs.find((d) => d.id === c.id && d.kind === 'sale');
    if (!original) throw Error('Original receipt not found');
    checkLines(c.lines);
    if (!c.reason) throw Error('A return reason is required');
    let net = 0,
      tax = 0,
      cost = 0;
    const lines: Line[] = [];
    const d = makeDoc(
      s,
      'return',
      { location: original.location, customer: original.customer, type: 'return' },
      date,
      user,
      'Refunded',
      lines,
    );
    d.original = original.id;
    d.reason = c.reason;
    d.quality = c.reason.startsWith('QUALITY');
    for (const l of c.lines) {
      const ol = original.lines.find((x) => x.item === l.item);
      if (!ol || l.qty > ol.qty - (ol.returned || 0))
        throw Error('Cannot return more than purchased');
      const before = ol.returned || 0,
        after = before + l.qty;
      const n = round((ol.net! * after) / ol.qty) - round((ol.net! * before) / ol.qty),
        t = round((ol.tax! * after) / ol.qty) - round((ol.tax! * before) / ol.qty);
      ol.returned = after;
      const v = round(l.qty * ol.cost!);
      net += n;
      tax += t;
      cost += v;
      costReceipt(s, l.item, l.qty, ol.cost!);
      move(
        s,
        l.item,
        original.location,
        l.qty,
        ol.cost!,
        d.id,
        'Return',
        c.reason,
        date,
        user,
        d.quality,
      );
      lines.push({ ...l, net: n, tax: t, cost: ol.cost });
    }
    d.total = round(net + tax);
    post(s, d.id, 'Refund', date, {
      'Sales Returns': round(net),
      'Sales Tax Payable': round(tax),
      Cash: -d.total,
      Inventory: round(cost),
      COGS: -round(cost),
    });
    if (c.replacements?.length) {
      const replacement = recordSale(
        s,
        {
          type: 'sale',
          location: original.location,
          customer: original.customer,
          lines: c.replacements,
        },
        date,
        user,
      );
      d.replacement = replacement.id;
      d.difference = round(replacement.total - d.total);
    }
  } else if (c.type === 'po') {
    checkLines(c.lines);
    const supplier = s.suppliers.find((x) => x.id === c.supplier);
    if (!supplier) throw Error('Choose a supplier');
    for (const l of c.lines) {
      if (!Number.isFinite(l.cost) || l.cost! <= 0) throw Error('Enter a positive unit cost');
    }
    const d = makeDoc(
      s,
      'po',
      c,
      date,
      user,
      'Order Sent',
      c.lines.map((l: Line) => ({ ...l, received: 0 })),
      round(sum(c.lines as Line[], (l) => l.qty * l.cost!)),
    );
    d.expected = c.expected || addDays(date, supplier.lead);
    d.receipts = [];
    d.invoices = [];
  } else if (c.type === 'receive') {
    const d = s.docs.find((x) => x.id === c.id && x.kind === 'po');
    if (!d || !['Order Sent', 'Partially Received'].includes(d.status))
      throw Error('This PO cannot be received');
    checkLines(c.lines);
    let total = 0;
    const received: Line[] = [];
    for (const l of c.lines) {
      const ol = d.lines.find((x) => x.item === l.item);
      if (!ol || l.qty > ol.qty - (ol.received || 0))
        throw Error('Quantity exceeds remaining PO quantity');
      ol.received = (ol.received || 0) + l.qty;
      const cost = ol.cost!;
      costReceipt(s, l.item, l.qty, cost);
      move(s, l.item, c.location, l.qty, cost, d.id, 'Receipt', 'PO_RECEIPT', date, user);
      total += round(cost * l.qty);
      received.push({ ...l, cost });
    }
    total = round(total);
    const supplier = s.suppliers.find((x) => x.id === d.supplier)!;
    const days = Number(supplier.terms.match(/Net (\d+)/)?.[1] || 30);
    d.receipts.push({
      date,
      location: c.location,
      lines: received,
      total,
      late: Math.round(
        (new Date(date.slice(0, 10)).getTime() - new Date(d.expected).getTime()) / 86400000,
      ),
    });
    d.invoices.push({
      id: 'INV-' + uid().slice(0, 8),
      date,
      due: addDays(date, days),
      total,
      paid: 0,
    });
    post(s, d.id, 'Purchase receipt', date, { Inventory: total, 'Accounts Payable': -total });
    status(
      d,
      d.lines.every((x) => x.received === x.qty) ? 'Received' : 'Partially Received',
      date,
      user,
    );
  } else if (c.type === 'pay') {
    const d = s.docs.find((x) => x.id === c.id && x.kind === 'po');
    if (!d) throw Error('PO not found');
    const total = round(sum(d.invoices || [], (i: any) => i.total - i.paid));
    if (total <= 0) throw Error('No outstanding balance');
    for (const i of d.invoices) i.paid = i.total;
    post(s, d.id, 'Supplier payment', date, { 'Accounts Payable': total, Cash: -total });
    if (d.status === 'Received') status(d, 'Closed', date, user);
  } else if (c.type === 'cancelPO') {
    const d = s.docs.find((x) => x.id === c.id && x.kind === 'po');
    if (!d || d.status !== 'Order Sent') throw Error('Only unreceived POs can be cancelled');
    status(d, 'Cancelled', date, user);
  } else if (c.type === 'production') {
    assertQty(c.qty);
    if (!s.bom.some((x) => x.parent === c.item)) throw Error('Item has no bill of materials');
    const d = makeDoc(s, 'production', c, date, user, 'Planned', [{ item: c.item, qty: c.qty }]);
    d.planned = c.planned || today();
  } else if (['issue', 'start', 'complete', 'cancelProduction'].includes(c.type)) {
    const d = s.docs.find((x) => x.id === c.id && x.kind === 'production');
    if (!d) throw Error('Production order not found');
    const l = d.lines[0];
    if (c.type === 'issue') {
      if (d.status !== 'Planned') throw Error('Order already issued');
      const components = s.bom.filter((x) => x.parent === l.item);
      for (const b of components) enough(s, b.item, d.location, b.qty * l.qty);
      d.consumed = [];
      d.materialCost = 0;
      for (const b of components) {
        const qty = b.qty * l.qty,
          cost = wac(s, b.item);
        move(s, b.item, d.location, -qty, cost, d.id, 'Production Issue', 'BOM_ISSUE', date, user);
        d.consumed.push({ item: b.item, qty, cost });
        d.materialCost += round(qty * cost);
      }
      d.materialCost = round(d.materialCost);
      post(s, d.id, 'Issue components', date, {
        'Work in Progress': d.materialCost,
        Inventory: -d.materialCost,
      });
      status(d, 'Released', date, user);
    } else if (c.type === 'start') {
      if (d.status !== 'Released') throw Error('Issue components first');
      d.started = date;
      status(d, 'In Progress', date, user);
    } else if (c.type === 'cancelProduction') {
      if (d.status !== 'Planned') throw Error('Only unissued production can be cancelled');
      status(d, 'Cancelled', date, user);
    } else {
      if (d.status !== 'In Progress') throw Error('Start the production order first');
      assertQty(c.good, true);
      assertQty(c.scrap, true);
      assertQty(c.rework, true);
      if (c.good + c.scrap !== l.qty || c.rework > c.good)
        throw Error('Good + scrap must equal started; rework is a subset of good');
      if ((c.scrap || c.rework) && !c.reason) throw Error('A quality reason code is required');
      if (new Date(date) < new Date(d.started)) throw Error('Finish precedes start');
      d.good = c.good;
      d.scrap = c.scrap;
      d.rework = c.rework;
      d.reason = c.reason;
      d.finished = date;
      d.labor = Number(c.labor) || 0;
      if (d.labor < 0) throw Error('Labor hours must be nonnegative');
      if (c.good) {
        const cost = d.materialCost / c.good;
        costReceipt(s, l.item, c.good, cost);
        move(
          s,
          l.item,
          d.location,
          c.good,
          cost,
          d.id,
          'Production Complete',
          'GOOD_UNITS',
          date,
          user,
        );
        post(s, d.id, 'Production complete: scrap absorbed', date, {
          Inventory: d.materialCost,
          'Work in Progress': -d.materialCost,
        });
      } else
        post(s, d.id, 'All units scrapped', date, {
          Shrinkage: d.materialCost,
          'Work in Progress': -d.materialCost,
        });
      status(d, 'Completed', date, user);
    }
  } else if (c.type === 'settings') {
    for (const [k, v] of Object.entries(c.values)) {
      if (typeof v !== 'number' || !Number.isFinite(v) || v < 0)
        throw Error('Settings must be nonnegative numbers');
      if (['taxRate', 'holdingRate'].includes(k) && v > 1)
        throw Error('Enter rates between 0 and 1');
      s.settings[k] = v;
    }
    if (
      !s.settings.holdingRate ||
      !s.settings.workingDays ||
      !s.settings.reviewDays ||
      !sum(['weightDelivery', 'weightFill', 'weightQuality'], (k) => s.settings[k])
    )
      throw Error('Holding, working/review days and score weights must be positive');
  } else if (c.type === 'deleteSupplier') {
    if (s.items.some((i) => i.supplier === c.id) || s.docs.some((d) => d.supplier === c.id))
      throw Error('This supplier has items or purchasing history and cannot be deleted');
    s.suppliers = s.suppliers.filter((p) => p.id !== c.id);
  } else if (c.type === 'supplier') {
    const v = c.value as Supplier;
    if (!v.name?.trim() || !v.email?.includes('@') || !(v.lead > 0))
      throw Error('Supplier name, valid email and lead time required');
    const i = s.suppliers.findIndex((x) => x.id === v.id);
    if (i < 0) s.suppliers.push({ ...v, id: uid() });
    else s.suppliers[i] = { ...v };
  } else if (c.type === 'item') {
    const i = itemBy(s, c.id);
    if (c.lead < 0 || c.rop < 0) throw Error('Lead time and reorder point must be nonnegative');
    i.lead = +c.lead;
    i.rop = +c.rop;
    i.supplier = c.supplier;
  } else if (c.type === 'forecast') {
    for (const f of c.lines) {
      assertQty(f.qty, true);
      itemBy(s, f.item);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(f.date)) throw Error('Forecast date required');
    }
    s.forecasts = c.lines;
  } else if (c.type === 'registry') {
    if (!c.name?.trim()) throw Error('Registry name required');
    checkLines(c.lines);
    s.registries.push({ id: uid(), name: c.name, customer: c.customer, items: c.lines });
  } else throw Error('Unknown action');
  s.activity.unshift({ id: uid(), date, user, text: activityText(s, c) });
  s.activity = s.activity.slice(0, 250);
}
function activityText(s: State, c: Command) {
  const i = c.item ? s.items.find((x) => x.id === c.item)?.name : '';
  const names: Record<string, string> = {
    sale: `Completed a sale · ${sum(c.lines || [], (l: any) => l.qty)} items`,
    order: 'Placed a pickup order',
    fulfill: `Fulfilled ${c.id}`,
    receive: `Received stock against ${c.id}`,
    production: `Planned ${c.qty} × ${i}`,
    complete: `Completed ${c.id} · ${c.good} good units`,
    transfer: `Transferred ${c.qty} × ${i}`,
    adjust: `Adjusted ${i} · ${c.reason}`,
    return: `Processed a return for ${c.id}`,
    settings: 'Updated planning settings',
    pay: `Paid supplier invoice · ${c.id}`,
  };
  return (
    names[c.type] || `${c.type.charAt(0).toUpperCase() + c.type.slice(1)} · ${c.id || i || 'saved'}`
  );
}
export function demand(s: State, id: string, days = 90, location?: string) {
  const end = today(),
    start = addDays(end, -days + 1);
  const daily = Array.from({ length: days }, () => 0);
  for (const m of s.moves) {
    if (
      m.item !== id ||
      (location && m.location !== location) ||
      !['Sale', 'Production Issue'].includes(m.type) ||
      dayOf(m.date) < start ||
      dayOf(m.date) > end
    )
      continue;
    const n = Math.floor(
      (new Date(dayOf(m.date)).getTime() - new Date(start).getTime()) / 86400000,
    );
    if (n >= 0 && n < days) daily[n] += -m.qty;
  }
  const avg = sum(daily, (x) => x) / days,
    sd = Math.sqrt(sum(daily, (x) => (x - avg) ** 2) / days);
  return { avg, sd, daily };
}
export function ordering(s: State, id: string) {
  const i = itemBy(s, id),
    d = demand(s, id),
    safety = s.settings.z * d.sd * Math.sqrt(i.lead),
    rop = d.avg * i.lead + safety,
    eoq =
      i.cost > 0
        ? Math.sqrt(
            (2 * d.avg * s.settings.workingDays * s.settings.orderCost) /
              (s.settings.holdingRate * i.cost),
          )
        : 0,
    position = onHand(s, id) + onOrder(s, id) - allocated(s, id),
    target = d.avg * (i.lead + s.settings.reviewDays) + safety,
    suggested =
      position < Math.max(rop, i.rop)
        ? Math.max(
            0,
            Math.ceil(
              Math.max(
                eoq,
                target - position,
                s.suppliers.find((x) => x.id === i.supplier)?.moq || 1,
              ),
            ),
          )
        : 0;
  return {
    ...d,
    safety,
    rop,
    eoq,
    position,
    suggested,
    orderBy: addDays(today(), d.avg ? Math.floor((position - safety) / d.avg) - i.lead : 0),
  };
}
export function expectedDate(s: State, id: string) {
  const dates = s.docs
    .filter(
      (d) =>
        d.kind === 'po' &&
        ['Order Sent', 'Partially Received'].includes(d.status) &&
        d.lines.some((l) => l.item === id && l.qty > (l.received || 0)),
    )
    .map((d) => d.expected as string)
    .sort();
  return dates[0] || addDays(today(), itemBy(s, id).lead);
}
export function scorecard(s: State, id: string) {
  const supplier = s.suppliers.find((x) => x.id === id)!,
    pos = s.docs.filter((x) => x.kind === 'po' && x.supplier === id && x.status !== 'Cancelled'),
    receipts = pos.flatMap((d) => (d.receipts || []).map((r: any) => ({ ...r, sent: d.date }))),
    received = sum(pos, (d) => sum(d.lines, (l) => l.received || 0)),
    ordered = sum(pos, (d) => sum(d.lines, (l) => l.qty)),
    onTime = receipts.length
      ? sum(receipts, (r: any) => (r.late <= 0 ? 1 : 0)) / receipts.length
      : 0,
    lead = receipts.length
      ? sum(
          receipts,
          (r: any) => (new Date(r.date).getTime() - new Date(r.sent).getTime()) / 86400000,
        ) / receipts.length
      : 0,
    defects = sum(
      s.docs.filter((d) => d.kind === 'return' && d.quality),
      (d) =>
        sum(
          d.lines.filter((l) => itemBy(s, l.item).supplier === id),
          (l) => l.qty,
        ),
    ),
    quality = received ? Math.max(0, 1 - defects / received) : 0,
    fill = ordered ? received / ordered : 0,
    weights = s.settings.weightDelivery + s.settings.weightFill + s.settings.weightQuality,
    score = weights
      ? ((onTime * s.settings.weightDelivery +
          fill * s.settings.weightFill +
          quality * s.settings.weightQuality) /
          weights) *
        100
      : 0,
    invoices = pos.flatMap((d) => (d.invoices || []).map((i: any) => ({ ...i, po: d.id }))),
    ap = sum(invoices, (i: any) => i.total - i.paid),
    overdue = sum(
      invoices.filter((i: any) => i.due < today()),
      (i: any) => i.total - i.paid,
    );
  return {
    supplier,
    onTime,
    lead,
    fill,
    quality,
    score,
    rating: !receipts.length
      ? 'NO HISTORY'
      : score >= 85
        ? 'KEEP'
        : score >= 65
          ? 'WATCH'
          : 'REPLACE',
    ap,
    overdue,
    invoices,
    receipts,
  };
}
export function mrp(s: State, roundOrders = false, uplift = 0) {
  const start = today(),
    buckets = Array.from({ length: 4 }, (_, n) => addDays(start, n * 7));
  const rows: Record<
    string,
    {
      item: string;
      weeks: {
        date: string;
        gross: number;
        receipts: number;
        projected: number;
        net: number;
        release: string;
        qty: number;
      }[];
    }
  > = {};
  const stock: Record<string, number> = {};
  s.items.forEach((i) => (stock[i.id] = onHand(s, i.id)));
  const requirements: Record<string, number[]> = {};
  s.items.forEach((i) => (requirements[i.id] = [0, 0, 0, 0]));
  for (const d of s.docs.filter((d) => d.kind === 'order' && d.status === 'Order Placed')) {
    const w = Math.max(
      0,
      Math.floor((new Date(d.requested).getTime() - new Date(start).getTime()) / 604800000),
    );
    if (w < 4)
      for (const l of d.lines) requirements[l.item][w] += Math.ceil(l.qty * (1 + uplift / 100));
  }
  for (const f of s.forecasts || []) {
    const w = Math.max(
      0,
      Math.floor((new Date(f.date).getTime() - new Date(start).getTime()) / 604800000),
    );
    if (w < 4) requirements[f.item][w] = Math.max(requirements[f.item][w], f.qty);
  }
  // Parents precede subassemblies, then purchased components. Accumulate shared demand once.
  const depth = (id: string, path: string[] = []): number => {
    if (path.includes(id)) throw Error('Cyclic BOM');
    const b = s.bom.filter((b) => b.parent === id);
    return b.length ? 1 + Math.max(...b.map((x) => depth(x.item, [...path, id]))) : 0;
  };
  const sorted = [...s.items].sort((a, b) => depth(b.id) - depth(a.id));
  for (const i of sorted) {
    const bom = s.bom.filter((x) => x.parent === i.id);
    let projected = stock[i.id];
    const weeks = buckets.map((date, w) => {
      const receipts = sum(
          s.docs.filter(
            (d) =>
              d.kind === 'po' &&
              ['Order Sent', 'Partially Received'].includes(d.status) &&
              d.expected < addDays(date, 7) &&
              (w === 0 || d.expected >= date),
          ),
          (d) =>
            sum(
              d.lines.filter((l) => l.item === i.id),
              (l) => l.qty - (l.received || 0),
            ),
        ),
        gross = requirements[i.id][w];
      let net = Math.max(0, gross - projected - receipts);
      const qty = net
        ? roundOrders
          ? Math.ceil(
              Math.max(
                net,
                ordering(s, i.id).eoq,
                s.suppliers.find((x) => x.id === i.supplier)?.moq || 1,
              ),
            )
          : net
        : 0;
      projected = projected + receipts + qty - gross;
      if (qty && bom.length) {
        const release = addDays(date, -i.lead),
          bw = Math.max(
            0,
            Math.min(
              w,
              Math.floor((new Date(release).getTime() - new Date(start).getTime()) / 604800000),
            ),
          );
        for (const b of bom) requirements[b.item][bw] += qty * b.qty;
      }
      return { date, gross, receipts, projected, net, release: addDays(date, -i.lead), qty };
    });
    if (weeks.some((w) => w.gross || w.receipts)) rows[i.id] = { item: i.id, weeks };
  }
  return Object.values(rows);
}
export function productionMetrics(s: State, from = '0000', to = '9999') {
  const docs = s.docs.filter(
      (d) =>
        d.kind === 'production' &&
        d.status === 'Completed' &&
        dayOf(d.finished) >= from &&
        dayOf(d.finished) <= to,
    ),
    started = sum(docs, (d) => d.lines[0].qty),
    good = sum(docs, (d) => d.good),
    scrap = sum(docs, (d) => d.scrap),
    rework = sum(docs, (d) => d.rework);
  return {
    docs,
    started,
    good,
    scrap,
    rework,
    fpy: started ? (good / started) * 100 : 0,
    firstTouch: started ? ((good - rework) / started) * 100 : 0,
    scrapRate: started ? (scrap / started) * 100 : 0,
    reworkRate: started ? (rework / started) * 100 : 0,
    cycle: docs.length
      ? sum(
          docs,
          (d) => (new Date(d.finished).getTime() - new Date(d.started).getTime()) / 3600000,
        ) / docs.length
      : 0,
    onTime: docs.length
      ? (sum(docs, (d) => (dayOf(d.finished) <= d.planned ? 1 : 0)) / docs.length) * 100
      : 0,
    uph: sum(docs, (d) => d.labor) ? good / sum(docs, (d) => d.labor) : 0,
  };
}
export function turnover(s: State, from: string, to: string, ids?: string[]) {
  const movements = ids ? s.moves.filter((m) => ids.includes(m.item)) : s.moves;
  const days = Math.max(
    1,
    Math.round((new Date(to).getTime() - new Date(from).getTime()) / 86400000) + 1,
  );
  let value = sum(
      movements.filter((m) => dayOf(m.date) < from),
      (m) => m.value,
    ),
    acc = 0;
  const byDay: Record<string, number> = {};
  for (const m of movements)
    if (dayOf(m.date) >= from && dayOf(m.date) <= to)
      byDay[dayOf(m.date)] = (byDay[dayOf(m.date)] || 0) + m.value;
  for (let n = 0; n < days; n++) {
    value += byDay[addDays(from, n)] || 0;
    acc += value;
  }
  const average = acc / days,
    cogs = ids
      ? -sum(
          movements.filter(
            (m) =>
              ['Sale', 'Return'].includes(m.type) && dayOf(m.date) >= from && dayOf(m.date) <= to,
          ),
          (m) => m.value,
        )
      : pnl(s, from, to).cogs,
    turns = average > 0 ? cogs / average : 0;
  return { average, cogs, turns, dsi: turns ? days / turns : 0, days };
}
